# Evaluation Classification
## Parameters:
* Model: <class 'classification.category_models.keyword_model.KeywordModel'>
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.0
* Averaging method: macro
## In-sample Prediction:
| Metric | Result |
|---|---|
| Recall | None |
| Precision | None |
| F1 | None |
## Out-of-sample Prediction:
| Metric | Result |
|---|---|
| Recall | 0.9783 |
| Precision | 0.9798 |
| F1 | 0.9783 |
