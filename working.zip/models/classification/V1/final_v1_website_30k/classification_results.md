# Evaluation Classification
## Parameters:
* Model: <class 'classification.category_models.neural_net_model.NeuralNetCategoryModel'>
* Data-split: website
* Size dataset: 30000
* Train-Test-Split: 0.7
* Averaging method: macro
* Name: final_v1_website_30k
* Version: V1
## In-sample Prediction:
| Metric | Result |
|---|---|
| Recall | 0.9989 |
| Precision | 0.9988 |
| F1 | 0.9989 |
## Out-of-sample Prediction:
| Metric | Result |
|---|---|
| Recall | 0.9978 |
| Precision | 0.9975 |
| F1 | 0.9976 |
