# Evaluation Classification
## Parameters:
* Model: <class 'classification.category_models.neural_net_model.NeuralNetCategoryModel'>
* Data-split: domain
* Size dataset: 30000
* Train-Test-Split: 0.7
* Averaging method: macro
* Name: final_v1_domain_30k
* Version: V1
## In-sample Prediction:
| Metric | Result |
|---|---|
| Recall | 1.0 |
| Precision | 1.0 |
| F1 | 1.0 |
## Out-of-sample Prediction:
| Metric | Result |
|---|---|
| Recall | 0.6809 |
| Precision | 0.7261 |
| F1 | 0.6619 |
