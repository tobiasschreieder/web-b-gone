# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | bull | wizard | 
 | team | bull | 76ers | 
 | team | bull | maverick | 
 | name | wesley johnson basketball | wesley johnson | 
 | team | maverick | wizard | 
 | team | lakers | celtic | 
 | name | manu ginóbili | emanuel ginóbili | 
 | team | cavalier | heat | 
 | name | maurice evans basketball | maurice evans | 
 | team | bull | sun | 
 | team | bobcat | buck | 
 | team | bull | 76ers | 
 | name | richard hamilton basketball | richard hamilton | 
 | name | matt carroll basketball | matt carroll | 
 | name | joe smith basketball | joe smith | 
 | name | tim brown | shaquille oneal | 
 | team | bobcat | bull | 
 | name | david lee basketball | david lee | 
 | name | nazr mohammed | desagana diop | 
 | name | jon weinbach | demar derozan | 
 | team | maverick | celtic | 
 | team | heat | warrior | 
 | name | james harden basketball | james harden | 
 | team | bull | warrior | 
 | name | tony allen basketball | tony allen | 
 | team | magic | sun | 
 | name | andrew bynum | jermaine oneal | 
 | team | bull | lakers | 
 | team | bobcat | sun | 
 | team | denver nuggets | philadelphia 76ers | 
 | team | grizzly | 76ers | 
 | team | bobcat | maverick | 
 | name | andrei kirilenko basketball | andrei kirilenko | 
 | weight | 285 | 295160lb 134 kg | 
 | name | jason williams basketball | jason williams | 
