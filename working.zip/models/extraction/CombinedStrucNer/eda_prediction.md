# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.54 | 2.33 | 1.48 | 0.01 | 
| team | 13.25 | 1.9 | 1.23 | 0.1 | 
| height | 3.35 | 1.3 | 0.91 | 0.09 | 
| weight | 5.76 | 1.51 | 0.91 | 0.09 | 


