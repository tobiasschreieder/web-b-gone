# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.structured_ner_model.CombinedExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Ner_name: final_nerv1_nba_player_website
* Struc_name: final_struc_nba_player_website
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9185 | 0.9209 |
| F1 | 0.9207 | 0.9213 |
| Partial Match | 0.9197 | 0.9212 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9173 | 0.9216 |
| F1 | 0.9193 | 0.9219 |
| Partial Match | 0.919 | 0.9218 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9805 | 0.9903 |
| F1 | 0.9894 | 0.9917 |
| Partial Match | 0.9854 | 0.9915 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9783 | 0.9877 |
| F1 | 0.9863 | 0.9889 |
| Partial Match | 0.9849 | 0.9887 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8881 | 0.8881 |
| F1 | 0.8881 | 0.8881 |
| Partial Match | 0.8881 | 0.8881 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8781 | 0.8856 |
| F1 | 0.8781 | 0.8856 |
| Partial Match | 0.8781 | 0.8856 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9027 | 0.9027 |
| F1 | 0.9027 | 0.9027 |
| Partial Match | 0.9027 | 0.9027 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9064 | 0.9064 |
| F1 | 0.9064 | 0.9064 |
| Partial Match | 0.9064 | 0.9064 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9027 | 0.9027 |
| F1 | 0.9027 | 0.9027 |
| Partial Match | 0.9027 | 0.9027 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9064 | 0.9064 |
| F1 | 0.9064 | 0.9064 |
| Partial Match | 0.9064 | 0.9064 |
