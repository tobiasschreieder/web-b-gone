# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: domain
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_nerv1_nba_player_domain
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9637 | 0.9639 |
| F1 | 0.9638 | 0.964 |
| Partial Match | 0.9638 | 0.9639 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.4065 | 0.4159 |
| F1 | 0.5258 | 0.5352 |
| Partial Match | 0.4097 | 0.4193 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.998 | 0.9984 |
| F1 | 0.9984 | 0.9986 |
| Partial Match | 0.9984 | 0.9984 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.1469 | 0.1546 |
| F1 | 0.1639 | 0.1722 |
| Partial Match | 0.1556 | 0.1643 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8577 | 0.8581 |
| F1 | 0.8577 | 0.8581 |
| Partial Match | 0.8577 | 0.8581 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8106 | 0.8406 |
| F1 | 0.8147 | 0.8442 |
| Partial Match | 0.8145 | 0.8444 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 1.0 | 1.0 |
| F1 | 1.0 | 1.0 |
| Partial Match | 1.0 | 1.0 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.3343 | 0.3343 |
| F1 | 0.5654 | 0.5654 |
| Partial Match | 0.3343 | 0.3343 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9992 | 0.9992 |
| F1 | 0.9992 | 0.9992 |
| Partial Match | 0.9992 | 0.9992 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.3343 | 0.3343 |
| F1 | 0.5591 | 0.5591 |
| Partial Match | 0.3343 | 0.3343 |
