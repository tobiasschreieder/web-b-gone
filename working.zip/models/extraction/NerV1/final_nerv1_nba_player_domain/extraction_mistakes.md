# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | name | butler head | brian cook | 
 | name | now recommended | linas kleiza | 
 | height | 62 | height 62 | 
 | weight | 200 | weight 200 | 
 | name | russell robinson | darrell arthur | 
 | height | 6 ft 9 | 6160ft1609160in 2.06 m | 
 | name | now recommended | kwame brown | 
 | name | date opponent | zydrunas ilgauskas | 
 | name | powe head | joey graham | 
 | height | 69 | height 69 | 
 | weight | 260 | weight 260 | 
 | name | jefferson | lebron james | 
 | height | 67 | height 67 | 
 | weight | 265 | weight 265 | 
 | weight | jr. . | 253160lb 115 kg | 
 | name | kirilenko head | c. j. miles | 
 | name | david west | trevor ariza | 
 | name | blair head | emanuel ginóbili | 
 | name | date opponent | marvin williams | 
 | name | butler head | rasual butler | 
 | name | now recommended | hakim warrick | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | height | 60 | height 60 | 
 | weight | 165 | weight 165 | 
 | name | now recommended | leandro barbosa | 
 | name | batum head | nicolas batum | 
 | height | 68 | height 68 | 
 | weight | 212 | weight 212 | 
 | height | 64 | height 64 | 
 | weight | 180 | weight 180 | 
 | name | erden head | kevin garnett | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | now recommended | manny harris | 
 | name | austin toros | alonzo gee | 
 | name | aldrich head | eric maynor | 
 | height | 61 | height 61 | 
 | weight | 195 | weight 195 | 
 | height | 70 | height 70 | 
 | weight | 261 | weight 261 | 
 | height | 69 | height 69 | 
 | weight | 230 | weight 230 | 
 | name | seattle supersonics | damien wilkins | 
 | height | 69 | height 69 | 
 | weight | 242 | weight 242 | 
 | name | butler head | eric gordon | 
 | height | 511 | height 511 | 
 | weight | 175 | weight 175 | 
 | name | lennie rosenbluth | wayne ellington jr. | 
 | name | powe head | jamario moon | 
 | name | chris paul | emeka okafor | 
 | name | alabi head | predrag stojaković | 
 | height | 69 | height 69 | 
 | weight | 215 | weight 215 | 
 | height | 66 | height 66 | 
 | weight | 238 | weight 238 | 
 | height | 610 | height 610 | 
 | weight | 255 | weight 255 | 
 | name | all american | shelden williams | 
 | name | now recommended | roy hibbert | 
 | height | 64 | height 64 | 
 | weight | 190 | weight 190 | 
 | name | date opponent | j.j. barea | 
 | name | dooling head | ersan i̇lyasova | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | height | 71 | height 71 | 
 | weight | 250 | weight 250 | 
 | height | 66 | height 66 | 
 | weight | 230 | weight 230 | 
 | height | 65 | height 65 | 
 | weight | 205 | weight 205 | 
 | height | 610 | height 610 | 
 | weight | 230 | weight 230 | 
 | height | 68 | height 68 | 
 | weight | 235 | weight 235 | 
 | height | 69 | height 69 | 
 | weight | 240 | weight 240 | 
 | height | 70 | height 70 | 
 | weight | 265 | weight 265 | 
 | name | blair head | antonio mcdyess | 
 | height | 610 | height 610 | 
 | weight | 240 | weight 240 | 
 | height | 6 ft 9 | 6160ft1609160in 2.06 m | 
 | name | kapono head | tony battie | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | name | date opponent | o.j. mayo | 
 | name | ely head | al harrington | 
 | name | stevenson head | caron butler | 
 | height | 63 | height 63 | 
 | weight | 185 | weight 185 | 
 | height | 64 | height 64 | 
 | weight | 200 | weight 200 | 
 | name | okafor head | aaron gray | 
 | name | clark head | hedo turkoğlu | 
 | team | orlando magic | phoenix suns | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | name | elmer bennett | josé calderón | 
 | name | tayshaun prince | jason maxiell | 
 | height | 68 | height 68 | 
 | weight | 235 | weight 235 | 
 | name | williams head | malik allen | 
 | team | denver nuggets | orlando magic | 
 | name | ratliff head | luke walton | 
 | name | now recommended | vladimir radmanovic | 
 | name | date opponent | luke walton | 
 | height | 63 | height 63 | 
 | height | 66 | height 66 | 
 | weight | 225 | weight 225 | 
 | height | 610 | height 610 | 
 | weight | 255 | weight 255 | 
 | name | chris paul | patrick ewing jr. | 
 | height | 511 | height 511 | 
 | weight | 195 | weight 195 | 
 | name | now recommended | christian eyenga | 
 | height | 610 | height 610 | 
 | weight | 251 | weight 251 | 
 | name | ratliff head | derek fisher | 
 | team | lakers | los angeles lakers | 
 | height | 6 ft 1 | 6160ft1601160in 1.85 m | 
 | name | house head | eddie house | 
 | height | 610 | height 610 | 
 | weight | 250 | weight 250 | 
 | name | now recommended | gary forbes | 
 | name | batum head | wesley matthews | 
 | team | utah jazz | portland trail blazers | 
 | name | aldrich head | serge ibaka | 
 | name | now recommended | craig smith | 
 | name | blair head | george hill | 
 | name | curry head | eddy curry | 
 | name | brezec | goran dragić | 
 | name | now recommended | patrick patterson | 
 | name | euroleague olympiacos | josh childress | 
 | name | now recommended | jordan crawford | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | name | house head | žydrūnas ilgauskas | 
 | name | wei | ronny turiaf | 
 | team | los angeles lakers | new york knicks | 
 | name | jackson head | tyreke evans | 
 | height | 67 | height 67 | 
 | weight | 215 | weight 215 | 
 | name | stevenson head | jason kidd | 
 | team | new jersey | dallas mavericks | 
 | height | 63 | height 63 | 
 | weight | 215 | weight 215 | 
 | height | 62 | height 62 | 
 | weight | 182 | weight 182 | 
 | name | league draft | chuck hayes | 
 | height | 611 | height 611 | 
 | weight | 246 | weight 246 | 
 | name | now recommended | garret siler | 
 | name | now recommended | brandon rush | 
 | name | humphries head | joe smith | 
 | height | 60 | height 60 | 
 | weight | 185 | weight 185 | 
 | name | williams head | dwight howard | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | date opponent | keith bogans | 
 | name | now recommended | mustafa shakur | 
 | name | house head | joel anthony | 
 | name | now recommended | stephen jackson | 
 | height | 62 | height 62 | 
 | weight | 195 | weight 195 | 
 | name | deron williams | francisco elson | 
 | height | 68 | height 68 | 
 | weight | 235 | weight 235 | 
 | name | date opponent | marc gasol | 
 | name | lennie rosenbluth | ty lawson | 
 | name | patterson head | jared jeffries | 
 | name | now recommended | marcus thornton | 
 | name | their backup | marcus banks | 
 | team | miami heat | new orleans hornets | 
 | name | now recommended | josh mcroberts | 
 | name | tolliver head | lazar hayward | 
 | height | 67 | height 67 | 
 | weight | 260 | weight 260 | 
 | name | most valuable | michael redd | 
 | name | date opponent | magnum rolle | 
 | name | now recommended | jordan hill | 
 | name | thomas head | brian scalabrine | 
 | name | dorell wright | russell westbrook | 
 | height | 67 | height 67 | 
 | weight | 195 | weight 195 | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | name | oden | greg oden | 
 | name | date opponent | juwan howard | 
 | name | erden head | delonte west | 
 | height | 6 ft 3 | 6160ft1603160in 1.91 m | 
 | name | now recommended | malik allen | 
 | name | most valuable | jerryd bayless | 
 | team | arizona wildcats | toronto raptors | 
 | height | 63 | height 63 | 
 | weight | 195 | weight 195 | 
 | height | 61 | height 61 | 
 | weight | 169 | weight 169 | 
 | height | 69 | height 69 | 
 | weight | 225 | weight 225 | 
 | name | now recommended | hamady ndiaye | 
 | team | lakers | los angeles lakers | 
 | height | 66 | height 66 | 
 | weight | 212 | weight 212 | 
 | name | erden head | von wafer | 
 | name | date opponent | nazr mohammed | 
 | name | erden head | kendrick perkins | 
 | name | now recommended | samuel dalembert | 
 | name | dooling head | corey maggette | 
 | team | golden state warriors | milwaukee bucks | 
 | name | date opponent | mario chalmers | 
 | name | radmanović head | stephen curry | 
 | height | 6 ft 3 in 1.91 m | 6160ft1603160in 1.91 m | 
 | height | 611 | height 611 | 
 | weight | 304 | weight 304 | 
 | height | 611 | height 611 | 
 | height | 70 | height 70 | 
 | weight | 262 | weight 262 | 
 | name | now recommended | stephen curry | 
 | name | phil ford | antawn jamison | 
 | height | 67 | height 67 | 
 | name | blair head | matt bonner | 
 | height | 610 | height 610 | 
 | weight | 246 | weight 246 | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | height | 611 | height 611 | 
 | weight | 275 | weight 275 | 
 | name | now recommended | kris humphries | 
 | height | 67 | height 67 | 
 | weight | 220 | weight 220 | 
 | height | 65 | height 65 | 
 | weight | 218 | weight 218 | 
 | height | 63 | height 63 | 
 | weight | 190 | weight 190 | 
 | height | 610 | height 610 | 
 | weight | 260 | weight 260 | 
 | name | patterson head | yao ming | 
 | name | now recommended | nene hilario | 
 | name | now recommended | brandan wright | 
 | name | jackson head | beno udrih | 
 | name | date opponent | taj gibson | 
 | name | chris bosh | alexis ajinca | 
 | height | 68 | height 68 | 
 | weight | 250 | weight 250 | 
 | name | marvin williams | jawad williams | 
 | height | 69 | height 69 | 
 | weight | 215 | weight 215 | 
 | height | 610 | height 610 | 
 | weight | 231 | weight 231 | 
 | name | radmanović head | andris biedrins | 
 | height | 71 | height 71 | 
 | weight | 235 | weight 235 | 
 | name | lonny baxter | steve blake | 
 | height | 611 | height 611 | 
 | weight | 265 | weight 265 | 
 | name | thomas head | kyle korver | 
 | name | date opponent | troy murphy | 
 | height | 67 | height 67 | 
 | weight | 220 | weight 220 | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | name | humphries head | derrick favors | 
 | name | date opponent | shaquille oneal | 
 | name | now recommended | ben uzoh | 
 | height | 610 | height 610 | 
 | weight | 230 | weight 230 | 
 | name | date opponent | ronnie brewer | 
 | height | 67 | height 67 | 
 | weight | 220 | weight 220 | 
 | name | ely head | arron afflalo | 
 | height | 68 | height 68 | 
 | weight | 238 | weight 238 | 
 | height | 69 | height 69 | 
 | weight | 210 | weight 210 | 
 | height | 610 | height 610 | 
 | weight | 230 | weight 230 | 
 | name | powe head | anthony parker | 
 | name | house head | dexter pittman | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | weight | 366 lbs before enrolling at texas. 5 his weight still prevented him from doing basic drills in practice, which caused various back and knee aches. 5 pittman then dedicated himself to a workout program with wright, which included 530 am workouts and a complete revamp of his diet. | 308160lb 140 kg | 
 | height | 61 | height 61 | 
 | weight | 186 | weight 186 | 
 | name | okafor head | quincy pondexter | 
 | name | date opponent | jamal crawford | 
 | height | 70 | height 70 | 
 | weight | 250 | weight 250 | 
 | height | 67 | height 67 | 
 | weight | 218 | weight 218 | 
 | name | aldrich head | d. j. white | 
 | name | johnson award | jermaine oneal | 
 | team | trail blazers | boston celtics | 
 | name | now recommended | othyus jeffers | 
 | height | 611 | height 611 | 
 | weight | 232 | weight 232 | 
 | height | 65 | height 65 | 
 | weight | 220 | weight 220 | 
 | name | days rest | dominique jones | 
 | name | williams head | jameer nelson | 
 | name | date opponent | xavier henry | 
 | height | 67 | height 67 | 
 | weight | 210 | weight 210 | 
 | name | bill walton | lamarcus aldridge | 
 | height | 68 | height 68 | 
 | weight | 225 | weight 225 | 
 | name | now recommended | demar derozan | 
 | name | carlos boozer | paul millsap | 
 | name | tim duncan | dasean butler | 
 | name | date opponent | omer asik | 
 | team | clipper | charlotte bobcats | 
 | name | date opponent | sasha pavlovic | 
 | height | 66 | height 66 | 
 | weight | 210 | weight 210 | 
 | name | radmanović head | jeff adrien | 
 | name | randolph head | zach randolph | 
 | height | 69 | height 69 | 
 | weight | 225 | weight 225 | 
 | name | maxiell head | tayshaun prince | 
 | height | 6 ft 9 | 6160ft1609160in 2.06 m | 
 | name | gerald wallace | matt carroll | 
 | height | 610 | height 610 | 
 | weight | 250 | weight 250 | 
 | height | 65 | height 65 | 
 | weight | 200 | weight 200 | 
 | height | 66 | height 66 | 
 | weight | 185 | weight 185 | 
 | height | 62 | height 62 | 
 | weight | 175 | weight 175 | 
 | height | 69 | height 69 | 
 | weight | 240 | weight 240 | 
 | height | 610 | height 610 | 
 | weight | 240 | weight 240 | 
 | name | anderson varejao | anderson varejão | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | randolph head | rudy gay | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | team | chicago bulls | detroit pistons | 
 | name | livingston | shaun livingston | 
 | height | 610 | height 610 | 
 | weight | 215 | weight 215 | 
 | name | erden head | luke harangody | 
 | height | 65 | height 65 | 
 | weight | 205 | weight 205 | 
 | height | 64 | height 64 | 
 | weight | 195 | weight 195 | 
 | height | 60 | height 60 | 
 | weight | 175 | weight 175 | 
 | height | 60 | height 60 | 
 | weight | 190 | weight 190 | 
 | height | 66 | height 66 | 
 | weight | 215 | weight 215 | 
 | name | jackson head | samuel dalembert | 
 | height | 66 | height 66 | 
 | weight | 232 | weight 232 | 
 | height | 611 | height 611 | 
 | weight | 245 | weight 245 | 
 | height | 68 | height 68 | 
 | weight | 205 | weight 205 | 
 | height | 62 | height 62 | 
 | weight | 181 | weight 181 | 
 | name | randolph head | hasheem thabeet | 
 | name | kirilenko head | jeremy evans | 
 | height | 610 | height 610 | 
 | weight | 220 | weight 220 | 
 | name | ratliff head | derrick caracter | 
 | name | stevenson head | deshawn stevenson | 
 | name | jackson head | francisco garcía | 
 | name | williams head | udonis haslem | 
 | height | 6 ft 8 | 6160ft1608160in 2.03 m | 
 | height | 611 | height 611 | 
 | weight | 240 | weight 240 | 
 | name | now recommended | andre miller | 
 | height | 65 | height 65 | 
 | weight | 215 | weight 215 | 
 | name | dooling head | carlos delfino | 
 | name | chris kaman | brian cook | 
 | height | 70 | height 70 | 
 | weight | 245 | weight 245 | 
 | name | batum head | lamarcus aldridge | 
 | height | 62 | height 62 | 
 | weight | 175 | weight 175 | 
 | height | 66 | height 66 | 
 | weight | 220 | weight 220 | 
 | height | 67 | height 67 | 
 | weight | 235 | weight 235 | 
 | name | latrell sprewell | tim duncan | 
 | weight |  | 260160lb 118 kg | 
 | name | maxiell head | dajuan summers | 
 | name | batum head | brandon roy | 
 | name | now recommended | rashard lewis | 
 | height | 67 | height 67 | 
 | weight | 225 | weight 225 | 
 | height | 61 | height 61 | 
 | weight | 205 | weight 205 | 
 | name | now recommended | ekpe udoh | 
 | height | 71 | height 71 | 
 | weight | 250 | weight 250 | 
 | name | james posey | kirk hinrich | 
 | team | chicago bulls | washington wizards | 
 | name | batum head | rudy fernández | 
 | name | wei | boris diaw | 
 | weight | 230 lbs, diaw is a natural small forward . however, his passing skills and capability to score inside have earned him a reputation of being capable of playing all positions on the floor well. | 235160lb 107 kg | 
 | name | date opponent | derrick rose | 
 | height | 71 | height 71 | 
 | weight | 325 | weight 325 | 
 | name | now recommended | eduardo najera | 
 | name | now recommended | kevin love | 
 | height | 511 | height 511 | 
 | weight | 165 | weight 165 | 
 | name | jackson head | omri casspi | 
 | height | 62 | height 62 | 
 | weight | 180 | weight 180 | 
 | team | trail blazers | portland trail blazers | 
 | height | 68 | height 68 | 
 | weight | 227 | weight 227 | 
 | name | twitter previous | david lee | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | name | okafor head | trevor ariza | 
 | height | 65 | height 65 | 
 | weight | 220 | weight 220 | 
 | name | maxiell head | rodney stuckey | 
 | height | 60 | height 60 | 
 | weight | 185 | weight 185 | 
 | name | patterson head | ishmael smith | 
 | name | now recommended | dwight howard | 
 | height | 66 | height 66 | 
 | weight | 210 | weight 210 | 
 | height | 66 | height 66 | 
 | weight | 205 | weight 205 | 
 | height | 64 | height 64 | 
 | weight | 195 | weight 195 | 
 | height | 70 | height 70 | 
 | weight | 275 | weight 275 | 
 | name | tolliver head | luke ridnour | 
 | height | 66 | height 66 | 
 | weight | 179 | weight 179 | 
 | name | date opponent | joe smith | 
 | name | hibbert head | a. j. price | 
 | name | date opponent | dirk nowitzki | 
 | name | maxiell head | terrico white | 
 | height | 70 | height 70 | 
 | weight | 235 | weight 235 | 
 | name | patterson head | jermaine taylor | 
 | name | brandon roy | jon brockman | 
 | name | alabi head | leandro barbosa | 
 | name | curry head | shawne williams | 
 | height | 68 | height 68 | 
 | name | now recommended | hassan whiteside | 
 | name | hibbert head | t.j. ford | 
 | height | 611 | height 611 | 
 | weight | 245 | weight 245 | 
 | name | powe head | daniel gibson | 
 | height | 64 | height 64 | 
 | weight | 213 | weight 213 | 
 | height | 66 | height 66 | 
 | weight | 210 | weight 210 | 
 | name | curry head | toney douglas | 
 | name | chris paul | deron williams | 
 | height | 62 | height 62 | 
 | weight | 180 | weight 180 | 
 | name | oregon ducks | aaron brooks | 
 | name | now recommended | quincy pondexter | 
 | height | 610 | height 610 | 
 | weight | 290 | weight 290 | 
 | name | aldrich head | royal ivey | 
 | name | date opponent | deshawn stevenson | 
 | height | 611 | height 611 | 
 | weight | 253 | weight 253 | 
 | name | assist award | chris bosh | 
 | name | ratliff head | devin ebanks | 
 | height | 69 | height 69 | 
 | weight | 225 | weight 225 | 
 | height | 6 ft 9 | 6160ft1609160in 2.06 m | 
 | name | date opponent | erick dampier | 
 | height | 65 | height 65 | 
 | weight | 215 | weight 215 | 
 | height | 611 | height 611 | 
 | weight | 300 | weight 300 | 
 | height | 68 | height 68 | 
 | weight | 250 | weight 250 | 
 | name | now recommended | roger mason | 
 | name | now recommended | rodrigue beaubois | 
 | height | 67 | height 67 | 
 | weight | 212 | weight 212 | 
 | team | trail blazers | portland trail blazers | 
 | height | 70 | height 70 | 
 | weight | 285 | weight 285 | 
 | height | 68 | 6160ft1608160in 2.03 m | 
 | height | 70 | height 70 | 
 | weight | 285 | weight 285 | 
 | name | tolliver head | jonny flynn | 
 | height | 66 | height 66 | 
 | weight | 219 | weight 219 | 
 | height | 67 | height 67 | 
 | weight | 240 | weight 240 | 
 | name | alex english | ty lawson | 
 | height | 62 | height 62 | 
 | weight | 187 | weight 187 | 
 | height | 69 | height 69 | 
 | weight | 245 | weight 245 | 
 | height | 69 | height 69 | 
 | weight | 295 | weight 295 | 
 | height | 63 | height 63 | 
 | weight | 185 | weight 185 | 
 | height | 67 | height 67 | 
 | name | powe head | leon powe | 
 | name | now recommended | anthony carter | 
 | name | greg oden | marcus camby | 
 | name | corey brewer | jonny flynn | 
 | name | now recommended | paul george | 
 | height | 68 | height 68 | 
 | weight | 210 | weight 210 | 
 | height | 68 | height 68 | 
 | weight | 225 | weight 225 | 
 | height | 66 | height 66 | 
 | weight | 225 | weight 225 | 
 | name | now recommended | chauncey billups | 
 | name | deron williams | andrei kirilenko | 
 | name | now recommended | dante cunningham | 
 | name | kirilenko head | ronnie price | 
 | height | 63 | height 63 | 
 | weight | 178 | weight 178 | 
 | name | now recommended | derrick favors | 
 | height | 611 | height 611 | 
 | weight | 240 | weight 240 | 
 | name | maxiell head | chris wilcox | 
 | height | 60 | height 60 | 
 | weight | 205 | weight 205 | 
 | height | 55 | height 55 | 
 | weight | 135 | weight 135 | 
 | height | 611 | height 611 | 
 | weight | 235 | weight 235 | 
 | height | 63 | height 63 | 
 | weight | 200 | weight 200 | 
 | name | kirilenko head | raja bell | 
 | height | 60 | height 60 | 
 | weight | 175 | weight 175 | 
 | name | now recommended | shelden williams | 
 | name | now recommended | mickael pietrus | 
 | height | 68 | height 68 | 
 | weight | 220 | weight 220 | 
 | name | kirilenko head | gordon hayward | 
 | height | 511 1.80 | 6160ft1609160in 2.06 m | 
 | name | date opponent | byron mullens | 
 | height | 611 | height 611 | 
 | weight | 226 | weight 226 | 
 | team | golden state warriors | san antonio spurs | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | height | 67 | height 67 | 
 | weight | 215 | weight 215 | 
 | name | elton brand | darius songaila | 
 | name | date opponent | lebron james | 
 | height | 71 | height 71 | 
 | weight | 245 | weight 245 | 
 | height | 69 | height 69 | 
 | weight | 230 | weight 230 | 
 | height | 68 | height 68 | 
 | weight | 230 | weight 230 | 
 | name | now recommended | carmelo anthony | 
 | team | toronto raptors | denver nuggets | 
 | name | kirilenko head | kyrylo fesenko | 
 | name | ely head | j. r. smith | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | name | now recommended | kevin martin | 
 | height | 68 | height 68 | 
 | weight | 210 | weight 210 | 
 | height | 63 | height 63 | 
 | weight | 190 | weight 190 | 
 | height | 72 | height 72 | 
 | weight | 278 | weight 278 | 
 | name | powe head | ryan hollins | 
 | name | date opponent | shannon brown | 
 | height | 611 | height 611 | 
 | weight | 245 | weight 245 | 
 | name | curry head | timofey mozgov | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | name | ratliff head | pau gasol | 
 | name | date opponent | brendan haywood | 
 | name | batum head | sean marks | 
 | name | williams head | mickaël piétrus | 
 | name | alabi head | demar derozan | 
 | name | chris richard | corey brewer | 
 | height | 70 | height 70 | 
 | weight | 247 | weight 247 | 
 | name | curry head | landry fields | 
 | height | 65 | height 65 | 
 | weight | 210 | weight 210 | 
 | height | 68 | height 68 | 
 | weight | 245 | weight 245 | 
 | name | ratliff head | theo ratliff | 
 | height | 63 | height 63 | 
 | weight | 205 | weight 205 | 
 | team | golden state warriors | charlotte bobcats | 
 | name | english српски | dirk nowitzki | 
 | height | 610 | height 610 | 
 | weight | 240 | weight 240 | 
 | name | now recommended | aaron brooks | 
 | name | league draft | cartier martin | 
 | name | date opponent | lamar odom | 
 | height | 70 | height 70 | 
 | weight | 260 | weight 260 | 
 | team | los angeles lakers | new jersey nets | 
 | height | 611 | height 611 | 
 | weight | 250 | weight 250 | 
 | name | kapono head | spencer hawes | 
 | name | jose carleron | jerryd bayless | 
 | height | 63 | height 63 | 
 | weight | 200 | weight 200 | 
 | height | 60 | height 60 | 
 | weight | 190 | weight 190 | 
 | name | now recommended | gilbert arenas | 
 | name | hibbert head | josh mcroberts | 
 | height | 69 | height 69 | 
 | weight | 207 | weight 207 | 
 | name | humphries head | kris humphries | 
 | height | 611 | height 611 | 
 | weight | 225 | weight 225 | 
 | height | 68 | height 68 | 
 | weight | 233 | weight 233 | 
 | name | batum head | joel przybilla | 
 | name | radmanović head | rodney carney | 
 | name | radmanović head | vladimir radmanović | 
 | height | 611 | height 611 | 
 | weight | 273 | weight 273 | 
 | height | 61 | height 61 | 
 | weight | 190 | weight 190 | 
 | height | 70 | height 70 | 
 | weight | 280 | weight 280 | 
 | name | now recommended | dominic mcguire | 
 | name | now recommended | anthony tolliver | 
 | height | 64 | height 64 | 
 | weight | 215 | weight 215 | 
 | name | childress | josh childress | 
 | name | marcus camby 06.21.99 | marcus camby | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | house head | carlos arroyo | 
 | name | james johnson | taj gibson | 
 | height | 6 ft 9 | 6160ft1609160in 2.06 m | 
 | name | now recommended | jarrett jack | 
 | name | humphries head | troy murphy | 
 | name | now recommended | renaldo balkman | 
 | name | louis williams | lou williams | 
 | team | kirk snyder | memphis grizzlies | 
 | name | date opponent | eddie house | 
 | name | jefferson | shawn marion | 
 | name | date opponent | pape sy | 
 | name | patterson head | kyle lowry | 
 | height | 69 | height 69 | 
 | weight | 228 | weight 228 | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | height | 76 | height 76 | 
 | weight | 310 | weight 310 | 
 | name | now recommended | chris johnson | 
 | name | franchise record | gilbert arenas | 
 | name | marvin williams | raymond felton | 
 | height | 73 | height 73 | 
 | weight | 267 | weight 267 | 
 | name | date opponent | jamaal magloire | 
 | height | 71 | height 71 | 
 | weight | 265 | weight 265 | 
 | name | dooling head | drew gooden | 
 | team | san antonio spurs | milwaukee bucks | 
 | name | darko milicic | nikola pekovic | 
 | height | 611 | height 611 | 
 | weight | 290 | weight 290 | 
 | height | 67 | height 67 | 
 | weight | 255 | weight 255 | 
 | height | 67 | height 67 | 
 | weight | 228 | weight 228 | 
 | height | 69 | height 69 | 
 | weight | 253 | weight 253 | 
 | name | aldrich head | jeff green | 
 | height | 67 | height 67 | 
 | weight | 220 | weight 220 | 
 | name | date opponent | caron butler | 
 | height | 69 | height 69 | 
 | weight | 219 | weight 219 | 
 | height | 610 | height 610 | 
 | weight | 245 | weight 245 | 
 | height | 68 | height 68 | 
 | weight | 215 | weight 215 | 
 | height | 66 | height 66 | 
 | weight | 210 | weight 210 | 
 | name | date opponent | kevin garnett | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | name | now recommended | kyle lowry | 
 | name | patterson head | chase budinger | 
 | team | toronto raptors | new orleans hornets | 
 | name | date opponent | rasual butler | 
 | height | 61 | height 61 | 
 | weight | 190 | weight 190 | 
 | name | nate james | carlos boozer | 
 | name | now recommended | rodney stuckey | 
 | height | 66 | height 66 | 
 | weight | 225 | weight 225 | 
 | height | 62 | height 62 | 
 | weight | 205 | weight 205 | 
 | name | dooling head | keyon dooling | 
 | team | los angeles clippers | milwaukee bucks | 
 | height | 68 | height 68 | 
 | weight | 220 | weight 220 | 
 | height | 62 | height 62 | 
 | weight | 185 | weight 185 | 
 | height | 59 | height 59 | 
 | weight | 180 | weight 180 | 
 | name | jeter | pooh jeter | 
 | name | sebastian telfair | rajon rondo | 
 | name | now recommended | brook lopez | 
 | name | now recommended | terrence williams | 
 | name | charlotte | baron davis | 
 | height | 66 | height 66 | 
 | weight | 200 | weight 200 | 
 | name | date opponent | etan thomas | 
 | name | aldrich head | nick collison | 
 | name | date opponent | zach randolph | 
 | name | now recommended | jamario moon | 
 | height | 66 | height 66 | 
 | height | 67 | height 67 | 
 | weight | 205 | weight 205 | 
 | name | alabi head | reggie evans | 
 | height | 68 | height 68 | 
 | weight | 215 | weight 215 | 
 | name | nate robinson | quentin richardson | 
 | team | los angeles clippers | orlando magic | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | name | thomas head | keith bogans | 
 | team | charlotte bobcats | chicago bulls | 
 | height | 610 | height 610 | 
 | weight | 245 | weight 245 | 
 | name | most valuable | j. j. redick | 
 | team | chicago bulls | orlando magic | 
 | height | 6 ft 4 in 1.93 m listed | 6160ft1604160in 1.93 m | 
 | name | now recommended | desagana diop | 
 | height | 69 | height 69 | 
 | weight | 245 | weight 245 | 
 | name | tolliver head | darko miličić | 
 | name | okafor head | marcus thornton | 
 | height | 64 | height 64 | 
 | weight | 213 | weight 213 | 
 | name | thomas head | john lucas iii | 
 | team | oklahoma state cowboys | chicago bulls | 
 | height | 69 | height 69 | 
 | weight | 225 | weight 225 | 
 | height | 610 | height 610 | 
 | weight | 245 | weight 245 | 
 | height | 69 | height 69 | 
 | weight | 260 | weight 260 | 
 | name | date opponent | kobe bryant | 
 | height | 67 | height 67 | 
 | weight | 210 | weight 210 | 
 | height | 610 | height 610 | 
 | weight | 260 | weight 260 | 
 | name | clyde drexler | chuck hayes | 
 | name | thomas head | luol deng | 
 | height | 70 | height 70 | 
 | weight | 255 | weight 255 | 
 | name | slovenščina српски | carmelo anthony | 
 | name | kapono head | jrue holiday | 
 | name | stevenson head | tyson chandler | 
 | team | oklahoma city thunder | dallas mavericks | 
 | height | 69 | height 69 | 
 | name | chris bosh | amir johnson | 
 | name | butler head | alfarouq aminu | 
 | name | acquires center | al jefferson | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | name | ely head | nenê | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | team | boston celtics | orlando magic | 
 | height | 61 | height 61 | 
 | weight | 185 | weight 185 | 
 | name | date opponent | kyle korver | 
 | name | jefferson | lamar odom | 
 | name | chris paul | david west | 
 | name | date opponent | avery bradley | 
 | height | 71 | height 71 | 
 | weight | 280 | weight 280 | 
 | height | 610 | height 610 | 
 | weight | 240 | weight 240 | 
 | height | 63 | height 63 | 
 | weight | 220 | weight 220 | 
 | height | 70 | height 70 | 
 | weight | 250 | weight 250 | 
 | name | summer league | josé juan barea | 
 | height | 611 | height 611 | 
 | weight | 205 | weight 205 | 
 | name | date opponent | devin ebanks | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | date opponent | von wafer | 
 | name | lennie rosenbluth | tyler hansbrough | 
 | height | 611 | height 611 | 
 | weight | 270 | weight 270 | 
 | height | 70 | height 70 | 
 | weight | 256 | weight 256 | 
 | name | erden head | marquis daniels | 
 | height | 69 | 6160ft1606160in 1.98 m | 
 | height | 61 | height 61 | 
 | weight | 195 | weight 195 | 
 | height | 70 | height 70 | 
 | weight | 275 | weight 275 | 
 | name | humphries head | anthony morrow | 
 | height | 66 | height 66 | 
 | weight | 225 | weight 225 | 
 | name | humphries head | devin harris | 
 | team | washington wizards | new jersey nets | 
 | height | 66 | height 66 | 
 | weight | 220 | weight 220 | 
 | name | karl malone | jeremy evans | 
 | name | kapono head | elton brand | 
 | name | blair head | tiago splitter | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | now recommended | kyrylo fesenko | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | name | new orleans | brandon bass | 
 | height | 61 | height 61 | 
 | weight | 210 | weight 210 | 
 | name | date opponent | theo ratliff | 
 | name | charlie bell | morris peterson | 
 | name | now recommended | trevor booker | 
 | name | now recommended | dan gadzuric | 
 | height | 70 | height 70 | 
 | weight | 255 | weight 255 | 
 | height | 611 | height 611 | 
 | weight | 250 | weight 250 | 
 | name | javtokas | linas kleiza | 
 | name | humphries head | ben uzoh | 
 | name | kapono head | thaddeus young | 
 | name | now recommended | jermaine oneal | 
 | name | house head | erick dampier | 
 | height | 6 ft 11 | 6160ft16011160in 2.11 m | 
 | name | date opponent | kirk hinrich | 
 | height | 62 | height 62 | 
 | weight | 200 | weight 200 | 
 | height | 63 | height 63 | 
 | weight | 195 | weight 195 | 
 | team | portland trail blazers | minnesota timberwolves | 
 | height | 68 | height 68 | 
 | weight | 245 | weight 245 | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | height | 68 | height 68 | 
 | weight | 240 | weight 240 | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | name | radmanović head | david lee | 
 | name | date opponent | ron artest | 
 | name | kirilenko head | paul millsap | 
 | height | 66 | height 66 | 
 | weight | 220 | weight 220 | 
 | height | 610 | height 610 | 
 | weight | 229 | weight 229 | 
 | name | butler head | deandre jordan | 
 | name | date opponent | john lucas | 
 | height | 68 | height 68 | 
 | weight | 230 | weight 230 | 
 | name | okafor head | willie green | 
 | name | anthony parker | andrea bargnani | 
 | name | now recommended | carl landry | 
 | name | orton | daniel orton | 
 | height | 64 | height 64 | 
 | weight | 210 | weight 210 | 
 | name | date opponent | dwyane wade | 
 | name | date opponent | rudy gay | 
 | height | 67 | height 67 | 
 | weight | 210 | weight 210 | 
 | height | 65 | height 65 | 
 | weight | 210 | weight 210 | 
 | name | radmanović head | brandan wright | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | name | manu ginobili | matt bonner | 
 | height | 611 | height 611 | 
 | weight | 250 | weight 250 | 
 | name | blair head | richard jefferson | 
 | name | butler head | randy foye | 
 | name | derek anderson | nazr mohammed | 
 | team | atlanta hawks | charlotte bobcats | 
 | height | 63 | height 63 | 
 | weight | 200 | weight 200 | 
 | name | jefferson | amare stoudemire | 
 | height | 65 | height 65 | 
 | weight | 200 | weight 200 | 
 | name | curry head | kelenna azubuike | 
 | height | 611 | height 611 | 
 | weight | 265 | weight 265 | 
 | name | hibbert head | paul george | 
 | height | 611 | height 611 | 
 | weight | 255 | weight 255 | 
 | height | 61 | height 61 | 
 | weight | 185 | weight 185 | 
 | height | 70 | height 70 | 
 | weight | 265 | weight 265 | 
 | name | now recommended | johan petro | 
 | height | 60 | height 60 | 
 | weight | 180 | weight 180 | 
 | height | 65 | height 65 | 
 | weight | 210 | weight 210 | 
 | name | matt gorman | hakim warrick | 
 | name | date opponent | c.j. watson | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | height | 69 | height 69 | 
 | weight | 251 | weight 251 | 
 | name | date opponent | leon powe | 
 | height | 66 | height 66 | 
 | weight | 225 | weight 225 | 
 | name | ratliff head | shannon brown | 
 | team | charlotte bobcats | los angeles lakers | 
 | name | twitter previous | dan gadzuric | 
 | height | 611 | height 611 | 
 | weight | 245 | weight 245 | 
 | name | stevenson head | steve novak | 
 | name | powe head | manny harris | 
 | height | 68 | height 68 | 
 | weight | 270 | weight 270 | 
 | name | now recommended | jonas jerebko | 
 | height | 66 | height 66 | 
 | weight | 215 | weight 215 | 
 | height | 67 | height 67 | 
 | weight | 210 | weight 210 | 
 | name | now recommended | andy rautins | 
 | name | songaila | darius songaila | 
 | name | now recommended | joakim noah | 
 | height | 69 | height 69 | 
 | weight | 265 | weight 265 | 
 | height | 66 | height 66 | 
 | weight | 230 | weight 230 | 
 | height | 70 | height 70 | 
 | weight | 275 | weight 275 | 
 | name | brian davis | grant hill | 
 | name | maxiell head | jonas jerebko | 
 | height | 611 | height 611 | 
 | weight | 265 | weight 265 | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | name | date opponent | james jones | 
 | height | 68 | height 68 | 
 | weight | 235 | weight 235 | 
 | name | now recommended | jermaine taylor | 
 | height | 68 | height 68 | 
 | weight | 235 | weight 235 | 
 | name | date opponent | mike conley | 
 | name | date opponent | nenad krstic | 
 | name | patterson head | luis scola | 
 | height | 610 | height 610 | 
 | weight | 240 | weight 240 | 
 | name | now recommended | robin lopez | 
 | name | now recommended | tyson chandler | 
 | name | hibbert head | jeff foster | 
 | name | clark head | earl clark | 
 | name | matt wong | jeremy lin | 
 | name | days rest | carlos boozer | 
 | name | tolliver head | michael beasley | 
 | name | humphries head | quinton ross | 
 | height | 62 | height 62 | 
 | weight | 175 | weight 175 | 
 | name | kirilenko head | francisco elson | 
 | name | brandon jennings | drew gooden | 
 | height | 67 | height 67 | 
 | weight | 227 | weight 227 | 
 | name | kapono head | jason kapono | 
 | height | 64 | height 64 | 
 | weight | 210 | weight 210 | 
 | height | 69 | height 69 | 
 | weight | 266 | weight 266 | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | height | 72 | height 72 | 
 | weight | 265 | weight 265 | 
 | name | curry head | anthony randolph | 
 | height | 62 | height 62 | 
 | weight | 185 | weight 185 | 
 | team | trail blazers | portland trail blazers | 
 | height | 68 | height 68 | 
 | weight | 210 | weight 210 | 
 | height | 69 | height 69 | 
 | weight | 250 | weight 250 | 
 | height | 611 | height 611 | 
 | weight | 250 | weight 250 | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | height | 611 | height 611 | 
 | weight | 232 | weight 232 | 
 | height | 68 | height 68 | 
 | weight | 210 | weight 210 | 
 | height | 63 | height 63 | 
 | weight | 202 | weight 202 | 
 | name | now recommended | deandre jordan | 
 | height | 66 | height 66 | 
 | weight | 215 | weight 215 | 
 | name | now recommended | wayne ellington | 
 | name | hibbert head | danny granger | 
 | height | 69 | height 69 | 
 | weight | 188 | weight 188 | 
 | name | patterson head | jordan hill | 
 | name | now recommended | louis amundson | 
 | height | 68 | height 68 | 
 | weight | 215 | weight 215 | 
 | name | ratliff head | sasha vujačić | 
 | name | now recommended | dj white | 
 | name | date opponent | carlos arroyo | 
 | name | butler head | ryan gomes | 
 | team | minnesota timberwolves | los angeles clippers | 
 | name | now recommended | t.j. ford | 
 | name | now recommended | jason kapono | 
 | height | 70 | height 70 | 
 | weight | 245 | weight 245 | 
 | name | now recommended | lance stephenson | 
 | height | 611 | height 611 | 
 | weight | 260 | weight 260 | 
 | name | aldrich head | thabo sefolosha | 
 | height | 66 | height 66 | 
 | weight | 228 | weight 228 | 
 | name | now recommended | luke harangody | 
 | name | dooling head | brandon jennings | 
 | name | clark head | robin lopez | 
 | name | jason thompson | jeff teague | 
 | height | 62 | height 62 | 
 | weight | 180 | weight 180 | 
 | height | 63 | height 63 | 
 | weight | 207 | weight 207 | 
 | name | now recommended | dejuan blair | 
 | height | 65 | height 65 | 
 | weight | 220 | weight 220 | 
 | height | 68 | height 68 | 
 | weight | 217 | weight 217 | 
 | name | cholet basket | kevin seraphin | 
 | name | now recommended | toney douglas | 
 | height | 64 | height 64 | 
 | weight | 210 | weight 210 | 
 | name | powe head | samardo samuels | 
 | height | 66 | height 66 | 
 | weight | 205 | weight 205 | 
 | height | 61 | height 61 | 
 | weight | 190 | weight 190 | 
 | name | date opponent | darrell arthur | 
 | name | harrington | al harrington | 
 | name | dooling head | andrew bogut | 
 | height | 66 | height 66 | 
 | weight | 215 | weight 215 | 
 | height | 63 | height 63 | 
 | weight | 200 | weight 200 | 
 | name | now recommended | ramon sessions | 
 | name | aldrich head | byron mullens | 
 | height | 70 | height 70 | 
 | weight | 270 | weight 270 | 
 | name | jamel thomas | sebastian telfair | 
 | height | 63 | height 63 | 
 | weight | 200 | weight 200 | 
 | name | kapono head | jodie meeks | 
 | name | patterson head | kevin martin | 
 | name | ely head | anthony carter | 
 | height | 73 | height 73 | 
 | weight | 260 | weight 260 | 
 | height | 67 | height 67 | 
 | weight | 205 | weight 205 | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | name | aldrich head | daequan cook | 
 | name | date opponent | dexter pittman | 
 | height | 611 | height 611 | 
 | weight | 230 | weight 230 | 
 | name | now recommended | nikola pekovic | 
 | name | now recommended | nick young | 
 | height | 68 | height 68 | 
 | weight | 245 | weight 245 | 
 | height | 61 | height 61 | 
 | weight | 175 | weight 175 | 
 | height | 69 | height 69 | 
 | weight | 240 | weight 240 | 
 | name | date opponent | brian scalabrine | 
 | height | 67 | height 67 | 
 | weight | 260 | weight 260 | 
 | height | 64 | height 64 | 
 | weight | 208 | weight 208 | 
 | height | 69 | height 69 | 
 | weight | 245 | weight 245 | 
 | name | date opponent | eric maynor | 
 | height | 64 | height 64 | 
 | weight | 205 | weight 205 | 
 | name | kirilenko head | earl watson | 
 | height | 70 | height 70 | 
 | weight | 240 | weight 240 | 
 | height | 65 | height 65 | 
 | weight | 215 | weight 215 | 
 | name | randolph head | greivis vasquez | 
 | height | 62 | height 62 | 
 | weight | 195 | weight 195 | 
 | name | miles simon | jason terry | 
 | name | williams head | daniel orton | 
 | name | date opponent | jason kidd | 
 | name | now recommended | courtney lee | 
 | name | date opponent | corey brewer | 
 | height | 67 | height 67 | 
 | weight | 210 | weight 210 | 
 | name | alabi head | joey dorsey | 
 | name | butler head | blake griffin | 
 | name | now recommended | richard hamilton | 
 | height | 610 | height 610 | 
 | weight | 245 | weight 245 | 
 | name | date opponent | peja stojakovic | 
 | name | date opponent | al horford | 
 | height | 69 | height 69 | 
 | weight | 248 | weight 248 | 
 | name | twitter previous | brandon roy | 
 | team | trail blazers | portland trail blazers | 
 | height | 66 | height 66 | 
 | weight | 211 | weight 211 | 
 | height | 65 | height 65 | 
 | name | date opponent | james harden | 
 | height | 65 | height 65 | 
 | weight | 220 | weight 220 | 
 | height | 64 | height 64 | 
 | weight | 215 | weight 215 | 
 | height | 63 | height 63 | 
 | weight | 201 | weight 201 | 
 | height | 68 | height 68 | 
 | weight | 250 | weight 250 | 
 | name | twitter previous | dominic mcguire | 
 | height | 69 | height 69 | 
 | weight | 235 | weight 235 | 
 | height | 610 | height 610 | 
 | weight | 225 | weight 225 | 
 | name | miller | brad miller | 
 | height | 611 | height 611 | 
 | weight | 270 | weight 270 | 
 | name | jackson head | demarcus cousins | 
 | name | date opponent | hilton armstrong | 
 | height | 67 | height 67 | 
 | weight | 225 | weight 225 | 
 | height | 67 | height 67 | 
 | weight | 226 | weight 226 | 
 | height | 68 | height 68 | 
 | weight | 210 | weight 210 | 
 | name | now recommended | kurt thomas | 
 | name | hibbert head | darren collison | 
 | name | now recommended | raymond felton | 
 | name | alabi head | andrea bargnani | 
 | name | date opponent | robert vaden | 
 | height | 63 | height 63 | 
 | weight | 172 | weight 172 | 
 | name | hibbert head | roy hibbert | 
 | height | 68 | height 68 | 
 | weight | 240 | weight 240 | 
 | height | 69 | height 69 | 
 | weight | 230 | weight 230 | 
 | name | humphries head | damion james | 
 | name | now recommended | hasheem thabeet | 
 | name | humphries head | brook lopez | 
 | name | curry head | bill walker | 
 | team | boston celtics | new york knicks | 
 | height | 63 | height 63 | 
 | weight | 170 | weight 170 | 
 | height | 610 | height 610 | 
 | weight | 235 | weight 235 | 
 | name | marcus williams | hilton armstrong | 
 | team | houston rockets | washington wizards | 
 | name | butler head | eric bledsoe | 
 | height | 67 | height 67 | 
 | weight | 215 | weight 215 | 
 | name | date opponent | jason terry | 
 | name | josh smith | wilson chandler | 
 | weight | 220 lbs. | 220160lb 100 kg | 
 | name | humphries head | travis outlaw | 
 | height | 69 | 6160ft1609160in 2.06 m | 
 | height | 610 | height 610 | 
 | weight | 280 | weight 280 | 
 | name | thomas head | c.j. watson | 
 | name | twitter previous | kenyon martin | 
 | height | 69 | height 69 | 
 | weight | 230 | weight 230 | 
 | name | personal life | martell webster | 
 | height | 6 7 2.01 | 6160ft1607160in 2.01 m | 
 | height | 611 | height 611 | 
 | weight | 235 | weight 235 | 
 | name | randolph head | o. j. mayo | 
 | height | 60 | height 60 | 
 | weight | 175 | weight 175 | 
 | name | hibbert head | brandon rush | 
 | name | karl malone | raja bell | 
 | name | date opponent | daequan cook | 
 | name | now recommended | andres nocioni | 
 | height | 610 | height 610 | 
 | weight | 255 | weight 255 | 
 | name | chris bosh | reggie evans | 
 | height | 67 | height 67 | 
 | weight | 185 | weight 185 | 
 | team | toronto raptors | orlando magic | 
 | name | maxiell head | jason maxiell | 
 | name | randolph head | marc gasol | 
 | name | erden head | nate robinson | 
 | height | 68 | height 68 | 
 | weight | 240 | weight 240 | 
 | name | erden head | ray allen | 
 | height | 611 | height 611 | 
 | weight | 240 | weight 240 | 
 | height | 66 | height 66 | 
 | weight | 211 | weight 211 | 
 | name | curry head | danilo gallinari | 
 | name | andersen | david andersen | 
 | height | 610 | height 610 | 
 | weight | 220 | weight 220 | 
 | name | williams head | earl barron | 
 | height | 69 | height 69 | 
 | weight | 240 | weight 240 | 
 | height | 64 | height 64 | 
 | weight | 210 | weight 210 | 
 | height | 68 | height 68 | 
 | weight | 268 | weight 268 | 
 | name | radmanović head | ekpe udoh | 
 | name | date opponent | ishmael smith | 
 | height | 68 | height 68 | 
 | weight | 241 | weight 241 | 
 | height | 66 | height 66 | 
 | weight | 207 | weight 207 | 
 | height | 70 | height 70 | 
 | weight | 255 | weight 255 | 
 | name | now recommended | jason richardson | 
 | name | tolliver head | kosta koufos | 
 | height | 66 | height 66 | 
 | weight | 207 | weight 207 | 
 | name | mo williams | maurice williams | 
 | weight |  | 195160lb 88 kg | 
 | name | date opponent | luol deng | 
 | name | jackson head | carl landry | 
 | height | 69 | height 69 | 
 | weight | 207 | weight 207 | 
 | name | aldrich head | nenad krstić | 
 | name | roger mason | roger mason jr. | 
 | height | 65 | height 65 | 
 | weight | 205 | weight 205 | 
 | name | thomas head | ömer aşık | 
 | name | chris richard | marreese speights | 
 | height | 6 ft 10 | 6160ft16010160in 2.08 m | 
 | name | butler head | craig smith | 
 | name | ely head | melvin ely | 
 | team | los angeles clippers | denver nuggets | 
 | name | marić | patrick mills | 
 | name | david west | dj mbenga | 
 | name | date opponent | shawn marion | 
 | name | now recommended | al thornton | 
 | name | thomas head | ronnie brewer | 
 | height | 610 | height 610 | 
 | weight | 230 | weight 230 | 
 | name | date opponent | udonis haslem | 
 | height | 63 | height 63 | 
 | weight | 190 | weight 190 | 
 | height | 64 | height 64 | 
 | weight | 190 | weight 190 | 
 | name | now recommended | a.j. price | 
 | height | 66 | height 66 | 
 | weight | 205 | weight 205 | 
