# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 7.66 | 1.2 | 0.92 | 0.4 | 
| team | 13.47 | 1.92 | 1.63 | 0.15 | 
| height | 1.72 | 0.77 | 0.71 | 0.29 | 
| weight | 2.56 | 0.77 | 0.68 | 0.32 | 


