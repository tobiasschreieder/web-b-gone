# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | name | wayne ellington | wayne ellington jr. | 
 | team | los angeles clippers | philadelphia 76ers | 
 | name | ersan ilyasova | ersan i̇lyasova | 
 | team | oklahoma city thunder | philadelphia 76ers | 
 | name | jose juan | jose juan barea | 
 | name | davis davis | ed davis | 
 | name | rudy fernandez | rudy fernández | 
 | name | luc richard mbah a moute | luc richard mbah a moute 12 sf | 
