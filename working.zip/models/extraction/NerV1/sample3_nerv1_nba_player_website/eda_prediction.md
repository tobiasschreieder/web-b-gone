# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.33 | 2.31 | 1.39 | 0.01 | 
| team | 13.27 | 1.9 | 1.35 | 0.11 | 
| height | 3.42 | 1.31 | 0.91 | 0.09 | 
| weight | 5.79 | 1.51 | 0.91 | 0.09 | 


