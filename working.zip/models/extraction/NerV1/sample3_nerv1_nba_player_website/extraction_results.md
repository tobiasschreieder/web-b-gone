# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: 2000
* Train-Test-Split: 0.7
* Seed: sample3
* Name: sample3_nerv1_nba_player_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9218 | 0.922 |
| F1 | 0.9222 | 0.9224 |
| Partial Match | 0.9225 | 0.9225 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.92 | 0.9208 |
| F1 | 0.9216 | 0.9221 |
| Partial Match | 0.9217 | 0.9221 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9929 | 0.9929 |
| F1 | 0.9945 | 0.9945 |
| Partial Match | 0.995 | 0.995 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9817 | 0.985 |
| F1 | 0.9882 | 0.9899 |
| Partial Match | 0.9883 | 0.99 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8993 | 0.8993 |
| F1 | 0.8993 | 0.8993 |
| Partial Match | 0.8993 | 0.8993 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.885 | 0.885 |
| F1 | 0.885 | 0.885 |
| Partial Match | 0.885 | 0.885 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8971 | 0.8979 |
| F1 | 0.8971 | 0.8979 |
| Partial Match | 0.8979 | 0.8979 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9067 | 0.9067 |
| F1 | 0.9067 | 0.9067 |
| Partial Match | 0.9067 | 0.9067 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8979 | 0.8979 |
| F1 | 0.8979 | 0.8979 |
| Partial Match | 0.8979 | 0.8979 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9067 | 0.9067 |
| F1 | 0.9067 | 0.9067 |
| Partial Match | 0.9067 | 0.9067 |
