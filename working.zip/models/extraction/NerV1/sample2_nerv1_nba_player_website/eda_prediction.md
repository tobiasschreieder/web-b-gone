# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.29 | 2.25 | 1.43 | 0.01 | 
| team | 12.83 | 1.85 | 1.26 | 0.13 | 
| height | 3.67 | 1.35 | 0.92 | 0.08 | 
| weight | 6.21 | 1.59 | 0.92 | 0.08 | 


