# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: 2000
* Train-Test-Split: 0.7
* Seed: sample2
* Name: sample2_nerv1_nba_player_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.922 | 0.922 |
| F1 | 0.9222 | 0.9222 |
| Partial Match | 0.9223 | 0.9223 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9208 | 0.9225 |
| F1 | 0.9214 | 0.923 |
| Partial Match | 0.9213 | 0.9229 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9943 | 0.9943 |
| F1 | 0.9953 | 0.9953 |
| Partial Match | 0.9957 | 0.9957 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.99 | 0.9917 |
| F1 | 0.9913 | 0.993 |
| Partial Match | 0.9917 | 0.9933 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8864 | 0.8864 |
| F1 | 0.8864 | 0.8864 |
| Partial Match | 0.8864 | 0.8864 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.86 | 0.865 |
| F1 | 0.8608 | 0.8658 |
| Partial Match | 0.86 | 0.865 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9036 | 0.9036 |
| F1 | 0.9036 | 0.9036 |
| Partial Match | 0.9036 | 0.9036 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9167 | 0.9167 |
| F1 | 0.9167 | 0.9167 |
| Partial Match | 0.9167 | 0.9167 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9036 | 0.9036 |
| F1 | 0.9036 | 0.9036 |
| Partial Match | 0.9036 | 0.9036 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9167 | 0.9167 |
| F1 | 0.9167 | 0.9167 |
| Partial Match | 0.9167 | 0.9167 |
