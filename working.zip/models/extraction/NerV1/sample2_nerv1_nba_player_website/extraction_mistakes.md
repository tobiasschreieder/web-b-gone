# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | oklahoma city thunder | philadelphia 76ers | 
 | team | grizzly | heat | 
 | team | phoenix suns | san antonio spurs | 
 | team | philadelphia 62 | philadelphia 76ers | 
 | name | d.j. mbenga | didier ilungambenga | 
 | name | wayne ellington | wayne ellington jr. | 
 | team | celtic | grizzly | 
