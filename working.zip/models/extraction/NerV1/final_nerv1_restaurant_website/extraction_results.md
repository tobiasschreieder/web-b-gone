# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.RESTAURANT
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_nerv1_restaurant_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9307 | 0.9447 |
| F1 | 0.9441 | 0.956 |
| Partial Match | 0.9386 | 0.9508 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9255 | 0.9413 |
| F1 | 0.9447 | 0.957 |
| Partial Match | 0.9381 | 0.9516 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8223 | 0.8297 |
| F1 | 0.8547 | 0.8595 |
| Partial Match | 0.8357 | 0.8404 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8217 | 0.8365 |
| F1 | 0.8671 | 0.8741 |
| Partial Match | 0.8431 | 0.8523 |
## Attribute Prediction: Address
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9738 | 0.9781 |
| F1 | 0.9864 | 0.9898 |
| Partial Match | 0.9849 | 0.9884 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9544 | 0.9579 |
| F1 | 0.9764 | 0.9788 |
| Partial Match | 0.9758 | 0.9781 |
## Attribute Prediction: Phone
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.993 | 0.9935 |
| F1 | 0.9944 | 0.9946 |
| Partial Match | 0.9948 | 0.9948 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9925 | 0.9927 |
| F1 | 0.9939 | 0.9939 |
| Partial Match | 0.9944 | 0.9944 |
## Attribute Prediction: Cuisine
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9336 | 0.9774 |
| F1 | 0.9407 | 0.9801 |
| Partial Match | 0.9389 | 0.9797 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9335 | 0.9779 |
| F1 | 0.9413 | 0.981 |
| Partial Match | 0.9392 | 0.9815 |
