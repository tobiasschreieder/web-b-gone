# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.RESTAURANT

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 14.01 | 2.24 | 1.89 | 0.08 | 
| address | 23.34 | 4.51 | 1.26 | 0.01 | 
| phone | 10.47 | 1.48 | 1.09 | 0.01 | 
| cuisine | 11.53 | 1.44 | 1.26 | 0.02 | 


