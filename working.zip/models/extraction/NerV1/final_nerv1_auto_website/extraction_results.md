# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.AUTO
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_nerv1_auto_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8982 | 0.908 |
| F1 | 0.8848 | 0.8938 |
| Partial Match | 0.8845 | 0.8936 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8973 | 0.9085 |
| F1 | 0.8848 | 0.8941 |
| Partial Match | 0.8845 | 0.8938 |
## Attribute Prediction: Model
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8427 | 0.8472 |
| F1 | 0.8477 | 0.8486 |
| Partial Match | 0.847 | 0.8482 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8347 | 0.8436 |
| F1 | 0.8453 | 0.8469 |
| Partial Match | 0.8452 | 0.8466 |
## Attribute Prediction: Price
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9556 | 0.9557 |
| F1 | 0.9556 | 0.9557 |
| Partial Match | 0.9556 | 0.9557 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.96 | 0.9603 |
| F1 | 0.9602 | 0.9603 |
| Partial Match | 0.96 | 0.9603 |
## Attribute Prediction: Engine
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8858 | 0.8858 |
| F1 | 0.8878 | 0.8878 |
| Partial Match | 0.8874 | 0.8874 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8852 | 0.8852 |
| F1 | 0.887 | 0.887 |
| Partial Match | 0.8861 | 0.8861 |
## Attribute Prediction: Fuel_economy
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9086 | 0.9433 |
| F1 | 0.8482 | 0.8829 |
| Partial Match | 0.8482 | 0.8829 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9093 | 0.9449 |
| F1 | 0.8468 | 0.8824 |
| Partial Match | 0.8468 | 0.8824 |
