# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.AUTO

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| model | 22.48 | 3.83 | 1.2 | 0.15 | 
| price | 8.56 | 2.03 | 1.07 | 0.04 | 
| engine | 22.43 | 5.41 | 0.96 | 0.11 | 
| fuel_economy | 13.8 | 3.7 | 1.04 | 0.15 | 


