# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | engine | 3. 6l v 6 vvt | 3.6l v 6 vvt | 
 | engine | 3.5l 27 6 hp v 6 | 3.5l 276 hp v 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 1.8l 1 40 hp i 4 | 1.8l 140 hp i 4 | 
 | fuel_economy |  | 12 mpg city 17 mpg hwy | 
 | fuel_economy |  | 15 mpg city 20 mpg hwy | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 2. 4l mivec dohc i 4 | 2.4l mivec dohc i 4 | 
 | model | 2010 chevrolet suburban | 2010 chevrolet suburban 1500 | 
 | fuel_economy |  | 27 mpg city 36 mpg hwy | 
 | engine | 3. 6l 288 hp v 6 | 3.6l 288 hp v 6 | 
 | model | 2010 nissan gtr | 2010 nissan gtr base coupe | 
 | engine | engine 3. 6l subaru boxer horizontally opposed 6 dohc with variable valve timing and four valves per cylinder | engine 3.6l subaru boxer horizontally opposed 6 dohc with variable valve timing and four valves per cylinder | 
 | engine | 500hp, 6. 8liter v 8 premium | 500hp, 6.8liter v 8 premium | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | engine | 1 40hp, 2.0liter i 4 diesel | 140hp, 2.0liter i 4 diesel | 
 | engine | 2. 4l 169 hp i 4 | 2.4l 169 hp i 4 | 
 | fuel_economy |  | 17 mpg city 24 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 18 mpg city 25 mpg hwy | 
 | engine | 3. 6l v 6 dohc | 3.6l v 6 dohc | 
 | fuel_economy |  | 14 mpg city 18 mpg hwy | 
 | engine | 2. 4l 175 hp i 4 | 2.4l 175 hp i 4 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | model | 2011 toyota sienna se 8passenger | 2011 toyota sienna se 8passenger minivan | 
 | fuel_economy |  | 15 mpg city 19 mpg hwy | 
 | engine | 1 40hp, 2.0liter i 4 diesel | 140hp, 2.0liter i 4 diesel | 
 | fuel_economy |  | 22 mpg city 25 mpg hwy | 
 | engine | 161hp, 2. 4liter i 4 regular gas | 161hp, 2.4liter i 4 regular gas | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | model | 2010 bmw x 5 3 5d sport utility | 2010 bmw x 5 35d sport utility | 
 | fuel_economy |  | 12 mpg city 17 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 5.5l directinjection | 5.5l directinjection biturbo v 8 | 
 | model | 2010 ford explorer sport trac 4 | 2010 ford explorer sport trac highlights | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | engine 3. 6l v 6 dohc with variable valve timing and four valves per cylinder | engine 3.6l v 6 dohc with variable valve timing and four valves per cylinder | 
 | fuel_economy |  | 18 mpg city 24 mpg hwy | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 2. 4l 161 hp i 4 | 2.4l 161 hp i 4 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | engine | 3. 6l vr 6 | 3.6l vr 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 2010 audi s 5 4.2 premium plus coupe | 2010 audi s 5 | 
 | fuel_economy |  | 22 mpg city 27 mpg hwy | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | fuel_economy |  | 21 mpg city 27 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 22 mpg city 32 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 345hp, 3. 6liter h 6 premium | 345hp, 3.6liter h 6 premium | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l 166 hp i 4 | 2.4l 166 hp i 4 | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 6.2l 63 8 hp v 8 | 6.2l 638 hp v 8 | 
 | engine | 2. 4l 182 hp i 4 | 2.4l 182 hp i 4 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 2. 4l 190 hp i 4 | 2.4l 190 hp i 4 | 
 | fuel_economy |  | 18 mpg city 24 mpg hwy | 
 | model | 2010 mini cooper | 2010 mini cooper s clubman | 
 | engine | 2. 5l 1 50 hp i 5 | 2.5l 150 hp i 5 | 
 | engine | 3.8l 2 65 hp v 6 | 3.8l 265 hp v 6 | 
 | engine | 3. 6l 288 hp v 6 | 3.6l 288 hp v 6 | 
 | fuel_economy |  | 18 mpg city 26 mpg hwy | 
 | engine | 180hp, 2. 4liter i 4 regular gas | 180hp, 2.4liter i 4 regular gas | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | model | 2011 lexus es | 2011 lexus es 350 | 
 | engine | 2 68hp, 3.5liter v 6 regular gas | 268hp, 3.5liter v 6 regular gas | 
 | engine | 173hp, 2. 4liter i 4 regular gas | 173hp, 2.4liter i 4 regular gas | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | fuel_economy |  | 26 mpg city 31 mpg hwy | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | engine | 30 6hp, 3.5liter v 6 premium | 306hp, 3.5liter v 6 premium | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 3. 6l 25 6 hp h 6 | 3.6l 256 hp h 6 | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | engine 5.0l v 8 double overhead cam with vvt 1 1.5 1 compression ratio four valves per cylinder | engine 5.0l v 8 double overhead cam with vvt 11.5 1 compression ratio four valves per cylinder | 
 | fuel_economy |  | 16 mpg city 22 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 4.6l 24 8 hp v 8 | 4.6l 248 hp v 8 | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 3.8l 30 6 hp v 6 | 3.8l 306 hp v 6 | 
 | engine | engine 1.6l inline 4 double overhead cam with vvt 1 1.0 1 compression ratio four valves per cylinder | engine 1.6l inline 4 double overhead cam with vvt 11.0 1 compression ratio four valves per cylinder | 
 | fuel_economy |  | 20 mpg city 23 mpg hwy | 
 | engine | 3.8l 2 65 hp v 6 | 3.8l 265 hp v 6 | 
 | engine | 2. 4l 180 hp i 4 | 2.4l 180 hp i 4 | 
 | engine | 3.5l 2 6 6 hp v 6 | 3.5l 266 hp v 6 | 
 | fuel_economy |  | 28 mpg city 34 mpg hwy | 
 | model | 2011 mercedesbenz | 2011 mercedesbenz eclass | 
 | engine | 3. 6l 302 hp v 6 | 3.6l 302 hp v 6 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | engine 4. 8l vortec v 8 ohv and two valves per cylinder | engine 4.8l vortec v 8 ohv and two valves per cylinder | 
 | engine | 168hp, 2. 4liter i 4 regular gas | 168hp, 2.4liter i 4 regular gas | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 3.0l 2 65 hp i 6 | 3.0l 265 hp i 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | 2. 4l 16valve dohc ivtec i 4 | 2.4l 16valve dohc ivtec i 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 25 mpg city 37 mpg hwy | 
 | engine | 2.0l 1 42 hp i 4 | 2.0l 142 hp i 4 | 
 | engine | 3. 6l 281 hp v 6 | 3.6l 281 hp v 6 | 
 | fuel_economy |  | 14 mpg city 19 mpg hwy | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | fuel_economy |  | 28 mpg city 34 mpg hwy | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 21 mpg city 27 mpg hwy | 
 | fuel_economy |  | 21 mpg city 22 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | model | 2011 kia sorento | 2011 infiniti ex | 
 | engine | 6.2l 3 85 hp v 8 | 6.2l 385 hp v 8 | 
 | model | 2010 saab 93 4 | 2010 saab 93 highlights | 
 | fuel_economy |  | 21 mpg city 31 mpg hwy | 
 | model | 2011 toyota sienna | 2011 toyota sienna base minivan | 
 | engine | 24 8hp, 4.6liter v 8 regular gas | 248hp, 4.6liter v 8 regular gas | 
 | engine | engine 4.7l v 8 double overhead cam with vvt 1 1.3 1 compression ratio four valves per cylinder | engine 4.7l v 8 double overhead cam with vvt 11.3 1 compression ratio four valves per cylinder | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 3. 6l 280 hp v 6 | 3.6l 280 hp v 6 | 
 | engine | 2 60hp, 3.0liter i 6 premium | 260hp, 3.0liter i 6 premium | 
 | fuel_economy |  | 21 mpg city 29 mpg hwy | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | 2. 4l 166 hp i 4 | 2.4l 166 hp i 4 | 
 | fuel_economy |  | 14 mpg city 19 mpg hwy | 
 | fuel_economy |  | 14 mpg city 18 mpg hwy | 
 | engine | 5cyl, lp | 5cyl, lp turbo, 2.5 liter | 
 | fuel_economy |  | 19 mpg city 28 mpg hwy | 
 | engine | 2.5l 22 4 hp h 4 | 2.5l 224 hp h 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 30 mpg city 28 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 20 mpg city 29 mpg hwy | 
 | engine | 2. 5l 227 hp i 5 | 2.5l 227 hp i 5 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 2. 5l 227 hp i 5 | 2.5l 227 hp i 5 | 
 | fuel_economy |  | 18 mpg city 26 mpg hwy | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | fuel_economy |  | 12 mpg city 17 mpg hwy | 
 | fuel_economy |  | 16 mpg city 24 mpg hwy | 
 | fuel_economy |  | 20 mpg city 27 mpg hwy | 
 | fuel_economy |  | 21 mpg city 31 mpg hwy | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | fuel_economy |  | 28 mpg city 35 mpg hwy | 
 | engine | engine 3.7l v 6 double overhead cam with vvt 1 1.0 1 compression ratio four valves per cylinder | engine 3.7l v 6 double overhead cam with vvt 11.0 1 compression ratio four valves per cylinder | 
 | engine | 2. 4l 170 hp i 4 | 2.4l 170 hp i 4 | 
 | engine | 3.5l gtdi v 6 | 3.5l gtdi v 6 ecoboost tm | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | fuel_economy |  | 19 mpg city 24 mpg hwy | 
 | engine | 3.5l v 6 | 3.5l v 6 high output 24v mpi | 
 | engine | engine 3. 6l pentastar v 6 dohc with variable valve timing and four valves per cylinder | engine 3.6l pentastar v 6 dohc with variable valve timing and four valves per cylinder | 
 | model | 2010 chrysler town country limited | 2010 chrysler town country limited passenger minivan | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 2. 4l i 4 dohc 16valve vvti | 2.4l i 4 dohc 16valve vvti | 
 | model | 2011 mercedesbenz | 2011 mercedesbenz rclass | 
 | engine | 304hp, 3. 6liter v 6 regular gas | 304hp, 3.6liter v 6 regular gas | 
 | engine | 2.5l 22 4 hp h 4 | 2.5l 224 hp h 4 | 
 | engine | 2. 4l gas i 4 ecotec, 182 hp | 2.4l gas i 4 ecotec, 182 hp | 
 | model | 2011 honda cr | 2011 honda crz | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 2. 5l 170 hp i 5 | 2.5l 170 hp i 5 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | model | 2010 kia forte | 2010 kia forte koup | 
 | engine | 2. 4l 172 hp i 4 | 2.4l 172 hp i 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l dohc 16v i 4 | 2.4l dohc 16v i 4 | 
 | fuel_economy | na | 18 | 
 | fuel_economy |  | 25 mpg city 31 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 19 mpg city 26 mpg hwy | 
 | fuel_economy |  | 15 mpg city 21 mpg hwy | 
 | model | 2011 chevrolet express 3500 | 2011 chevrolet express 2500 | 
 | model | 2010 mercedesbenz | 2010 mercedesbenz glkclass | 
 | engine | 2 68hp, 3.5liter v 6 premium | 268hp, 3.5liter v 6 premium | 
 | fuel_economy |  | 20 mpg city 26 mpg hwy | 
 | engine | 3. 6l 288 hp v 6 | 3.6l 288 hp v 6 | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3.5l 27 6 hp v 6 | 3.5l 276 hp v 6 | 
 | fuel_economy |  | 18 mpg city 26 mpg hwy | 
 | engine | 3. 6l variable valve timing v 6 di | 3.6l variable valve timing v 6 di | 
 | fuel_economy |  | 13 mpg city 19 mpg hwy | 
 | fuel_economy |  | 19 mpg city 29 mpg hwy | 
 | fuel_economy |  | 13 mpg city 19 mpg hwy | 
 | fuel_economy |  | 24 mpg city 35 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2 68hp, 3.5liter v 6 regular gas | 268hp, 3.5liter v 6 regular gas | 
 | engine | 2. 4l i 4 16valve dohc ivtec | 2.4l i 4 16valve dohc ivtec | 
 | model | 2010 toyota prius prius | 2010 toyota prius | 
 | fuel_economy |  | 30 mpg city 42 mpg hwy | 
 | engine | 1 40hp, 2.0liter i 4 diesel | 140hp, 2.0liter i 4 diesel | 
 | engine | 3. 6l 280 hp v 6 | 3.6l 280 hp v 6 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 18 mpg city 23 mpg hwy | 
 | engine | 2.3l 2 4 4 hp i 4 | 2.3l 244 hp i 4 | 
 | fuel_economy |  | 23 mpg city 30 mpg hwy | 
 | engine | 2. 4l 16valve dohc ivtec i 4 | 2.4l 16valve dohc ivtec i 4 | 
 | fuel_economy |  | 19 mpg city 23 mpg hwy | 
 | engine | 2.4l dohc 4cylinder | 2.4l dohc 4cylinder sidi wvvt | 
 | engine | 2. 4l 182 hp i 4 | 2.4l 182 hp i 4 | 
 | engine | 4. 8l 2 80 hp v 8 | 4.8l 280 hp v 8 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | fuel_economy |  | 18 mpg city 23 mpg hwy | 
 | engine | 6.2l 3 85 hp v 8 | 6.2l 385 hp v 8 | 
 | engine | 3. 6l vr 6 | 3.6l vr 6 | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | engine | 288hp, 3. 6liter v 6 regular gas | 288hp, 3.6liter v 6 regular gas | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 290hp, 3. 6liter v 6 flexible e 85 | 290hp, 3.6liter v 6 flexible e 85 | 
 | engine | 2. 5l 170 hp i 5 | 2.5l 170 hp i 5 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | model | 2011 toyota sienna limited 7passenger | 2011 toyota sienna limited 7passenger minivan | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | fuel_economy |  | 17 mpg city 24 mpg hwy | 
 | engine | 1 4 4hp, 2.0liter i 4 regular gas | 144hp, 2.0liter i 4 regular gas | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | model | 2010 ford explorer sport trac 4 | 2010 ford explorer sport trac highlights | 
 | engine | 166hp, 2. 4liter i 4 regular gas | 166hp, 2.4liter i 4 regular gas | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 2. 5l 5 | 2. 5l 5 cylinder inline dohc | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | fuel_economy |  | 16 mpg city 21 mpg hwy | 
 | fuel_economy |  | 21 mpg city 30 mpg hwy | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 20 mpg city 26 mpg hwy | 
 | fuel_economy |  | 14 mpg city 19 mpg hwy | 
 | engine | 2. 4l 176 hp i 4 | 2.4l 176 hp i 4 | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 3. 6l v 6 vvt di direct injection | 3.6l v 6 vvt di direct injection | 
 | engine | 1. 4l 138 hp i 4 | 1.4l 138 hp i 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 2010 nissan pathfinder | 2010 mazda cx 9 | 
 | fuel_economy |  | 16 mpg city 24 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 2010 aston martin | 2010 aston martin rapide | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | fuel_economy |  | 22 mpg city 30 mpg hwy | 
 | engine | vortec 4. 8l vvt v 8 sfi flexfuel | vortec 4.8l vvt v 8 sfi flexfuel | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | fuel_economy |  | 17 mpg city 25 mpg hwy | 
 | engine | 1 40hp, 2.0liter i 4 regular gas | 140hp, 2.0liter i 4 regular gas | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | engine | 4.6l 24 8 hp v 8 | 4.6l 248 hp v 8 | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | engine | vortec 4. 8l v 8 sfi flexfuel | vortec 4.8l v 8 sfi flexfuel | 
 | fuel_economy |  | 18 mpg city 25 mpg hwy | 
 | engine | engine 6.2l v 8 double overhead cam with vvt 1 1.3 1 compression ratio four valves per cylinder | engine 6.2l v 8 double overhead cam with vvt 11.3 1 compression ratio four valves per cylinder | 
 | engine | 3. 6l h 6 engine | 3.6l h 6 engine | 
 | price | not released | na | 
 | fuel_economy | na | 18 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 16 mpg city 21 mpg hwy | 
 | engine | 2. 4l 180 hp i 4 | 2.4l 180 hp i 4 | 
 | engine | 2. 4l 169 hp i 4 | 2.4l 169 hp i 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | engine | 4. 8l 2 80 hp v 8 | 4.8l 280 hp v 8 | 
 | engine | 2. 4l 170 hp i 4 | 2.4l 170 hp i 4 | 
 | engine | engine 1.6l ecotec | engine 1.6l ecotec inlinefourcylinder dohc with variable valve timing and four valves per cylinder | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | fuel_economy |  | 21 mpg city 27 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2.0l 1 48 hp i 4 | 2.0l 148 hp i 4 | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | model | 2011 chrysler town country | 2011 chrysler town amp country | 
 | engine | 283hp, 3. 6liter v 6 flexible e 85 | 283hp, 3.6liter v 6 flexible e 85 | 
 | fuel_economy |  | 12 mpg city 17 mpg hwy | 
 | fuel_economy |  | 12 mpg city 18 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | engine | 3. 6l gas v 6 | 3.6l gas v 6 | 
 | engine | 2.0l 1 42 hp i 4 | 2.0l 142 hp i 4 | 
 | model | 2011 toyota sienna xle 7passenger | 2011 toyota sienna xle 7passenger minivan | 
 | fuel_economy |  | 20 mpg city 26 mpg hwy | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 4l i 4 dohc 16v dual vvt | 2.4l i 4 dohc 16v dual vvt | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 5.5l 3 82 hp v 8 | 5.5l 382 hp v 8 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 3.0l supercharged hybrid | 3.0l supercharged hybrid v 6, 380 hp | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | model | 2010 mercedesbenz | 2010 mercedesbenz slkclass | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3. 6l 252 hp v 6 | 3.6l 252 hp v 6 | 
 | fuel_economy |  | 18 mpg city 24 mpg hwy | 
 | fuel_economy |  | 16 mpg city 23 mpg hwy | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 4l 166 hp i 4 | 2.4l 166 hp i 4 | 
 | engine | 3. 6l 281 hp v 6 | 3.6l 281 hp v 6 | 
 | engine | 2. 4l 172 hp i 4 | 2.4l 172 hp i 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 15 mpg city 21 mpg hwy | 
 | engine | 3. 6l variable valve timing v 6 di | 3.6l variable valve timing v 6 di | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 2.4l dohc 4cylinder | 2.4l dohc 4cylinder sidi wvvt | 
 | engine | 166hp, 2. 4liter i 4 regular gas | 166hp, 2.4liter i 4 regular gas | 
 | model | 2011 bmw activehybrid | 2011 bmw activehybrid 750 | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 4. 8l 3 85 hp v 8 | 4.8l 385 hp v 8 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 15 mpg city 20 mpg hwy | 
 | fuel_economy |  | 18 mpg city 24 mpg hwy | 
 | fuel_economy |  | 14 mpg city 18 mpg hwy | 
 | engine | 2. 4l 176 hp i 4 | 2.4l 176 hp i 4 | 
 | engine | engine 4. 8l vortec v 8 ohv with variable valve timing and two valves per cylinder | engine 4.8l vortec v 8 ohv with variable valve timing and two valves per cylinder | 
 | engine | 150hp, 2. 4liter i 4 regular gas | 150hp, 2.4liter i 4 regular gas | 
 | fuel_economy |  | 22 mpg city 32 mpg hwy | 
 | model | 2011 chevrolet suburban | 2011 chevrolet suburban 1500 | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | model | 2010 land rover range | 2010 land rover range rover | 
 | engine | 2. 4l 166 hp i 4 | 2.4l 166 hp i 4 | 
 | fuel_economy |  | 22 mpg city 32 mpg hwy | 
 | engine | 6.2l 3 85 hp v 8 | 6.2l 385 hp v 8 | 
 | model | 2010 porsche 911 | 2010 porsche 911 gt 3 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3. 6l 280 hp v 6 | 3.6l 280 hp v 6 | 
 | engine | 3. 6l 25 6 hp h 6 | 3.6l 256 hp h 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 4.0l 2 6 6 hp v 6 | 4.0l 266 hp v 6 | 
 | engine | 2. 5l 5 | 2. 5l 5 cylinder inline dohc | 
 | model | 2011 subaru forester | 2011 subaru forester 2.5 xt premium suv | 
 | engine | 2. 4l 173 hp i 4 | 2.4l 173 hp i 4 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | engine 5.0l v 8 double overhead cam with vvt 1 1.5 1 compression ratio four valves per cylinder | engine 5.0l v 8 double overhead cam with vvt 11.5 1 compression ratio four valves per cylinder | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 6.2l 3 85 hp v 8 | 6.2l 385 hp v 8 | 
 | engine | 3. 6l v 6 vvt di direct injection | 3.6l v 6 vvt di direct injection | 
 | fuel_economy |  | 16 mpg city 21 mpg hwy | 
 | engine | 3. 6l v 6 dohc | 3.6l v 6 dohc | 
 | engine | 3.8l 30 6 hp v 6 | 3.8l 306 hp v 6 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 2 65hp, 3.0liter i 6 diesel | 265hp, 3.0liter i 6 diesel | 
 | fuel_economy |  | 26 mpg city 34 mpg hwy | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | model | 2010 lincoln mks ecoboost | 2010 lincoln mks ecoboost sedan | 
 | engine | 3. 6l variable valve timing v 6 di | 3.6l variable valve timing v 6 di | 
 | fuel_economy |  | 15 mpg city 19 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 14 mpg city 19 mpg hwy | 
 | engine | 2. 4l 173 hp i 4 | 2.4l 173 hp i 4 | 
 | fuel_economy |  | 40 mpg city 43 mpg hwy | 
 | model | 2011 hyundai genesis coupe | 2011 hyundai genesis coupe rspec coupe | 
 | fuel_economy |  | 22 mpg city 28 mpg hwy | 
 | engine | 2. 4l 168 hp i 4 | 2.4l 168 hp i 4 | 
 | fuel_economy |  | 18 mpg city 25 mpg hwy | 
 | engine | 4.6l 24 8 hp v 8 | 4.6l 248 hp v 8 | 
 | engine | 2. 4l 158 hp i 4 | 2.4l 158 hp i 4 | 
 | model | 2011 chrysler town country | 2011 chrysler town amp country | 
 | price | not released | na | 
 | fuel_economy | na | 18 | 
 | engine | 2.0l 1 48 hp i 4 | 2.0l 148 hp i 4 | 
 | engine | 1 48hp, 2.0liter i 4 regular gas | 148hp, 2.0liter i 4 regular gas | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | model | 2010 volkswagen golf | 2010 volkswagen gti | 
 | engine | 2.3l 1 43 hp i 4 | 2.3l 143 hp i 4 | 
 | engine | 182hp, 2. 4liter i 4 regular gas | 182hp, 2.4liter i 4 regular gas | 
 | engine | 173hp, 2. 4liter i 4 regular gas | 173hp, 2.4liter i 4 regular gas | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 1.8l 1 40 hp i 4 | 1.8l 140 hp i 4 | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | engine | 4. 8l v 8 32v | 4.8l v 8 32v | 
 | fuel_economy |  | 14 mpg city 22 mpg hwy | 
 | fuel_economy |  | 25 mpg city 33 mpg hwy | 
 | engine | 3. 6l h 6 engine | 3.6l h 6 engine | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | fuel_economy |  | 17 mpg city 25 mpg hwy | 
 | engine | 3.5l 2 6 6 hp v 6 | 3.5l 266 hp v 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 161hp, 2. 4liter i 4 regular gas | 161hp, 2.4liter i 4 regular gas | 
 | fuel_economy |  | 17 mpg city 25 mpg hwy | 
 | engine | vortec 4. 8l v 8 sfi flexfuel | vortec 4.8l v 8 sfi flexfuel | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | model | 2010 hyundai santa | 2010 hyundai santa fe | 
 | engine | 175hp, 2. 4liter i 4 regular gas | 175hp, 2.4liter i 4 regular gas | 
 | fuel_economy |  | 23 mpg city 31 mpg hwy | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | engine | 182hp, 2. 4liter i 4 regular gas | 182hp, 2.4liter i 4 regular gas | 
 | engine | 290hp, 3. 6liter v 6 premium | 290hp, 3.6liter v 6 premium | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 2. 5l i 5 dohc mpi | 2.5l i 5 dohc mpi | 
 | engine | engine 3.7l v 6 overhead cam with vvt 1 1.2 1 compression ratio four valves per cylinder | engine 3.7l v 6 overhead cam with vvt 11.2 1 compression ratio four valves per cylinder | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | fuel_economy |  | 41 mpg city 36 mpg hwy | 
 | model | 2010 hummer h 3 | 2010 hummer h 3 suv | 
 | engine | vortec 4. 8l v 8 sfi flexfuel | vortec 4.8l v 8 sfi flexfuel | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | fuel_economy |  | 28 mpg city 36 mpg hwy | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 35 mpg city 34 mpg hwy | 
 | engine | 3. 6l gas v 6 | 3.6l gas v 6 | 
 | engine | 2. 4l 190 hp i 4 | 2.4l 190 hp i 4 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | vortec 4. 8l vvt v 8 sfi flexfuel | vortec 4.8l vvt v 8 sfi flexfuel | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 20 1 1 chevrolet corvette zr 1 | 2011 chevrolet corvette zr 1 | 
 | engine | 25 6hp, 3. 6liter h 6 regular gas | 256hp, 3.6liter h 6 regular gas | 
 | engine | 3. 6l 288 hp v 6 | 3.6l 288 hp v 6 | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 4. 8l v 8 engine | 4.8l v 8 engine | 
 | fuel_economy |  | 21 mpg city 29 mpg hwy | 
 | model | 2010 bentley continental 552 | 2010 bentley continental gtc | 
 | fuel_economy |  | 17 mpg city 25 mpg hwy | 
 | model | 2010 lexus ls | 2010 lexus ls 460 | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | engine | vortec 4. 8l vvt v 8 sfi flexfuel | vortec 4.8l vvt v 8 sfi flexfuel | 
 | fuel_economy |  | 15 mpg city 22 mpg hwy | 
 | engine | engine 6. 8l v 8 ohv and two valves per cylinder | engine 6.8l v 8 ohv and two valves per cylinder | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 4l 180 hp i 4 | 2.4l 180 hp i 4 | 
 | fuel_economy |  | 13 mpg city 17 mpg hwy | 
 | fuel_economy |  | 17 mpg city 23 mpg hwy | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | model | 2010 lexus gs | 2010 lexus gs 350 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 27 mpg city 36 mpg hwy | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 2011 mercedesbenz | 2011 mercedesbenz clclass | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | fuel_economy |  | 24 mpg city 35 mpg hwy | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | engine | 3. 6l 345 hp h 6 | 3.6l 345 hp h 6 | 
 | fuel_economy |  | 12 mpg city 18 mpg hwy | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 3. 6l 252 hp v 6 | 3.6l 252 hp v 6 | 
 | fuel_economy |  | 16 mpg city 21 mpg hwy | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | engine | 3. 6l vvt v 6 sidi | 3.6l vvt v 6 sidi | 
 | model | 2011 land rover | 2011 land rover lr 4 | 
 | engine | 2. 4l 190 hp i 4 | 2.4l 190 hp i 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2.3l 2 40 hp i 4 | 2.3l 240 hp i 4 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | fuel_economy |  | 11 mpg city 18 mpg hwy | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | fuel_economy |  | 16 mpg city 25 mpg hwy | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | engine 3. 6l pentastar v 6 dohc with variable valve timing and four valves per cylinder | engine 3.6l pentastar v 6 dohc with variable valve timing and four valves per cylinder | 
 | engine | 4.6l 24 8 hp v 8 | 4.6l 248 hp v 8 | 
 | engine | 3. 6l h 6 engine | 3.6l h 6 engine | 
 | engine | 3. 6l v 6 vvt flex fuel | 3.6l v 6 vvt flex fuel | 
 | engine | 162hp, 2. 4liter i 4 regular gas | 162hp, 2.4liter i 4 regular gas | 
 | engine | 155hp, 2. 4liter i 4 regular gas | 155hp, 2.4liter i 4 regular gas | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | 3.5l 2 6 6 hp v 6 | 3.5l 266 hp v 6 | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | engine | 2. 4l 16 4 hp i 4 | 2.4l 164 hp i 4 | 
 | engine | 6.2l 3 85 hp v 8 | 6.2l 385 hp v 8 | 
 | model | 2010 ford f 350 | 2010 ford f 250 | 
 | fuel_economy |  | 18 mpg city 23 mpg hwy | 
 | engine | 3.5l 2 69 hp v 6 | 3.5l 269 hp v 6 | 
 | engine | 2. 4l 182 hp i 4 | 2.4l 182 hp i 4 | 
 | engine | 3. 6l 304 hp v 6 | 3.6l 304 hp v 6 | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | 5.7l 3 81 hp v 8 | 5.7l 381 hp v 8 | 
 | engine | 2. 5l 5 | 2. 5l 5 cylinder inline dohc | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | model | 2011 hyundai elantra | 2011 hyundai elantra touring | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | engine | engine 3.5l v 6 overhead cam with vvt 1 1.2 1 compression ratio four valves per cylinder | engine 3.5l v 6 overhead cam with vvt 11.2 1 compression ratio four valves per cylinder | 
 | engine | 4.6l 24 8 hp v 8 | 4.6l 248 hp v 8 | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 3.8l 30 6 hp v 6 | 3.8l 306 hp v 6 | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 12 mpg city 18 mpg hwy | 
 | fuel_economy |  | 17 mpg city 25 mpg hwy | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | engine | 2. 4l 177 hp i 4 | 2.4l 177 hp i 4 | 
 | fuel_economy |  | 17 mpg city 24 mpg hwy | 
 | engine | 3.5l 2 6 6 hp v 6 | 3.5l 266 hp v 6 | 
 | engine | 3.8l 30 6 hp v 6 | 3.8l 306 hp v 6 | 
 | engine | engine 3. 6l v 6 double overhead cam with vvt 1 1.3 1 compression ratio four valves per cylinder | engine 3. 6l v 6 double overhead cam with vvt 11.3 1 compression ratio four valves per cylinder | 
 | engine | 3.5l 2 65 hp v 6 | 3.5l 265 hp v 6 | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 3. 6l 288 hp v 6 | 3.6l 288 hp v 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | fuel_economy |  | 22 mpg city 31 mpg hwy | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | engine | 2. 4l 190 hp i 4 | 2.4l 190 hp i 4 | 
 | engine | 3. 6l 25 6 hp h 6 | 3.6l 256 hp h 6 | 
 | model | 2010 mercedesbenz | 2010 mercedesbenz eclass | 
 | engine | 2 68hp, 3.5liter v 6 premium | 268hp, 3.5liter v 6 premium | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 25 mpg city 34 mpg hwy | 
 | engine | 1.8l 1 40 hp i 4 | 1.8l 140 hp i 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | model | 2010 land rover range rover | 2010 land rover range rover sport | 
 | fuel_economy |  | 15 mpg city 22 mpg hwy | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | model | 2011 mercedesbenz sls | 2011 mercedesbenz sls amg | 
 | model | 2010 chrysler town country touring | 2010 chrysler town country touring passenger minivan | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | engine | 2. 4l i 4 dohc 16v dual vvt | 2.4l i 4 dohc 16v dual vvt | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | engine | engine 2.0l inline 4 double overhead cam with vvt 10. 1 1 compression ratio four valves per cylinder | engine 2.0l inline 4 double overhead cam with vvt 10.1 1 compression ratio four valves per cylinder | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | model | 2011 kia forte | 2011 kia forte 5door overview | 
 | fuel_economy |  | 15 mpg city 22 mpg hwy | 
 | fuel_economy |  | 14 mpg city 19 mpg hwy | 
 | fuel_economy |  | 14 mpg city 20 mpg hwy | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | engine | engine 3. 6l v 6 double overhead cam with vvt 1 1.3 1 compression ratio four valves per cylinder | engine 3. 6l v 6 double overhead cam with vvt 11.3 1 compression ratio four valves per cylinder | 
 | model | 2011 land rover range rover | 2011 land rover range rover sport | 
 | model | 2010 land rover | 2010 land rover lr 4 | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | engine | 3 85hp, 5.0liter v 8 premium | 385hp, 5.0liter v 8 premium | 
 | fuel_economy |  | 13 mpg city 20 mpg hwy | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 2. 5l 170 hp i 5 | 2.5l 170 hp i 5 | 
 | model | 2010 gmc yukon | 2010 gmc yukon xl 1500 | 
 | fuel_economy |  | 18 mpg city 24 mpg hwy | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | engine | 3.5l v 6 | 3.5l v 6 high output 24v mpi | 
 | model | 2010 rollsroyce phantom | 2010 rollsroyce phantom drophead coupe | 
 | fuel_economy |  | 12 mpg city 17 mpg hwy | 
 | model | 2010 hyundai elantra | 2010 hyundai elantra touring | 
 | engine | 2. 4l i 4 dohc cvvt | 2.4l i 4 dohc cvvt | 
 | engine | 2. 4l 16valve dohc ivtec i 4 | 2.4l 16valve dohc ivtec i 4 | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | engine | 2. 4l l 4 | 2.4l l 4 | 
 | fuel_economy |  | 21 mpg city 22 mpg hwy | 
 | engine | 2.0l i 4 dohc 16valve 1 48hp | 2.0l i 4 dohc 16valve 148hp | 
 | engine | 2. 5l i 5 engine | 2.5l i 5 engine | 
 | fuel_economy |  | 18 mpg city 28 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | engine | 3. 6l 302 hp v 6 | 3.6l 302 hp v 6 | 
 | fuel_economy |  | 22 mpg city 32 mpg hwy | 
 | engine | 2. 4l theta 2 dohc 16v i 4 wcvvt mpi | 2.4l theta 2 dohc 16v i 4 wcvvt mpi | 
 | fuel_economy |  | 18 mpg city 25 mpg hwy | 
 | engine | engine 2.0l inline 4 double overhead cam with vvt 1 1.0 1 compression ratio four valves per cylinder | engine 2.0l inline 4 double overhead cam with vvt 11.0 1 compression ratio four valves per cylinder | 
 | engine | 4. 8l v 8 | 4.8l v 8 | 
 | engine | 4.0l 2 61 hp v 6 | 4.0l 261 hp v 6 | 
 | fuel_economy |  | 22 mpg city 30 mpg hwy | 
 | engine | 3.0l 2 65 hp v 6 | 3.0l 265 hp v 6 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l 16v i 4 mpi dohc | 2.4l 16v i 4 mpi dohc | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | engine | 2. 4l i 4 sidi vvt | 2.4l i 4 sidi vvt | 
 | fuel_economy |  | 13 mpg city 19 mpg hwy | 
 | engine | 3. 6l 281 hp v 6 | 3.6l 281 hp v 6 | 
 | engine | vortec 4. 8l vvt v 8 sfi flexfuel | vortec 4.8l vvt v 8 sfi flexfuel | 
 | engine | 3. 6l 281 hp v 6 | 3.6l 281 hp v 6 | 
 | engine | engine 1.4l ecotec | engine 1.4l ecotec inlinefourcylinder dohc with variable valve timing and four valves per cylinder | 
 | fuel_economy |  | 13 mpg city 18 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 4.0l 2 60 hp v 6 | 4.0l 260 hp v 6 | 
 | engine | 2. 4l 190 hp i 4 | 2.4l 190 hp i 4 | 
 | fuel_economy |  | 19 mpg city 27 mpg hwy | 
 | engine | 180hp, 2. 4liter i 4 regular gas | 180hp, 2.4liter i 4 regular gas | 
 | fuel_economy |  | 16 mpg city 21 mpg hwy | 
 | engine | 2. 5l l 5 | 2.5l l 5 | 
 | model | 2010 toyota yaris sedan | 2010 toyota yaris | 
 | fuel_economy |  | 20 mpg city 23 mpg hwy | 
 | engine | 2.0l 1 40 hp i 4 | 2.0l 140 hp i 4 | 
 | fuel_economy |  | 13 mpg city 19 mpg hwy | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | engine | 3. 6l v 6 | 3.6l v 6 | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | fuel_economy |  | 27 mpg city 36 mpg hwy | 
 | engine | 2. 4l 16valve dohc ivtec i 4 | 2.4l 16valve dohc ivtec i 4 | 
 | engine | 2. 5l 1 50 hp i 5 | 2.5l 150 hp i 5 | 
 | engine | 2. 4l i 4 engine | 2.4l i 4 engine | 
 | fuel_economy |  | 16 mpg city 23 mpg hwy | 
 | fuel_economy |  | 18 mpg city 26 mpg hwy | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | fuel_economy |  | 18 mpg city 27 mpg hwy | 
 | engine | 3.5l 30 6 hp v 6 | 3.5l 306 hp v 6 | 
 | engine | 1.8l 1 40 hp i 4 | 1.8l 140 hp i 4 | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | fuel_economy |  | 23 mpg city 31 mpg hwy | 
 | engine | 3. 6l vvt v 6 sidi | 3.6l vvt v 6 sidi | 
 | engine | 2.0l 1 48 hp i 4 | 2.0l 148 hp i 4 | 
 | price | $ 87,600 | $ 56,850 | 
 | engine | 3.5l 2 68 hp v 6 | 3.5l 268 hp v 6 | 
 | engine | 4. 8l 302 hp v 8 | 4.8l 302 hp v 8 | 
 | engine | vortec 4. 8l vvt v 8 sfi flexfuel | vortec 4.8l vvt v 8 sfi flexfuel | 
 | engine | 3.2l 2 65 hp v 6 | 3.2l 265 hp v 6 | 
 | engine | 3. 6l sidi v 6 | 3.6l sidi v 6 | 
 | engine | 4.0l 23 6 hp v 6 | 4.0l 236 hp v 6 | 
 | fuel_economy | na | no data | 
 | model | 2010 subaru impreza outback | 2010 subaru impreza | 
 | engine | 3. 6l h 6 | 3.6l h 6 | 
 | fuel_economy |  | 22 mpg city 32 mpg hwy | 
 | engine | 3. 6l v 6 engine | 3.6l v 6 engine | 
 | engine | 4. 8l 360 hp v 8 | 4.8l 360 hp v 8 | 
 | model | 2010 chevrolet silverado 2500hd | 2010 chevrolet silverado 3500hd | 
 | engine | 3.5l 2 6 6 hp v 6 | 3.5l 266 hp v 6 | 
 | model | 2010 suzuki equator crew cab sport | 2010 suzuki equator crew cab | 
