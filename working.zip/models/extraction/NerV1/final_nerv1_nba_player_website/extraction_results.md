# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_nerv1_nba_player_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9211 | 0.9215 |
| F1 | 0.9219 | 0.9221 |
| Partial Match | 0.922 | 0.9222 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9194 | 0.9216 |
| F1 | 0.9209 | 0.923 |
| Partial Match | 0.9208 | 0.9232 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9878 | 0.9891 |
| F1 | 0.991 | 0.9914 |
| Partial Match | 0.9915 | 0.9919 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9811 | 0.982 |
| F1 | 0.9864 | 0.9873 |
| Partial Match | 0.9868 | 0.9887 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8917 | 0.8921 |
| F1 | 0.8917 | 0.8921 |
| Partial Match | 0.8917 | 0.8921 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8847 | 0.8922 |
| F1 | 0.8847 | 0.8922 |
| Partial Match | 0.8847 | 0.8922 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9023 | 0.9023 |
| F1 | 0.9024 | 0.9024 |
| Partial Match | 0.9023 | 0.9023 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9055 | 0.9055 |
| F1 | 0.9061 | 0.9061 |
| Partial Match | 0.9055 | 0.9055 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9027 | 0.9027 |
| F1 | 0.9027 | 0.9027 |
| Partial Match | 0.9027 | 0.9027 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9064 | 0.9064 |
| F1 | 0.9064 | 0.9064 |
| Partial Match | 0.9064 | 0.9064 |
