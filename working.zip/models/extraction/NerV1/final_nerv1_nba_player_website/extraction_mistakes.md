# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | celtic | grizzly | 
 | team | bull | wizard | 
 | team | clipper | 76ers | 
 | name | patrick ewing | patrick ewing jr. | 
 | team | lakers | celtic | 
 | name | manu ginóbili | emanuel ginóbili | 
 | team | cavalier | heat | 
 | team | bull | 76ers | 
 | team | los angeles clippers | denver nuggets | 
 | height | height 68 | 68 | 
 | name | josé juan | josé juan barea | 
 | name | lindsey hunter | shaquille oneal | 
 | name | nazr mohammed | desagana diop | 
 | name | jon weinbach | demar derozan | 
 | team | heat | warrior | 
 | name | j.j. barea | jose juan barea | 
 | team | magic | sun | 
 | name | andrew bynum | jermaine oneal | 
 | team | sacramento kings | washington wizards | 
 | name | j. mayo | o. j. mayo | 
 | name | chris douglasroberts | chris douglasroberts 17 | 
 | name | jose juan barea | jose juan barea 11 pg | 
 | name | al farouq | al farouq aminu | 
 | team | denver nuggets | philadelphia 76ers | 
 | team | nugget | 76ers | 
 | weight | 285 | 295160lb 134 kg | 
