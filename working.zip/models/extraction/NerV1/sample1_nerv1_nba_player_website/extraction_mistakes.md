# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | houston rockets | philadelphia 76ers | 
 | name | pops mensah bonsu pops mensahbonsu | pops mensah bonsu | 
 | name | o.j. mayo | o. j. mayo | 
 | name | brandon jennings from | brandon jennings | 
 | team | new orleans hornets | philadelphia 76ers | 
