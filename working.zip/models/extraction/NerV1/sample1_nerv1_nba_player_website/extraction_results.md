# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: 2000
* Train-Test-Split: 0.7
* Seed: sample1
* Name: sample1_nerv1_nba_player_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9223 | 0.9225 |
| F1 | 0.9226 | 0.9226 |
| Partial Match | 0.9223 | 0.9225 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9146 | 0.9154 |
| F1 | 0.9154 | 0.9156 |
| Partial Match | 0.9154 | 0.9158 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9914 | 0.9921 |
| F1 | 0.9924 | 0.9926 |
| Partial Match | 0.9914 | 0.9921 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.985 | 0.9883 |
| F1 | 0.9883 | 0.989 |
| Partial Match | 0.9883 | 0.99 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8914 | 0.8914 |
| F1 | 0.8914 | 0.8914 |
| Partial Match | 0.8914 | 0.8914 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8867 | 0.8867 |
| F1 | 0.8867 | 0.8867 |
| Partial Match | 0.8867 | 0.8867 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9029 | 0.9029 |
| F1 | 0.9029 | 0.9029 |
| Partial Match | 0.9029 | 0.9029 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8933 | 0.8933 |
| F1 | 0.8933 | 0.8933 |
| Partial Match | 0.8933 | 0.8933 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9036 | 0.9036 |
| F1 | 0.9036 | 0.9036 |
| Partial Match | 0.9036 | 0.9036 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8933 | 0.8933 |
| F1 | 0.8933 | 0.8933 |
| Partial Match | 0.8933 | 0.8933 |
