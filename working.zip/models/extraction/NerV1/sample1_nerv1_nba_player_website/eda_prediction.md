# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.26 | 2.27 | 1.4 | 0.01 | 
| team | 13.42 | 1.94 | 1.29 | 0.11 | 
| height | 3.31 | 1.28 | 0.89 | 0.11 | 
| weight | 5.77 | 1.51 | 0.89 | 0.11 | 


