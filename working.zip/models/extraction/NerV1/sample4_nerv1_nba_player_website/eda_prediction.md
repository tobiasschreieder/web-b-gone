# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.47 | 2.32 | 1.47 | 0.0 | 
| team | 13.18 | 1.93 | 1.38 | 0.09 | 
| height | 3.23 | 1.25 | 0.9 | 0.1 | 
| weight | 5.58 | 1.46 | 0.9 | 0.1 | 


