# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: 2000
* Train-Test-Split: 0.7
* Seed: sample4
* Name: sample4_nerv1_nba_player_website
* Version: NerV1
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9237 | 0.9237 |
| F1 | 0.9239 | 0.9239 |
| Partial Match | 0.9237 | 0.9237 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9242 | 0.9271 |
| F1 | 0.9253 | 0.9274 |
| Partial Match | 0.9263 | 0.9279 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9907 | 0.9907 |
| F1 | 0.9914 | 0.9914 |
| Partial Match | 0.9907 | 0.9907 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9917 | 0.9933 |
| F1 | 0.993 | 0.9947 |
| Partial Match | 0.995 | 0.9967 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8929 | 0.8929 |
| F1 | 0.8929 | 0.8929 |
| Partial Match | 0.8929 | 0.8929 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8983 | 0.9083 |
| F1 | 0.9017 | 0.9083 |
| Partial Match | 0.9033 | 0.9083 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9057 | 0.9057 |
| F1 | 0.9057 | 0.9057 |
| Partial Match | 0.9057 | 0.9057 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9033 | 0.9033 |
| F1 | 0.9033 | 0.9033 |
| Partial Match | 0.9033 | 0.9033 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9057 | 0.9057 |
| F1 | 0.9057 | 0.9057 |
| Partial Match | 0.9057 | 0.9057 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9033 | 0.9033 |
| F1 | 0.9033 | 0.9033 |
| Partial Match | 0.9033 | 0.9033 |
