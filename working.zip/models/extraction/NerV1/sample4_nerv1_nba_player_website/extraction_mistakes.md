# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | york knicks | knicks | 
 | team | bobcat | knicks | 
 | name | c.j. miles | c. j. miles | 
 | team | york knicks | knicks | 
 | team | sacramento kings | washington wizards | 
 | name | staff writer | kevin love | 
 | team | york knicks | knicks | 
 | team | new orleans hornets | toronto raptors | 
 | name | j.r. smith | j. r. smith | 
