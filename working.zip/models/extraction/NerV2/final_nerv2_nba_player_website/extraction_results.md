# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.neural_net_model.NeuralNetExtractionModel'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_nerv2_nba_player_website
* Version: NerV2
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0024 | 0.0076 |
| F1 | 0.0052 | 0.0129 |
| Partial Match | 0.0036 | 0.0096 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0017 | 0.0073 |
| F1 | 0.0032 | 0.0119 |
| Partial Match | 0.0026 | 0.0097 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0097 | 0.0304 |
| F1 | 0.0209 | 0.0515 |
| Partial Match | 0.0146 | 0.0385 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0066 | 0.0293 |
| F1 | 0.0128 | 0.0477 |
| Partial Match | 0.0104 | 0.0388 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0 | 0.0 |
| Partial Match | 0.0 | 0.0 |
