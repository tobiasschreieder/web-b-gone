# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.structure_template_model_v3.StrucTempExtractionModelV3'>
* Category: Category.RESTAURANT
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.15
* Seed: eval_class
* Name: final_struc_restaurant_website
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.5601 | 0.6672 |
| F1 | 0.5798 | 0.6928 |
| Partial Match | 0.561 | 0.6694 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.5655 | 0.6681 |
| F1 | 0.5839 | 0.6918 |
| Partial Match | 0.5665 | 0.6699 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7317 | 0.7317 |
| F1 | 0.7588 | 0.7605 |
| Partial Match | 0.7342 | 0.7346 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7432 | 0.7435 |
| F1 | 0.7693 | 0.7713 |
| Partial Match | 0.7443 | 0.7451 |
## Attribute Prediction: Address
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.2029 | 0.2913 |
| F1 | 0.2455 | 0.3418 |
| Partial Match | 0.2037 | 0.2942 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.1983 | 0.2781 |
| F1 | 0.2369 | 0.324 |
| Partial Match | 0.1988 | 0.28 |
## Attribute Prediction: Phone
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6196 | 0.8592 |
| F1 | 0.6198 | 0.8595 |
| Partial Match | 0.62 | 0.86 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6299 | 0.8598 |
| F1 | 0.6306 | 0.8606 |
| Partial Match | 0.6316 | 0.8616 |
## Attribute Prediction: Cuisine
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6863 | 0.7867 |
| F1 | 0.6953 | 0.8093 |
| Partial Match | 0.6863 | 0.7887 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6905 | 0.7909 |
| F1 | 0.6989 | 0.8113 |
| Partial Match | 0.6914 | 0.7929 |
