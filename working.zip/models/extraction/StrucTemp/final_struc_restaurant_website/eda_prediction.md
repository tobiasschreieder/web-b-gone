# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.RESTAURANT

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 14.81 | 2.22 | 3.0 | 0.0 | 
| address | 16.64 | 2.98 | 3.0 | 0.0 | 
| phone | 12.08 | 1.89 | 3.0 | 0.0 | 
| cuisine | 13.78 | 2.2 | 3.0 | 0.0 | 


