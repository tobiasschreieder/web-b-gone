# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.structure_template_model_v3.StrucTempExtractionModelV3'>
* Category: Category.NBA_PLAYER
* Data-split: domain
* Size dataset: -1
* Train-Test-Split: 0.7
* Seed: eval_class
* Name: final_struc_nba_player_domain
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7716 | 0.8059 |
| F1 | 0.7718 | 0.806 |
| Partial Match | 0.7719 | 0.8062 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.1572 | 0.2442 |
| F1 | 0.1573 | 0.2465 |
| Partial Match | 0.1575 | 0.2461 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8521 | 0.8521 |
| F1 | 0.8527 | 0.8527 |
| Partial Match | 0.8521 | 0.8521 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.0 |
| F1 | 0.0002 | 0.0093 |
| Partial Match | 0.0 | 0.001 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.5555 | 0.5555 |
| F1 | 0.5555 | 0.5555 |
| Partial Match | 0.5555 | 0.5555 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.2957 | 0.2986 |
| F1 | 0.2957 | 0.2986 |
| Partial Match | 0.2957 | 0.2986 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6949 | 0.832 |
| F1 | 0.6949 | 0.832 |
| Partial Match | 0.6949 | 0.832 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.3333 | 0.3449 |
| F1 | 0.3333 | 0.3449 |
| Partial Match | 0.3333 | 0.3449 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.9839 | 0.9839 |
| F1 | 0.9839 | 0.9839 |
| Partial Match | 0.9851 | 0.9851 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.0 | 0.3333 |
| F1 | 0.0 | 0.3333 |
| Partial Match | 0.001 | 0.3401 |
