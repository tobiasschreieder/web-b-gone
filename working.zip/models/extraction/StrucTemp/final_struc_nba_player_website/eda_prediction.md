# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.NBA_PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.02 | 2.12 | 3.0 | 0.0 | 
| team | 10.58 | 1.74 | 3.0 | 0.1 | 
| height | 5.06 | 1.33 | 3.0 | 0.26 | 
| weight | 8.32 | 1.99 | 3.0 | 0.04 | 


