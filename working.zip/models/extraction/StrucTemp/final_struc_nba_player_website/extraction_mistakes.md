# Wrong Extractions
| Attribute | Prediction | Ground Truth |
|---|---|---|
 | team | october 10, 1979 | portland trail blazers | 
 | name | utah jazz | al jefferson | 
 | team | relevancy filter | utah jazz | 
 | team | april 4, 1988 | atlanta hawks | 
 | name | rise to prominence | gilbert arenas | 
 | height | 1.1 | 6160ft1604160in 1.93 m | 
 | weight | 1.1 | 215160lb 98 kg | 
 | name | rebound | darrell arthur | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | denver nuggets | j.r. smith | 
 | team | relevancy filter | denver nuggets | 
 | name | assist | tony allen | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 213 | 
 | team | december 7, 1983 | washington wizards | 
 | team | november 10, 1984 | boston celtics | 
 | name | assist | steve blake | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 172 | 
 | height |  | 611 | 
 | height |  | 611 | 
 | name | utah jazz | andrei kirilenko | 
 | team | relevancy filter | utah jazz | 
 | name | orlando magic | j.j. redick | 
 | team | relevancy filter | orlando magic | 
 | name | endorsement | lebron james | 
 | team | 3.1.1 | miami heat | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | team | april 5, 1980 | san antonio spurs | 
 | height |  | 63 | 
 | name | utah jazz | jeremy evans | 
 | team | relevancy filter | utah jazz | 
 | name | 2004–05 | kevin martin | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 185160lb 84 kg | 
 | height |  | 66 | 
 | height |  | 610 | 
 | name | assist | gordon hayward | 
 | height |  | 69 | 
 | weight | may 18 ap | 207 | 
 | name | assist | c.j. watson | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 175 | 
 | name | san antonio spurs | dejuan blair | 
 | team | relevancy filter | san antonio spurs | 
 | name | rebound | kevin seraphin | 
 | height |  | 69 | 
 | weight | may 18 ap | 275 | 
 | name | career transactions | boris diaw | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 235160lb 107 kg | 
 | name | difficult start 1998–99 | dirk nowitzki | 
 | team | 5.1.1 | dallas mavericks | 
 | height | 3.1 | 7160ft1600160in 2.13 m | 
 | weight | 3.1 | 245160lb 111 kg | 
 | team | july 21, 1985 | boston celtics | 
 | name | rebound | andrew bogut | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 260 | 
 | name | assist | mike dunleavy | 
 | height |  | 69 | 
 | weight | 3pt made | 230 | 
 | team | july 26, 1975 | new jersey nets | 
 | team | july 6, 1980 | los angeles lakers | 
 | team | rank | heat | 
 | height |  | 68 | 
 | name | milwaukee bucks | chris douglas roberts | 
 | team | relevancy filter | milwaukee bucks | 
 | team | may 2, 1990 | indiana pacers | 
 | name | los angeles clippers | al thornton | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | name | assist | brandon rush | 
 | height |  | 66 | 
 | weight | may 18 yahoo contributor network | 210 | 
 | name | assist | mustafa shakur | 
 | height |  | 63 | 
 | weight | 3pt made | 190 | 
 | name | assist | beno udrih | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 205 | 
 | name | washington wizards | hamady ndiaye | 
 | team | relevancy filter | washington wizards | 
 | name | utah jazz | francisco elson | 
 | team | relevancy filter | utah jazz | 
 | team | november 12, 1988 | oklahoma city thunder | 
 | name | atlanta hawks | al horford | 
 | team | relevancy filter | atlanta hawks | 
 | height |  | 69 | 
 | name | assist | wilson chandler | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 225 | 
 | name | college | robin lopez | 
 | height | 3.1 | 7160ft1600160in 2.13 m | 
 | weight | 3.1 | 255160lb 116 kg | 
 | name | phoenix suns | earl barron | 
 | team | relevancy filter | phoenix suns | 
 | height |  | 61 | 
 | name | 1998–00 | carlos delfino | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 230160lb 104 kg | 
 | name | cleveland cavaliers | ryan hollins | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | oklahoma city thunder | nenad krstic | 
 | team | relevancy filter | oklahoma city thunder | 
 | team | november 19, 1980 | golden state warriors | 
 | name | sacramento kings | gerald wallace | 
 | height | 3.1 | 6160ft1607160in 2.01 m | 
 | weight | 3.1 | 220160lb 100 kg | 
 | name | portland trail blazers | lamarcus aldridge | 
 | team | relevancy filter | portland trail blazers | 
 | team | february 17, 1984 | orlando magic | 
 | name | assist | andre miller | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 200 | 
 | name | 2005–06 season | ryan gomes | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | team | october 4, 1988 | chicago bulls | 
 | team | may 4, 1988 | los angeles lakers | 
 | name | rebound | nick collison | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 255 | 
 | name | dallas mavericks 19941996 | jason kidd | 
 | height | 3.1 | 6160ft1604160in 1.93 m | 
 | weight | 3.1 | 210160lb 95 kg | 
 | name | philadelphia 76ers 2001–2002 | raja bell | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | name | regular season | hilton armstrong | 
 | height | 3.1 | 6160ft16011160in 2.11 m | 
 | weight | 3.1 | 235160lb 107 kg | 
 | name | indiana pacers | mike dunleavy | 
 | team | relevancy filter | indiana pacers | 
 | height |  | 610 | 
 | name | early life | al harrington | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | name | denver nuggets | chauncey billups | 
 | team | relevancy filter | denver nuggets | 
 | team | october 20, 1985 | charlotte bobcats | 
 | team | march 2, 1987 | detroit pistons | 
 | height |  | 63 | 
 | name | regular season | jameer nelson | 
 | height | 5.1 | 6160ft1600160in 1.83 m | 
 | weight | 5.1 | 190160lb 86 kg | 
 | team | june 1, 1985 | washington wizards | 
 | name | freshman year | ed davis | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | name | regular season | joel anthony | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 260160lb 118 kg | 
 | team | april 4, 1985 | portland trail blazers | 
 | name | rebound | dexter pittman | 
 | height |  | 611 | 
 | weight | may 19 ap | 308 | 
 | team | april 1, 1988 | new jersey nets | 
 | team | september 15, 1977 | dallas mavericks | 
 | name | rebound | darius songaila | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 248 | 
 | height |  | 6160ft16011160in 2.11 m | 
 | weight |  | 250160lb 113 kg | 
 | height |  | 69 | 
 | name | rebound | jeremy evans | 
 | height |  | 69 | 
 | weight | majestic utah jazz 32 karl malone green retired player throwback tshirt | 196 | 
 | name | assist | john lucas | 
 | height |  | 511 | 
 | weight | 3pt made | 165 | 
 | name | rebound | luis scola | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 245 | 
 | team | july 4, 1986 | chicago bulls | 
 | team | september 4, 1988 | cleveland cavaliers | 
 | name | minnesota timberwolves | nikola pekovic | 
 | team | relevancy filter | minnesota timberwolves | 
 | height |  | 611 | 
 | height |  | 63 | 
 | name | regular season | jawad williams | 
 | height | 5.1 | 6160ft1609160in 2.06 m | 
 | weight | 5.1 | 218160lb 99 kg | 
 | height |  | 69 | 
 | height |  | 610 | 
 | weight | 20 | 255 | 
 | height |  | 60 | 
 | name | assist | chris duhon | 
 | height |  | 61 | 
 | weight | may 18 yahoo contributor network | 190 | 
 | height |  | 610 | 
 | height |  | 64 | 
 | height |  | 67 | 
 | name | assist | d.j. augustin | 
 | height |  | 60 | 
 | weight | may 21 yahoo sports | 180 | 
 | name | assist | mike miller | 
 | height |  | 68 | 
 | weight | may 21 ap | 218 | 
 | team | september 19, 1983 | sacramento kings | 
 | name | los angeles clippers | willie warren | 
 | team | relevancy filter | los angeles clippers | 
 | name | toronto raptors | peja stojakovic | 
 | team | relevancy filter | toronto raptors | 
 | team | march 18, 1987 | utah jazz | 
 | name | freshman year | mario chalmers | 
 | height | 2.1 | 6160ft1601160in 1.85 m | 
 | weight | 2.1 | 195160lb 88 kg | 
 | name | new orleans hornets | jarrett jack | 
 | team | relevancy filter | new orleans hornets | 
 | height |  | 64 | 
 | name | college statistics | byron mullens | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 275160lb 125 kg | 
 | height |  | 69 | 
 | height |  | 67 | 
 | team | june 11, 1987 | oklahoma city thunder | 
 | name | los angeles lakers | kobe bryant | 
 | team | relevancy filter | los angeles lakers | 
 | name | rebound | leon powe | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | milwaukee bucks | keyon dooling | 
 | team | relevancy filter | milwaukee bucks | 
 | name | regular season | ian mahinmi | 
 | height | 4.1 | 6160ft16011160in 2.11 m | 
 | weight | 4.1 | 230160lb 104 kg | 
 | name | atlanta hawks | jamal crawford | 
 | team | relevancy filter | atlanta hawks | 
 | name | nba career statistics | raymond felton | 
 | height | 3.1 | 6160ft1601160in 1.85 m | 
 | weight | 3.1 | 198160lb 90 kg | 
 | name | minnesota timberwolves | kevin love | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | july 11, 1987 | minnesota timberwolves | 
 | team | june 22, 1988 | sacramento kings | 
 | name | injury | blake griffin | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 251160lb 114 kg | 
 | name | rookie year | tayshaun prince | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | team | june 4, 1990 | detroit pistons | 
 | name | miami heat | james jones | 
 | team | relevancy filter | miami heat | 
 | name | french youth teams | nicolas batum | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 200160lb 91 kg | 
 | name | assist | t.j. ford | 
 | height |  | 60 | 
 | weight | may 21 yahoo sports | 165 | 
 | team | september 15, 1980 | indiana pacers | 
 | team | march 25, 1988 | memphis grizzlies | 
 | team | april 20, 1983 | indiana pacers | 
 | height |  | 6160ft1604.75160in 1.95 m | 
 | weight |  | 210160lb 95 kg | 
 | name | recruitment | xavier henry | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | name | assist | raymond felton | 
 | height |  | 61 | 
 | weight | may 21 yahoo sports | 205 | 
 | name | phoenix suns | robin lopez | 
 | team | relevancy filter | phoenix suns | 
 | team | january 16, 1987 | memphis grizzlies | 
 | name | regular season | samuel dalembert | 
 | height | 3.1 | 6160ft16011160in 2.11 m | 
 | weight | 3.1 | 250160lb 113 kg | 
 | name | rebound | kevin durant | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 230 | 
 | name | rebound | jason thompson | 
 | height |  | 611 | 
 | weight | 9.3 | 250 | 
 | team | rank | heat | 
 | height |  | 611 | 
 | name | rookie season | josé calderón | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 210160lb 95 kg | 
 | name | rebound | rudy gay | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 230 | 
 | name | dallas mavericks | jason kidd | 
 | team | relevancy filter | dallas mavericks | 
 | height |  | 60 | 
 | name | rebound | shane battier | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | early years | dwight howard | 
 | team | 2.4.1 | orlando magic | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 265160lb 120 kg | 
 | height |  | 67 | 
 | name | rebound | deandre jordan | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 265 | 
 | height |  | 70 | 
 | team | december 30, 1984 | miami heat | 
 | name | rebound | derrick brown | 
 | height |  | 68 | 
 | weight | 9.6 | 233 | 
 | name | atlanta hawks | jordan crawford | 
 | team | relevancy filter | atlanta hawks | 
 | name | boston celtics | nate robinson | 
 | team | relevancy filter | boston celtics | 
 | name | washington wizards | cartier martin | 
 | team | relevancy filter | washington wizards | 
 | height |  | 610 | 
 | name | rebound | tyler hansbrough | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 250 | 
 | team | rank | jazz | 
 | height |  | 63 | 
 | name | rebound | samuel dalembert | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 250 | 
 | name | rebound | eduardo najera | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | regular season | a. j. price | 
 | height | 4.1 | 6160ft1602160in 1.88 m | 
 | weight | 4.1 | 181160lb 82 kg | 
 | name | nba dleague | donté greene | 
 | height | 4.1 | 6160ft16011160in 2.11 m | 
 | weight | 4.1 | 226160lb 103 kg | 
 | height |  | 63 | 
 | team | rank | net | 
 | height |  | 66 | 
 | team | june 22, 1989 | cleveland cavaliers | 
 | team | july 15, 1989 | new york knicks | 
 | name | 2009 playoffs | trevor ariza | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 210160lb 95 kg | 
 | name | utah jazz | paul millsap | 
 | team | relevancy filter | utah jazz | 
 | team | january 11, 1982 | memphis grizzlies | 
 | name | phoenix suns | matt janning | 
 | team | relevancy filter | phoenix suns | 
 | name | health concerns | etan thomas | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 260160lb 118 kg | 
 | team | december 8, 1985 | orlando magic | 
 | name | regular season | cartier martin | 
 | height | 3.1 | 6160ft1607160in 2.01 m | 
 | weight | 3.1 | 220160lb 100 kg | 
 | height |  | 65 | 
 | name | rebound | patrick patterson | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 235 | 
 | team | february 26, 1980 | los angeles lakers | 
 | name | new orleans hornets | chris paul | 
 | team | relevancy filter | new orleans hornets | 
 | team | march 12, 1979 | golden state warriors | 
 | name | italy | danilo gallinari | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 225160lb 102 kg | 
 | team | august 7, 1989 | toronto raptors | 
 | name | philadelphia 76ers | willie green | 
 | height | 1.1 | 6160ft1603160in 1.91 m | 
 | weight | 1.1 | 201160lb 91 kg | 
 | name | milwaukee bucks | john salmons | 
 | team | relevancy filter | milwaukee bucks | 
 | name | rebound | andris biedrins | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 240 | 
 | team | june 20, 1983 | phoenix suns | 
 | height |  | 66 | 
 | weight | 24 | 201 | 
 | name | entering the nba | yi jianlian | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 250160lb 113 kg | 
 | name | milwaukee bucks | carlos delfino | 
 | team | relevancy filter | milwaukee bucks | 
 | height |  | 66 | 
 | name | new york knicks | eddy curry | 
 | team | relevancy filter | new york knicks | 
 | team | september 7, 1988 | minnesota timberwolves | 
 | name | new jersey nets | troy murphy | 
 | team | relevancy filter | new jersey nets | 
 | height |  | 69 | 
 | weight | 25 | 255 | 
 | height |  | 64 | 
 | name | phoenix suns | josh childress | 
 | team | relevancy filter | phoenix suns | 
 | name | los angeles lakers | matt barnes | 
 | team | relevancy filter | los angeles lakers | 
 | name | memphis grizzlies | sam young | 
 | team | relevancy filter | memphis grizzlies | 
 | name | atlanta hawks | joe johnson | 
 | team | relevancy filter | atlanta hawks | 
 | name | new york knicks | timofey mozgov | 
 | team | relevancy filter | new york knicks | 
 | name | assist | wayne ellington | 
 | height |  | 64 | 
 | weight | 3pt made | 200 | 
 | height |  | 66 | 
 | team | june 13, 1989 | sacramento kings | 
 | name | collegiate career | stephen curry | 
 | height | 1.1 | 6160ft1603160in 1.91 m | 
 | weight | 1.1 | 185160lb 84 kg | 
 | height |  | 67 | 
 | name | chicago bulls | ben gordon | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 200160lb 91 kg | 
 | name | regular season | david west | 
 | height | 6.1 | 6160ft1609160in 2.06 m | 
 | weight | 6.1 | 240160lb 109 kg | 
 | team | may 10, 1987 | new york knicks | 
 | height |  | 610 | 
 | name | assist | jose calderon | 
 | height |  | 63 | 
 | weight | 3pt made | 210 | 
 | height |  | 6160ft16010160in 2.08 m | 
 | weight |  | 255160lb 116 kg | 
 | name | early years | carlos arroyo | 
 | height | 1.1 | 6160ft1602160in 1.88 m | 
 | weight | 1.1 | 202160lb 92 kg | 
 | team | january 29, 1985 | memphis grizzlies | 
 | name | washington wizards | lester hudson | 
 | team | relevancy filter | washington wizards | 
 | team | rank | jazz | 
 | height |  | 68 | 
 | team | march 23, 1990 | utah jazz | 
 | name | portland | zach randolph | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 260160lb 118 kg | 
 | team | july 23, 1984 | portland trail blazers | 
 | name | houston rockets | chase budinger | 
 | team | relevancy filter | houston rockets | 
 | name | miami heat | juwan howard | 
 | team | relevancy filter | miami heat | 
 | height |  | 60 | 
 | team | august 11, 1988 | portland trail blazers | 
 | team | january 3, 1985 | toronto raptors | 
 | name | high school | brandon jennings | 
 | height | 1.1 | 6160ft1601160in 1.85 m | 
 | weight | 1.1 | 169160lb 77 kg | 
 | team | october 27, 1986 | philadelphia 76ers | 
 | name | early college career | rodney carney | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 205160lb 93 kg | 
 | team | may 24, 1979 | detroit pistons | 
 | team | april 30, 1985 | orlando magic | 
 | name | rebound | blake griffin | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 251 | 
 | name | milwaukee bucks | darington hobson | 
 | team | relevancy filter | milwaukee bucks | 
 | team | rank | net | 
 | height |  | 66 | 
 | name | assist | josh childress | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 210 | 
 | name | cleveland cavaliers | leon powe | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | assist | kevin martin | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 185 | 
 | name | philadelphia 76ers | louis williams | 
 | team | relevancy filter | philadelphia 76ers | 
 | name | assist | alonzo gee | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 219 | 
 | team | january 17, 1982 | miami heat | 
 | height |  | 66 | 
 | team | may 18, 1980 | toronto raptors | 
 | height |  | 67 | 
 | name | atlanta hawks | damien wilkins | 
 | team | relevancy filter | atlanta hawks | 
 | team | august 9, 1977 | san antonio spurs | 
 | team | october 24, 1987 | utah jazz | 
 | name | buy now | greg oden | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 285 | 
 | name | rebound | theo ratliff | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 235 | 
 | height |  | 65 | 
 | team | november 29, 1987 | minnesota timberwolves | 
 | name | milwaukee bucks | corey maggette | 
 | team | relevancy filter | milwaukee bucks | 
 | height |  | 61 | 
 | height |  | 61 | 
 | team | august 4, 1987 | philadelphia 76ers | 
 | team | september 18, 1989 | oklahoma city thunder | 
 | name | memphis grizzlies | hasheem thabeet | 
 | team | relevancy filter | memphis grizzlies | 
 | team | april 30, 1980 | houston rockets | 
 | name | new orleans hornets | jason smith | 
 | team | relevancy filter | new orleans hornets | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 242160lb 110 kg | 
 | height |  | 61 | 
 | name | regular season | theo ratliff | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 235160lb 107 kg | 
 | height |  | 68 | 
 | name | new orleans hornets | quincy pondexter | 
 | team | relevancy filter | new orleans hornets | 
 | name | rebound | jordan hill | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | rebound | nikola pekovic | 
 | height |  | 611 | 
 | weight | adidas minnesota timberwolves 10 jonny flynn black net player tshirt | 290 | 
 | name | draft | emeka okafor | 
 | height | 4.1 | 6160ft16010160in 2.08 m | 
 | weight | 4.1 | 255160lb 116 kg | 
 | name | assist | nick young | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 210 | 
 | name | rebound | luke walton | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | rebound | travis outlaw | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 207 | 
 | name | new jersey nets | travis outlaw | 
 | team | relevancy filter | new jersey nets | 
 | team | rank | jazz | 
 | height |  | 61 | 
 | name | assist | sasha pavlovic | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | san antonio spurs | gary neal | 
 | team | relevancy filter | san antonio spurs | 
 | name | philadelphia 76ers | elton brand | 
 | team | relevancy filter | philadelphia 76ers | 
 | name | charlotte bobcats | gerald wallace | 
 | team | relevancy filter | charlotte bobcats | 
 | name | charlotte bobcats | eduardo najera | 
 | team | relevancy filter | charlotte bobcats | 
 | team | february 10, 1986 | golden state warriors | 
 | height |  | 68 | 
 | name | rebound | josh mcroberts | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 240 | 
 | team | april 17, 1984 | chicago bulls | 
 | name | los angeles lakers | andrew bynum | 
 | team | relevancy filter | los angeles lakers | 
 | name | rebound | amir johnson | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 210 | 
 | name | 20062007 | andris biedrins | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | height |  | 69 | 
 | name | assist | larry owens | 
 | height |  | 67 | 
 | weight | 3pt made | 210 | 
 | team | april 22, 1987 | portland trail blazers | 
 | name | assist | andre iguodala | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 207 | 
 | height |  | 69 | 
 | height |  | 6160ft1607160in 2.01 m | 
 | weight |  | 210160lb 95 kg | 
 | name | rebound | anthony tolliver | 
 | height |  | 69 | 
 | weight | 9.3 | 240 | 
 | name | chicago bulls | brian scalabrine | 
 | team | relevancy filter | chicago bulls | 
 | team | may 22, 1988 | houston rockets | 
 | name | rebound | zydrunas ilgauskas | 
 | height |  | 73 | 
 | weight | may 21 yahoo sports | 260 | 
 | height |  | 62 | 
 | team | december 24, 1986 | utah jazz | 
 | name | from golden state to dallas | antawn jamison | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 235160lb 107 kg | 
 | height |  | 70 | 
 | height |  | 70 | 
 | name | cleveland cavaliers | antawn jamison | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | washington wizards | yi jianlian | 
 | team | relevancy filter | washington wizards | 
 | name | new york knicks | raymond felton | 
 | team | relevancy filter | new york knicks | 
 | name | rebound | boris diaw | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | washington wizards | gilbert arenas | 
 | team | relevancy filter | washington wizards | 
 | height |  | 67 | 
 | name | dallas mavericks | ian mahinmi | 
 | team | relevancy filter | dallas mavericks | 
 | team | may 2, 1984 | oklahoma city thunder | 
 | team | november 8, 1978 | atlanta hawks | 
 | name | sacramento kings | pooh jeter | 
 | team | relevancy filter | sacramento kings | 
 | team | january 28, 1984 | philadelphia 76ers | 
 | name | freshman season | sherron marlon collins | 
 | height | 2.1 | 5160ft16011160in 1.80 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | name | rebound | jason maxiell | 
 | height |  | 67 | 
 | weight | adidas detroit pistons 22 tayshaun prince white home swingman basketball jersey | 260 | 
 | team | january 9, 1989 | cleveland cavaliers | 
 | name | early life | tim duncan | 
 | height | 1.1 | 6160ft16011160in 2.11 m | 
 | weight | 1.1 | 260160lb 118 kg | 
 | height |  | 611 | 
 | name | rebound | etan thomas | 
 | height |  | 610 | 
 | weight | 9.3 | 260 | 
 | name | denver nuggets | linas kleiza | 
 | height | 3.1 | 6160ft1608160in 2.03 m | 
 | weight | 3.1 | 245160lb 111 kg | 
 | name | scouting report | juwan howard | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 253160lb 115 kg | 
 | height |  | 66 | 
 | height |  | 611 | 
 | weight | 24 | 260 | 
 | name | boston celtics | von wafer | 
 | team | relevancy filter | boston celtics | 
 | height |  | 67 | 
 | height |  | 68 | 
 | name | toronto raptors | jerryd bayless | 
 | team | relevancy filter | toronto raptors | 
 | name | regular season | eduardo nájera | 
 | height | 5.1 | 6160ft1608160in 2.03 m | 
 | weight | 5.1 | 235160lb 107 kg | 
 | height |  | 70 | 
 | name | rebound | ed davis | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | utah jazz | ronnie price | 
 | team | relevancy filter | utah jazz | 
 | name | oklahoma city thunder | jeff green | 
 | team | relevancy filter | oklahoma city thunder | 
 | team | rank | sun | 
 | height |  | 611 | 
 | team | june 16, 1975 | denver nuggets | 
 | height |  | 610 | 
 | name | europe | josh childress | 
 | height | 3.1 | 6160ft1608160in 2.03 m | 
 | weight | 3.1 | 210160lb 95 kg | 
 | name | orlando magic 2006present | j. j. redick | 
 | height | 3.1 | 6160ft1604160in 1.93 m | 
 | weight | 3.1 | 190160lb 86 kg | 
 | name | rebound | joel anthony | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | rebound | channing frye | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | golden state warriors | louis amundson | 
 | team | relevancy filter | golden state warriors | 
 | height |  | 65 | 
 | name | regular season | charlie villanueva | 
 | height | 8.1 | 6160ft16011160in 2.11 m | 
 | weight | 8.1 | 240160lb 109 kg | 
 | name | rebound | dajuan summers | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 240 | 
 | height |  | 70 | 
 | name | regular season | charlie bell | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 200160lb 91 kg | 
 | name | denver nuggets | al harrington | 
 | team | relevancy filter | denver nuggets | 
 | height |  | 6160ft1606160in 1.98 m | 
 | weight |  | 225160lb 102 kg | 
 | team | rank | heat | 
 | height |  | 67 | 
 | weight | 22 | 230 | 
 | name | nba career | timofey mozgov | 
 | height | 1.1 | 7160ft1601160in 2.16 m | 
 | weight | 1.1 | 270160lb 122 kg | 
 | name | rebound | david andersen | 
 | height |  | 611 | 
 | weight | adidas new orleans hornets 3 chris paul teal road swingman basketball jersey | 245 | 
 | name | freshman year | manny harris | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 192160lb 87 kg | 
 | height |  | 63 | 
 | name | rebound | nenad krstic | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | orlando magic | jason williams | 
 | team | relevancy filter | orlando magic | 
 | name | toronto raptors | andrea bargnani | 
 | team | relevancy filter | toronto raptors | 
 | name | early career | pau gasol | 
 | height | 1.1 | 7160ft1600160in 2.13 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | name | rebound | demarcus cousins | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 270 | 
 | name | rebound | shawne williams | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 225 | 
 | name | boston celtics | jermaine oneal | 
 | team | relevancy filter | boston celtics | 
 | name | assist | charlie bell | 
 | height |  | 63 | 
 | weight | 3pt made | 200 | 
 | name | atlanta hawks | jeff teague | 
 | team | relevancy filter | atlanta hawks | 
 | team | february 14, 1978 | detroit pistons | 
 | name | los angeles clippers | ryan gomes | 
 | team | relevancy filter | los angeles clippers | 
 | name | high school | demarre carroll | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 225160lb 102 kg | 
 | name | phoenix suns 2002–10 | amare stoudemire | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 249160lb 113 kg | 
 | height |  | 67 | 
 | weight | 24 | 230 | 
 | team | january 13, 1977 | indiana pacers | 
 | name | nba playoffs | j. r. smith | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | team | november 26, 1982 | sacramento kings | 
 | name | assist | dorell wright | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 210 | 
 | height |  | 610 | 
 | name | 2008–09 | corey maggette | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 225160lb 102 kg | 
 | name | los angeles clippers | eric gordon | 
 | team | relevancy filter | los angeles clippers | 
 | name | assist | xavier henry | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 220 | 
 | height |  | 64 | 
 | team | january 2, 1988 | boston celtics | 
 | height |  | 65 | 
 | team | february 21, 1988 | sacramento kings | 
 | team | february 28, 1976 | utah jazz | 
 | name | rebound | greg monroe | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 253 | 
 | height |  | 68 | 
 | name | rebound | thaddeus young | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | college statistics | jermaine taylor | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 210160lb 95 kg | 
 | name | rebound | timofey mozgov | 
 | height |  | 71 | 
 | weight | may 21 yahoo sports | 250 | 
 | height |  | 70 | 
 | height |  | 62 | 
 | name | assist | rasual butler | 
 | height |  | 67 | 
 | weight | 3pt made | 215 | 
 | team | june 24, 1985 | chicago bulls | 
 | height |  | 60 | 
 | name | minnesota timberwolves | michael beasley | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | february 25, 1985 | denver nuggets | 
 | name | regular season | jason kapono | 
 | height | 6.1 | 6160ft1608160in 2.03 m | 
 | weight | 6.1 | 215160lb 98 kg | 
 | name | rebound | hilton armstrong | 
 | height |  | 611 | 
 | weight | 9.3 | 235 | 
 | name | assist | sasha vujacic | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 205 | 
 | name | buy now | terrico white | 
 | height | adidas detroit pistons 32 richard hamilton royal blue road swingman basketball jersey | 65 | 
 | weight | adidas detroit pistons 32 richard hamilton royal blue road swingman basketball jersey | 213 | 
 | name | rebound | michael beasley | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 230 | 
 | name | golden state warriors | reggie williams | 
 | team | relevancy filter | golden state warriors | 
 | name | assist | zabian dowdell | 
 | height |  | 63 | 
 | weight | 3pt made | 190 | 
 | name | san antonio spurs | ime udoka | 
 | team | relevancy filter | san antonio spurs | 
 | height |  | 62 | 
 | name | assist | sonny weems | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 205 | 
 | name | toronto raptors | jose calderon | 
 | team | relevancy filter | toronto raptors | 
 | name | regular season | dahntay jones | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 210160lb 95 kg | 
 | height |  | 66 | 
 | name | argentina and spain | andrés nocioni | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 225160lb 102 kg | 
 | name | pro career | david andersen | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 247160lb 112 kg | 
 | team | may 2, 1980 | new jersey nets | 
 | name | miami heat | zydrunas ilgauskas | 
 | team | relevancy filter | miami heat | 
 | team | february 17, 1980 | denver nuggets | 
 | height |  | 70 | 
 | name | indiana pacers | jeff foster | 
 | team | relevancy filter | indiana pacers | 
 | name | rebound | hamady ndiaye | 
 | height |  | 70 | 
 | weight | 8.7 | 235 | 
 | height |  | 610 | 
 | team | rank | jazz | 
 | height |  | 65 | 
 | name | indiana pacers | darren collison | 
 | team | relevancy filter | indiana pacers | 
 | name | dallas mavericks | dominique jones | 
 | team | relevancy filter | dallas mavericks | 
 | name | assist | eric maynor | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 170 | 
 | name | assist | john salmons | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 207 | 
 | name | freshman year | evan turner | 
 | height | 3.1 | 6160ft1607160in 2.01 m | 
 | weight | 3.1 | 210160lb 95 kg | 
 | name | toronto raptors | sonny weems | 
 | team | relevancy filter | toronto raptors | 
 | name | new jersey nets | derrick favors | 
 | team | relevancy filter | new jersey nets | 
 | name | rebound | danny granger | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 228 | 
 | name | regular season | leandro barbosa | 
 | height | 5.1 | 6160ft1603160in 1.91 m | 
 | weight | 5.1 | 202160lb 92 kg | 
 | name | regular season | rodney stuckey | 
 | height | 4.1 | 6160ft1605160in 1.96 m | 
 | weight | 4.1 | 205160lb 93 kg | 
 | name | los angeles lakers | pau gasol | 
 | team | relevancy filter | los angeles lakers | 
 | name | rebound | grant hill | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 225 | 
 | height |  | 62 | 
 | name | charlotte bobcats | kwame brown | 
 | team | relevancy filter | charlotte bobcats | 
 | name | houston rockets | patrick patterson | 
 | team | relevancy filter | houston rockets | 
 | name | rebound | charlie villanueva | 
 | height |  | 611 | 
 | weight | 9.6 | 232 | 
 | team | october 23, 1988 | atlanta hawks | 
 | name | assist | paul george | 
 | height |  | 68 | 
 | weight | may 12 yahoo contributor network | 210 | 
 | name | assist | a.j. price | 
 | height |  | 62 | 
 | weight | 3pt made | 181 | 
 | name | phoenix suns | grant hill | 
 | team | relevancy filter | phoenix suns | 
 | name | rebound | garret siler | 
 | height |  | 611 | 
 | weight | 8.7 | 304 | 
 | name | sacramento kings | omri casspi | 
 | team | relevancy filter | sacramento kings | 
 | height |  | 611 | 
 | name | indiana pacers | brandon rush | 
 | team | relevancy filter | indiana pacers | 
 | name | regular season | patrick mills | 
 | height | 5.1 | 6160ft1600160in 1.83 m | 
 | weight | 5.1 | 185160lb 84 kg | 
 | height |  | 611 | 
 | name | oklahoma city thunder | thabo sefolosha | 
 | team | relevancy filter | oklahoma city thunder | 
 | team | june 5, 1987 | new orleans hornets | 
 | height |  | 63 | 
 | team | may 23, 1979 | los angeles clippers | 
 | height |  | 68 | 
 | name | miami heat | jamaal magloire | 
 | team | relevancy filter | miami heat | 
 | name | san antonio spurs | matt bonner | 
 | team | relevancy filter | san antonio spurs | 
 | name | regular season | quinton ross | 
 | height | 4.1 | 6160ft1606160in 1.98 m | 
 | weight | 4.1 | 193160lb 88 kg | 
 | name | nba draft | lamarcus aldridge | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | height |  | 63 | 
 | weight | 23 | 200 | 
 | height |  | 611 | 
 | name | freshman | hakim warrick | 
 | team | 3.2.1 | phoenix suns | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 219160lb 99 kg | 
 | name | charlotte bobcats | derrick brown | 
 | team | relevancy filter | charlotte bobcats | 
 | name | europe | rudy fernández | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 185160lb 84 kg | 
 | name | sacramento kings | samuel dalembert | 
 | team | relevancy filter | sacramento kings | 
 | height |  | 67 | 
 | name | san antonio spurs | antonio mcdyess | 
 | team | relevancy filter | san antonio spurs | 
 | name | rebound | kenyon martin | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 240 | 
 | height |  | 66 | 
 | height |  | 68 | 
 | height |  | 611 | 
 | height |  | 67 | 
 | height |  | 611 | 
 | name | houston rockets | kyle lowry | 
 | team | relevancy filter | houston rockets | 
 | name | minnesota timberwolves | maurice ager | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | april 17, 1973 | los angeles lakers | 
 | name | assist | richard hamilton | 
 | height |  | 67 | 
 | weight | 3pt made | 193 | 
 | height |  | 67 | 
 | name | assist | marcus thornton | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 205 | 
 | height |  | 611 | 
 | name | houston rockets | chuck hayes | 
 | team | relevancy filter | houston rockets | 
 | name | boston celtics | luke harangody | 
 | team | relevancy filter | boston celtics | 
 | name | rebound | larry sanders | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 235 | 
 | team | rank | sun | 
 | height |  | 60 | 
 | name | chicago bulls | c.j. watson | 
 | team | relevancy filter | chicago bulls | 
 | name | assist | james jones | 
 | height |  | 68 | 
 | weight | may 21 miami herald | 215 | 
 | name | rebound | steve novak | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | sacramento kings | donte greene | 
 | team | relevancy filter | sacramento kings | 
 | name | rebound | brian cook | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 250 | 
 | height |  | 65 | 
 | height |  | 511 | 
 | height |  | 68 | 
 | name | regular season | kosta koufos | 
 | height | 7.1 | 7160ft1600160in 2.13 m | 
 | weight | 7.1 | 265160lb 120 kg | 
 | team | december 25, 1988 | los angeles clippers | 
 | height |  | 69 | 
 | name | charlotte bobcats | jared dudley | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 235160lb 107 kg | 
 | name | regular season | erick dampier | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 265160lb 120 kg | 
 | name | regular season | andray blatche | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 260160lb 118 kg | 
 | name | rebound | carl landry | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 248 | 
 | name | assist | stephen graham | 
 | height |  | 66 | 
 | weight | may 10 yahoo sports | 215 | 
 | height |  | 7160ft1600160in 2.13 m | 
 | weight |  | 235160lb 107 kg | 
 | height |  | 71 | 
 | name | nba development league | sonny weems | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 203160lb 92 kg | 
 | name | assist | donte greene | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 226 | 
 | height |  | 611 | 
 | team | january 16, 1977 | indiana pacers | 
 | name | rebound | robin lopez | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 255 | 
 | height |  | 67 | 
 | team | september 9, 1985 | denver nuggets | 
 | height |  | 6160ft1601160in 1.85 m | 
 | weight |  | 190160lb 86 kg | 
 | name | dallas mavericks | deshawn stevenson | 
 | team | relevancy filter | dallas mavericks | 
 | name | rebound | cole aldrich | 
 | height |  | 611 | 
 | weight | 8.7 | 245 | 
 | name | orlando magic | chris duhon | 
 | team | relevancy filter | orlando magic | 
 | name | early life | luke walton | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 235160lb 107 kg | 
 | name | assist | baron davis | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | assist | kirk hinrich | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 190 | 
 | name | utah jazz | maurice williams | 
 | height | 2.1 | 6160ft1601160in 1.85 m | 
 | weight | 2.1 | 190160lb 86 kg | 
 | team | rank | jazz | 
 | height |  | 66 | 
 | name | minnesota timberwolves 2006–2009 | randy foye | 
 | height | 2.1 | 6160ft1604160in 1.93 m | 
 | weight | 2.1 | 213160lb 97 kg | 
 | name | washington wizards | nick young | 
 | team | relevancy filter | washington wizards | 
 | height |  | 63 | 
 | weight | 26 | 190 | 
 | team | rank | heat | 
 | height |  | 610 | 
 | team | august 20, 1988 | toronto raptors | 
 | name | orlando magic | vince carter | 
 | team | relevancy filter | orlando magic | 
 | name | detroit pistons | tracy mcgrady | 
 | team | relevancy filter | detroit pistons | 
 | team | july 28, 1977 | san antonio spurs | 
 | name | regular season | brandon bass | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | height |  | 68 | 
 | height |  | 6160ft1600160in 1.83 m | 
 | weight |  | 180160lb 82 kg | 
 | name | detroit pistons | terrico white | 
 | team | relevancy filter | detroit pistons | 
 | name | rebound | darnell jackson | 
 | height |  | 69 | 
 | weight | 9.6 | 253 | 
 | name | europe | nikola peković | 
 | height | 1.1 | 6160ft16011160in 2.11 m | 
 | weight | 1.1 | 265160lb 120 kg | 
 | team | june 19, 1975 | cleveland cavaliers | 
 | name | rebound | hedo turkoglu | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | rebound | carlos boozer | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 266 | 
 | name | charlotte bobcats | boris diaw | 
 | team | relevancy filter | charlotte bobcats | 
 | name | regular season | marcin gortat | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | height |  | 64 | 
 | name | portland trail blazers | patrick mills | 
 | team | relevancy filter | portland trail blazers | 
 | name | orlando magic | malik allen | 
 | team | relevancy filter | orlando magic | 
 | name | assist | kyle korver | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 212 | 
 | height |  | 66 | 
 | height |  | 6160ft1605160in 1.96 m | 
 | weight |  | 203160lb 92 kg | 
 | name | regular season | desagana diop | 
 | height | 4.1 | 7160ft1600160in 2.13 m | 
 | weight | 4.1 | 280160lb 127 kg | 
 | team | february 10, 1984 | atlanta hawks | 
 | height |  | 63 | 
 | team | march 19, 1976 | portland trail blazers | 
 | name | rebound | ryan hollins | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 240 | 
 | team | june 1, 1985 | minnesota timberwolves | 
 | name | assist | pooh jeter | 
 | height |  | 511 | 
 | weight | 3pt made | 175 | 
 | name | toronto raptors 1998–2004 | vince carter | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | name | milwaukee bucks | drew gooden | 
 | team | relevancy filter | milwaukee bucks | 
 | team | rank | heat | 
 | height |  | 69 | 
 | team | february 24, 1988 | dallas mavericks | 
 | team | july 30, 1979 | miami heat | 
 | name | rebound | spencer hawes | 
 | height |  | 71 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | 2005–06 | andy rautins | 
 | height | 3.1 | 6160ft1605160in 1.96 m | 
 | weight | 3.1 | 205160lb 93 kg | 
 | name | assist | john wall | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 195 | 
 | height |  | 61 | 
 | name | childhood and youth | kobe bryant | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 205160lb 93 kg | 
 | name | rebound | lamar odom | 
 | height |  | 610 | 
 | weight | may 20 yahoo contributor network | 230 | 
 | name | assist | ty lawson | 
 | height |  | 511 | 
 | weight | may 18 yahoo contributor network | 195 | 
 | name | rebound | hamed haddadi | 
 | height |  | 72 | 
 | weight | may 21 yahoo sports | 265 | 
 | name | regular season | jrue holiday | 
 | height | 4.1 | 6160ft1604160in 1.93 m | 
 | weight | 4.1 | 180160lb 82 kg | 
 | height |  | 6160ft1603160in 1.91 m | 
 | weight |  | 205160lb 93 kg | 
 | height |  | 6160ft1607160in 2.01 m | 
 | weight |  | 220160lb 100 kg | 
 | name | assist | shannon brown | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 210 | 
 | name | rebound | reggie evans | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | assist | keyon dooling | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 195 | 
 | name | assist | carlos delfino | 
 | height |  | 66 | 
 | weight | 3pt made | 230 | 
 | name | college statistics | james johnson | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 245160lb 111 kg | 
 | name | buy now | elliot williams | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 183 | 
 | name | houston rockets | jared jeffries | 
 | team | relevancy filter | houston rockets | 
 | height |  | 6160ft1606160in 1.98 m | 
 | weight |  | 210160lb 95 kg | 
 | team | november 2, 1986 | new york knicks | 
 | name | new orleans hornets | trevor ariza | 
 | team | relevancy filter | new orleans hornets | 
 | name | rebound | matt bonner | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | cleveland cavaliers | anthony parker | 
 | team | relevancy filter | cleveland cavaliers | 
 | team | may 10, 1981 | sacramento kings | 
 | team | may 4, 1986 | san antonio spurs | 
 | name | 2003–04 | semih erden | 
 | height | 1.1 | 7160ft1600160in 2.13 m | 
 | weight | 1.1 | 240160lb 109 kg | 
 | height |  | 611 | 
 | weight | 24 | 225 | 
 | name | orlando magic | jameer nelson | 
 | team | relevancy filter | orlando magic | 
 | name | new york knicks | ronny turiaf | 
 | team | relevancy filter | new york knicks | 
 | height |  | 7160ft1600160in 2.13 m | 
 | weight |  | 255160lb 116 kg | 
 | height |  | 69 | 
 | name | rebound | antonio mcdyess | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | assist | matt barnes | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 226 | 
 | name | rebound | brook lopez | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 265 | 
 | name | rebound | brian scalabrine | 
 | height |  | 69 | 
 | weight | may 10 yahoo contributor network | 235 | 
 | name | regular season | chris quinn | 
 | height | 4.1 | 6160ft1602160in 1.88 m | 
 | weight | 4.1 | 175160lb 79 kg | 
 | team | may 2, 1977 | dallas mavericks | 
 | height |  | 6160ft1605160in 1.96 m | 
 | weight |  | 180160lb 82 kg | 
 | name | regular season | nazr mohammed | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 250160lb 113 kg | 
 | name | chinese basketball association | garret siler | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 280160lb 127 kg | 
 | name | regular season | jarrett jack | 
 | height | 4.1 | 6160ft1603160in 1.91 m | 
 | weight | 4.1 | 197160lb 89 kg | 
 | team | june 9, 1980 | miami heat | 
 | team | october 11, 1987 | memphis grizzlies | 
 | name | purdue | brad miller | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 261160lb 118 kg | 
 | height |  | 65 | 
 | name | assist | randy foye | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 213 | 
 | name | seattle supersonics | luke ridnour | 
 | height | 3.1 | 6160ft1602160in 1.88 m | 
 | weight | 3.1 | 175160lb 79 kg | 
 | name | rebound | dominic mcguire | 
 | height |  | 69 | 
 | weight | 9.6 | 235 | 
 | name | golden state warriors | andris biedrins | 
 | team | relevancy filter | golden state warriors | 
 | team | rank | heat | 
 | height |  | 61 | 
 | team | april 28, 1988 | philadelphia 76ers | 
 | team | october 15, 1988 | dallas mavericks | 
 | name | new orleans hornets | joe alexander | 
 | team | relevancy filter | new orleans hornets | 
 | height |  | 69 | 
 | name | assist | wesley matthews | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 200 | 
 | name | rebound | ronny turiaf | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 247 | 
 | name | phoenix suns | channing frye | 
 | team | relevancy filter | phoenix suns | 
 | name | denver nuggets | carmelo anthony | 
 | team | relevancy filter | denver nuggets | 
 | height |  | 68 | 
 | name | boston celtics | glen davis | 
 | team | relevancy filter | boston celtics | 
 | height |  | 69 | 
 | name | rebound | earl clark | 
 | height |  | 610 | 
 | weight | 9.6 | 225 | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 264160lb 120 kg | 
 | name | los angeles clippers | randy foye | 
 | team | relevancy filter | los angeles clippers | 
 | name | dallas mavericks | shawn marion | 
 | team | relevancy filter | dallas mavericks | 
 | team | april 5, 1978 | charlotte bobcats | 
 | name | rebound | tiago splitter | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | 20042006 | shaun livingston | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 185160lb 84 kg | 
 | name | assist | chauncey billups | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 202 | 
 | name | 2007–2008 | delonte west | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 180160lb 82 kg | 
 | height |  | 67 | 
 | height |  | 65 | 
 | team | march 23, 1973 | dallas mavericks | 
 | height |  | 70 | 
 | height |  | 610 | 
 | name | draft | rudy gay | 
 | height | 4.1 | 6160ft1608160in 2.03 m | 
 | weight | 4.1 | 230160lb 104 kg | 
 | team | february 6, 1989 | minnesota timberwolves | 
 | name | college statistics | wayne ellington jr. | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 202160lb 92 kg | 
 | height |  | 67 | 
 | name | portland trail blazers | nicolas batum | 
 | team | relevancy filter | portland trail blazers | 
 | name | phoenix suns | hakim warrick | 
 | team | relevancy filter | phoenix suns | 
 | name | detroit pistons | tayshaun prince | 
 | team | relevancy filter | detroit pistons | 
 | height |  | 64 | 
 | team | march 20, 1987 | milwaukee bucks | 
 | name | sacramento kings | tyreke evans | 
 | team | relevancy filter | sacramento kings | 
 | team | june 12, 1979 | utah jazz | 
 | height |  | 62 | 
 | height |  | 66 | 
 | height |  | 611 | 
 | height |  | 69 | 
 | team | august 28, 1980 | charlotte bobcats | 
 | name | assist | patty mills | 
 | height |  | 60 | 
 | weight | 3pt made | 185 | 
 | name | rebound | tyrus thomas | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 225 | 
 | team | november 10, 1983 | los angeles clippers | 
 | height |  | 66 | 
 | name | portland trail blazers | elliot williams | 
 | team | relevancy filter | portland trail blazers | 
 | name | milwaukee bucks | ersan ilyasova | 
 | team | relevancy filter | milwaukee bucks | 
 | team | august 28, 1986 | oklahoma city thunder | 
 | height |  | 610 | 
 | height |  | 66 | 
 | name | seattle supersonics | vladimir radmanović | 
 | team | 2.3.1 | golden state warriors | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 234160lb 106 kg | 
 | name | sacramento kings | carl landry | 
 | team | relevancy filter | sacramento kings | 
 | name | rebound | paul millsap | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 250 | 
 | height |  | 610 | 
 | team | september 28, 1981 | toronto raptors | 
 | name | regular season | jeff foster | 
 | height | 1.1 | 6160ft16011160in 2.11 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | team | july 14, 1984 | denver nuggets | 
 | name | rebound | andrew bynum | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 285 | 
 | height |  | 62 | 
 | weight | 20 | 195 | 
 | team | june 20, 1989 | portland trail blazers | 
 | height |  | 68 | 
 | name | philadelphia 76ers | craig brackins | 
 | team | relevancy filter | philadelphia 76ers | 
 | name | regular season | julian wright | 
 | height | 5.1 | 6160ft1608160in 2.03 m | 
 | weight | 5.1 | 225160lb 102 kg | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 215160lb 98 kg | 
 | team | september 13, 1982 | denver nuggets | 
 | name | new jersey nets | johan petro | 
 | team | relevancy filter | new jersey nets | 
 | team | march 8, 1984 | los angeles lakers | 
 | team | may 17, 1982 | san antonio spurs | 
 | name | philadelphia 76ers | evan turner | 
 | team | relevancy filter | philadelphia 76ers | 
 | name | dallas mavericks | josh howard | 
 | team | 3.1.1 | washington wizards | 
 | height | 3.1 | 6160ft1607160in 2.01 m | 
 | weight | 3.1 | 210160lb 95 kg | 
 | name | new york knicks | nate robinson | 
 | team | 3.1.1 | boston celtics | 
 | height | 3.1 | 5160ft1609160in 1.75 m | 
 | weight | 3.1 | 180160lb 82 kg | 
 | height |  | 610 | 
 | name | cleveland cavaliers | jamario moon | 
 | team | relevancy filter | cleveland cavaliers | 
 | team | october 4, 1980 | miami heat | 
 | height |  | 70 | 
 | height |  | 69 | 
 | team | december 8, 1986 | houston rockets | 
 | height |  | 65 | 
 | name | rebound | brendan haywood | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 263 | 
 | name | rebound | dj mbenga | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 255 | 
 | name | assist | marco belinelli | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 200 | 
 | team | june 19, 1978 | dallas mavericks | 
 | name | indiana pacers | dahntay jones | 
 | team | relevancy filter | indiana pacers | 
 | name | regular season | stephen graham | 
 | height | 3.1 | 6160ft1606160in 1.98 m | 
 | weight | 3.1 | 215160lb 98 kg | 
 | height |  | 611 | 
 | name | cleveland cavaliers | andre miller | 
 | height | 2.1 | 6160ft1602160in 1.88 m | 
 | weight | 2.1 | 205160lb 93 kg | 
 | name | rebound | lamarcus aldridge | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 246 | 
 | height |  | 62 | 
 | name | wake forest | jeff teague | 
 | team | 1.1.1 | atlanta hawks | 
 | height | 1.1 | 6160ft1602160in 1.88 m | 
 | weight | 1.1 | 180160lb 82 kg | 
 | name | rebound | roy hibbert | 
 | height |  | 72 | 
 | weight | may 11 yahoo sports | 278 | 
 | height |  | 62 | 
 | height |  | 6160ft1605160in 1.96 m | 
 | weight |  | 210160lb 95 kg | 
 | name | assist | chris quinn | 
 | height |  | 62 | 
 | weight | 3pt made | 175 | 
 | name | chicago bulls | carlos boozer | 
 | team | relevancy filter | chicago bulls | 
 | name | assist | andy rautins | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 195 | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 225160lb 102 kg | 
 | name | minnesota timberwolves | darko milicic | 
 | team | relevancy filter | minnesota timberwolves | 
 | name | rebound | al thornton | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | oklahoma city thunder | cole aldrich | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | rookie season | carmelo anthony | 
 | height | 3.1 | 6160ft1608160in 2.03 m | 
 | weight | 3.1 | 228160lb 103 kg | 
 | name | los angeles lakers | steve blake | 
 | team | relevancy filter | los angeles lakers | 
 | name | cleveland cavaliers | daniel gibson | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | oklahoma city thunder | byron mullens | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | portland trail blazers | fabricio oberto | 
 | team | relevancy filter | portland trail blazers | 
 | height |  | 68 | 
 | team | rank | heat | 
 | height |  | 68 | 
 | name | san antonio spurs | richard jefferson | 
 | team | relevancy filter | san antonio spurs | 
 | name | 20092010 rookie season | tyreke evans | 
 | team | 3.2.1 | sacramento kings | 
 | height | 3.1 | 6160ft1606160in 1.98 m | 
 | weight | 3.1 | 220160lb 100 kg | 
 | name | assist | eric gordon | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | 2006–07 | eric maynor | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 175160lb 79 kg | 
 | height |  | 65 | 
 | name | minnesota timberwolves | sebastian telfair | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | february 18, 1981 | utah jazz | 
 | team | january 4, 1985 | utah jazz | 
 | name | minnesota timberwolves | wes johnson | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | august 24, 1984 | detroit pistons | 
 | height |  | 68 | 
 | name | miami heat | carlos arroyo | 
 | team | relevancy filter | miami heat | 
 | height |  | 62 | 
 | height |  | 68 | 
 | name | rebound | carmelo anthony | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 238 | 
 | name | phoenix suns | goran dragic | 
 | team | relevancy filter | phoenix suns | 
 | team | august 23, 1975 | portland trail blazers | 
 | name | cleveland cavaliers | drew gooden | 
 | height | 4.1 | 6160ft16010160in 2.08 m | 
 | weight | 4.1 | 250160lb 113 kg | 
 | name | regular season | jared jeffries | 
 | height | 4.1 | 6160ft16011160in 2.11 m | 
 | weight | 4.1 | 240160lb 109 kg | 
 | name | rebound | dirk nowitzki | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 245 | 
 | team | december 7, 1982 | golden state warriors | 
 | name | assist | chase budinger | 
 | height |  | 67 | 
 | weight | 3pt made | 218 | 
 | name | portland trail blazers | sebastian telfair | 
 | height | 1.1 | 6160ft1600160in 1.83 m | 
 | weight | 1.1 | 175160lb 79 kg | 
 | name | rebound | quincy pondexter | 
 | height |  | 66 | 
 | weight | 9.6 | 225 | 
 | name | boston celtics | avery bradley | 
 | team | relevancy filter | boston celtics | 
 | team | rank | net | 
 | height |  | 611 | 
 | name | regular season | ramon sessions | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 190160lb 86 kg | 
 | name | assist | demar derozan | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | regular season | jarron collins | 
 | height | 4.1 | 6160ft16011160in 2.11 m | 
 | weight | 4.1 | 248160lb 112 kg | 
 | name | assist | steve nash | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 178 | 
 | height |  | 67 | 
 | height |  | 69 | 
 | team | august 29, 1982 | milwaukee bucks | 
 | name | assist | dwyane wade | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | argentina | luis scola | 
 | team | 1.2.1 | houston rockets | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 245160lb 111 kg | 
 | name | rebound | jason smith | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | record | shelden williams | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 250160lb 113 kg | 
 | name | vincennes | carl landry | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 248160lb 112 kg | 
 | height |  | 64 | 
 | height |  | 69 | 
 | height |  | 610 | 
 | name | houston rockets | kevin martin | 
 | team | relevancy filter | houston rockets | 
 | name | indiana pacers | danny granger | 
 | team | relevancy filter | indiana pacers | 
 | name | toronto raptors | morris peterson | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | height |  | 61 | 
 | weight | 23 | 201 | 
 | height |  | 65 | 
 | name | rebound | andray blatche | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 260 | 
 | team | april 13, 1979 | los angeles clippers | 
 | name | new york knicks | andy rautins | 
 | team | relevancy filter | new york knicks | 
 | name | rebound | al horford | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 245 | 
 | team | november 12, 1979 | milwaukee bucks | 
 | height |  | 69 | 
 | name | new jersey nets | joe smith | 
 | team | relevancy filter | new jersey nets | 
 | team | february 2, 1978 | golden state warriors | 
 | team | october 21, 1983 | denver nuggets | 
 | name | rebound | kevin love | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 260 | 
 | team | april 28, 1980 | washington wizards | 
 | height |  | 61 | 
 | team | october 26, 1985 | golden state warriors | 
 | height |  | 611 | 
 | name | memphis grizzlies | mike conley | 
 | team | relevancy filter | memphis grizzlies | 
 | name | rebound | juwan howard | 
 | height |  | 69 | 
 | weight | may 21 miami herald | 250 | 
 | team | september 21, 1990 | los angeles clippers | 
 | height |  | 67 | 
 | team | february 23, 1989 | portland trail blazers | 
 | height |  | 67 | 
 | height |  | 66 | 
 | weight | 27 | 240 | 
 | name | rebound | james johnson | 
 | height |  | 69 | 
 | weight | 9.6 | 245 | 
 | name | seattle supersonics | rashard lewis | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 230160lb 104 kg | 
 | team | june 29, 1981 | atlanta hawks | 
 | height |  | 65 | 
 | height |  | 69 | 
 | name | assist | george hill | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 180 | 
 | name | assist | james harden | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | utah jazz | deron williams | 
 | team | relevancy filter | utah jazz | 
 | name | san antonio spurs | bobby simmons | 
 | team | relevancy filter | san antonio spurs | 
 | height |  | 63 | 
 | weight | 30 | 190 | 
 | name | assist | ramon sessions | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 190 | 
 | name | washington wizards | alonzo gee | 
 | team | relevancy filter | washington wizards | 
 | name | assist | rajon rondo | 
 | height |  | 61 | 
 | weight | may 21 yahoo sports | 186 | 
 | name | assist | earl boykins | 
 | height |  | 55 | 
 | weight | may 21 yahoo sports | 135 | 
 | team | october 27, 1988 | philadelphia 76ers | 
 | name | rebound | vladimir radmanovic | 
 | height |  | 610 | 
 | weight | 9.6 | 235 | 
 | name | western kentucky university | courtney lee | 
 | height | 1.1 | 6160ft1605160in 1.96 m | 
 | weight | 1.1 | 200160lb 91 kg | 
 | name | minnesota timberwolves | corey brewer | 
 | team | relevancy filter | minnesota timberwolves | 
 | height |  | 611 | 
 | name | assist | nicolas batum | 
 | height |  | 68 | 
 | weight | 3pt made | 210 | 
 | name | rebound | al jefferson | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 280 | 
 | name | rebound | omer asik | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 255 | 
 | name | assist | deshawn stevenson | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 218 | 
 | name | philadelphia 76ers | darius songaila | 
 | team | relevancy filter | philadelphia 76ers | 
 | team | april 2, 1986 | golden state warriors | 
 | name | toronto raptors | linas kleiza | 
 | team | relevancy filter | toronto raptors | 
 | name | amateur career | pops mensahbonsu | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 240160lb 109 kg | 
 | height |  | 69 | 
 | height |  | 61 | 
 | name | rebound | alexis ajinca | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 262 | 
 | team | september 19, 1976 | utah jazz | 
 | height |  | 65 | 
 | height |  | 69 | 
 | height |  | 67 | 
 | team | march 24, 1984 | miami heat | 
 | name | assist | carlos arroyo | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 200 | 
 | name | portland trail blazers | rudy fernandez | 
 | team | relevancy filter | portland trail blazers | 
 | height |  | 610 | 
 | name | rebound | taj gibson | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 225 | 
 | name | assist | jordan crawford | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 195 | 
 | name | amare stoudemire | amar 039e stoudemire | 
 | name | rebound | gerald wallace | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 220 | 
 | height |  | 62 | 
 | name | dallas mavericks | dirk nowitzki | 
 | team | relevancy filter | dallas mavericks | 
 | name | nba career statistics | kris humphries | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 235160lb 107 kg | 
 | team | september 7, 1974 | san antonio spurs | 
 | team | december 5, 1982 | new york knicks | 
 | name | early career | ben wallace | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 240160lb 109 kg | 
 | name | united states | kevin garnett | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 253160lb 115 kg | 
 | name | rebound | malik allen | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 255 | 
 | height |  | 611 | 
 | name | atlanta hawks | josh powell | 
 | team | relevancy filter | atlanta hawks | 
 | name | regular season | jason collins | 
 | height | 2.1 | 7160ft1600160in 2.13 m | 
 | weight | 2.1 | 255160lb 116 kg | 
 | height |  | 70 | 
 | weight | 24 | 245 | 
 | team | september 9, 1986 | milwaukee bucks | 
 | name | boston celtics | marquis daniels | 
 | team | relevancy filter | boston celtics | 
 | team | october 26, 1985 | toronto raptors | 
 | team | june 27, 1988 | new york knicks | 
 | team | march 10, 1988 | new orleans hornets | 
 | height |  | 69 | 
 | weight | 23 | 240 | 
 | height |  | 611 | 
 | name | rebound | nene hilario | 
 | height |  | 611 | 
 | weight | 8.7 | 250 | 
 | name | rebound | rashard lewis | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 230 | 
 | team | november 21, 1982 | chicago bulls | 
 | name | rebound | desagana diop | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 280 | 
 | team | january 2, 1981 | washington wizards | 
 | name | rebound | al harrington | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 250 | 
 | height |  | 69 | 
 | name | rebound | joel przybilla | 
 | height |  | 71 | 
 | weight | may 21 yahoo sports | 259 | 
 | name | regular season | brian skinner | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 255160lb 116 kg | 
 | height |  | 69 | 
 | name | assist | eric bledsoe | 
 | height |  | 61 | 
 | weight | may 21 yahoo sports | 195 | 
 | name | san antonio spurs | chris quinn | 
 | team | relevancy filter | san antonio spurs | 
 | team | rank | net | 
 | height |  | 610 | 
 | name | oklahoma city thunder | morris peterson | 
 | team | relevancy filter | oklahoma city thunder | 
 | team | june 13, 1980 | cleveland cavaliers | 
 | height |  | 6160ft16011160in 2.11 m | 
 | weight |  | 235160lb 107 kg | 
 | name | regular season | joel przybilla | 
 | height | 4.1 | 7160ft1601160in 2.16 m | 
 | weight | 4.1 | 245160lb 111 kg | 
 | team | rank | jazz | 
 | height |  | 70 | 
 | height |  | 76 | 
 | team | rank | jazz | 
 | height |  | 62 | 
 | name | indiana pacers | james posey | 
 | team | relevancy filter | indiana pacers | 
 | name | rebound | brandon bass | 
 | height |  | 68 | 
 | weight | may 10 yahoo sports | 250 | 
 | team | july 23, 1982 | charlotte bobcats | 
 | team | may 19, 1985 | memphis grizzlies | 
 | team | january 14, 1985 | houston rockets | 
 | name | high school | steve blake | 
 | height | 1.1 | 6160ft1603160in 1.91 m | 
 | weight | 1.1 | 172160lb 78 kg | 
 | team | rank | sun | 
 | height |  | 68 | 
 | team | may 6, 1985 | new orleans hornets | 
 | name | rookie season | russell westbrook | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 187160lb 85 kg | 
 | team | july 28, 1986 | boston celtics | 
 | height |  | 65 | 
 | height |  | 610 | 
 | team | august 31, 1986 | oklahoma city thunder | 
 | name | assist | von wafer | 
 | height |  | 65 | 
 | weight | may 14 worcester telegram gazette | 220 | 
 | height |  | 66 | 
 | name | assist | manny harris | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 192 | 
 | height |  | 66 | 
 | name | assist | james posey | 
 | height |  | 68 | 
 | weight | may 17 the morning journal | 217 | 
 | team | march 20, 1980 | atlanta hawks | 
 | name | miami heat | erick dampier | 
 | team | relevancy filter | miami heat | 
 | name | regular season | darius songaila | 
 | height | 4.1 | 6160ft1609160in 2.06 m | 
 | weight | 4.1 | 248160lb 112 kg | 
 | name | milwaukee bucks | luc richard mbah a moute | 
 | team | relevancy filter | milwaukee bucks | 
 | team | december 2, 1978 | atlanta hawks | 
 | name | charlotte and new orleans | jamaal magloire | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 265160lb 120 kg | 
 | name | rebound | louis amundson | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 225 | 
 | team | september 3, 1982 | detroit pistons | 
 | name | regular season | al horford | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 245160lb 111 kg | 
 | name | assist | toney douglas | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 185 | 
 | name | golden state warriors | dorell wright | 
 | team | relevancy filter | golden state warriors | 
 | name | indiana pacers | a.j. price | 
 | team | relevancy filter | indiana pacers | 
 | name | new york knicks | amare stoudemire | 
 | team | relevancy filter | new york knicks | 
 | name | assist | shaun livingston | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 190 | 
 | height |  | 67 | 
 | name | rebound | dejuan blair | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 270 | 
 | name | college | alfarouq aminu | 
 | height | 4.1 | 6160ft1609160in 2.06 m | 
 | weight | 4.1 | 215160lb 98 kg | 
 | team | rank | sun | 
 | height |  | 68 | 
 | team | march 2, 1988 | miami heat | 
 | name | rebound | ian mahinmi | 
 | height |  | 611 | 
 | weight | 9.3 | 230 | 
 | name | regular season | james jones | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | height |  | 63 | 
 | height |  | 66 | 
 | name | new orleans hornets | marcus thornton | 
 | team | relevancy filter | new orleans hornets | 
 | height |  | 67 | 
 | name | orlando magic | mickael pietrus | 
 | team | relevancy filter | orlando magic | 
 | name | assist | sam young | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | college statistics | trevor booker | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 242160lb 110 kg | 
 | name | ncaa career statistics | steve nash | 
 | team | 6.1.1 | phoenix suns | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 178160lb 81 kg | 
 | height |  | 64 | 
 | name | toronto raptors | ed davis | 
 | team | relevancy filter | toronto raptors | 
 | team | october 22, 1989 | los angeles clippers | 
 | name | portland trail blazers | luke babbitt | 
 | team | relevancy filter | portland trail blazers | 
 | height |  | 71 | 
 | name | milwaukee bucks 1996–2003 | ray allen | 
 | team | 8.5.1 | boston celtics | 
 | height | 3.1 | 6160ft1605160in 1.96 m | 
 | weight | 3.1 | 205160lb 93 kg | 
 | height |  | 68 | 
 | height |  | 63 | 
 | height |  | 65 | 
 | team | july 11, 1976 | charlotte bobcats | 
 | team | october 15, 1985 | denver nuggets | 
 | height |  | 66 | 
 | team | may 7, 1978 | dallas mavericks | 
 | team | july 19, 1985 | portland trail blazers | 
 | name | orlando magic | marcin gortat | 
 | team | relevancy filter | orlando magic | 
 | name | early years | james posey | 
 | height | 3.1 | 6160ft1608160in 2.03 m | 
 | weight | 3.1 | 217160lb 98 kg | 
 | name | regular season | chris wilcox | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 235160lb 107 kg | 
 | height |  | 611 | 
 | team | march 15, 1991 | memphis grizzlies | 
 | height |  | 611 | 
 | name | rebound | austin daye | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 205 | 
 | name | houston rockets | von wafer | 
 | height | 3.1 | 6160ft1605160in 1.96 m | 
 | weight | 3.1 | 209160lb 95 kg | 
 | name | indiana pacers | paul george | 
 | team | relevancy filter | indiana pacers | 
 | name | assist | jason terry | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 180 | 
 | name | boston celtics | delonte west | 
 | team | relevancy filter | boston celtics | 
 | name | rebound | hakim warrick | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 219 | 
 | height |  | 64 | 
 | name | new york knicks | landry fields | 
 | team | relevancy filter | new york knicks | 
 | name | denver nuggets | ty lawson | 
 | team | relevancy filter | denver nuggets | 
 | height |  | 68 | 
 | name | new jersey nets | jordan farmar | 
 | team | relevancy filter | new jersey nets | 
 | team | december 2, 1985 | golden state warriors | 
 | name | washington wizards | josh howard | 
 | team | relevancy filter | washington wizards | 
 | name | regular season | rasual butler | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 205160lb 93 kg | 
 | name | regular season | marvin williams | 
 | height | 5.1 | 6160ft1609160in 2.06 m | 
 | weight | 5.1 | 240160lb 109 kg | 
 | name | rebound | mehmet okur | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 265 | 
 | name | assist | daniel gibson | 
 | height |  | 62 | 
 | weight | may 16 yahoo contributor network | 200 | 
 | team | november 30, 1979 | philadelphia 76ers | 
 | team | july 20, 1975 | boston celtics | 
 | team | may 19, 1976 | milwaukee bucks | 
 | name | 2006–07 nba season | leon powe | 
 | height | 4.1 | 6160ft1608160in 2.03 m | 
 | weight | 4.1 | 240160lb 109 kg | 
 | height |  | 69 | 
 | weight | 24 | 230 | 
 | name | charlotte bobcats | shaun livingston | 
 | team | relevancy filter | charlotte bobcats | 
 | name | freshman season | damion james | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 230160lb 104 kg | 
 | name | milwaukee bucks | andrew bogut | 
 | team | relevancy filter | milwaukee bucks | 
 | height |  | 66 | 
 | team | august 14, 1981 | phoenix suns | 
 | name | assist | anthony carter | 
 | height |  | 62 | 
 | weight | 3pt made | 195 | 
 | team | june 9, 1977 | toronto raptors | 
 | name | assist | christian eyenga | 
 | height |  | 65 | 
 | weight | 3pt made | 210 | 
 | height |  | 611 | 
 | name | assist | jermaine taylor | 
 | height |  | 64 | 
 | weight | 3pt made | 210 | 
 | name | minnesota timberwolves | luke ridnour | 
 | team | relevancy filter | minnesota timberwolves | 
 | team | august 23, 1978 | los angeles lakers | 
 | height |  | 69 | 
 | height |  | 610 | 
 | height |  | 511 | 
 | team | january 11, 1980 | atlanta hawks | 
 | name | 200607 | daniel gibson | 
 | height | 3.1 | 6160ft1602160in 1.88 m | 
 | weight | 3.1 | 200160lb 91 kg | 
 | height |  | 67 | 
 | name | cleveland cavaliers | jawad williams | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | rebound | kwame brown | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 270 | 
 | name | rebound | yao ming | 
 | height |  | 76 | 
 | weight | may 21 yahoo sports | 310 | 
 | name | assist | mario west | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 210 | 
 | team | march 14, 1989 | houston rockets | 
 | height |  | 62 | 
 | name | boston celtics | kendrick perkins | 
 | team | relevancy filter | boston celtics | 
 | name | nba statistics | derrick favors | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 246160lb 112 kg | 
 | height |  | 5160ft16011160in 1.80 m | 
 | weight |  | 176160lb 80 kg | 
 | height |  | 69 | 
 | team | december 2, 1978 | los angeles clippers | 
 | name | golden state warriors | jeff adrien | 
 | team | relevancy filter | golden state warriors | 
 | name | assist | eddie house | 
 | height |  | 61 | 
 | weight | may 20 miami herald | 190 | 
 | team | june 5, 1975 | miami heat | 
 | height |  | 60 | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 207160lb 94 kg | 
 | name | orlando magic | rashard lewis | 
 | team | relevancy filter | orlando magic | 
 | name | assist | earl watson | 
 | height |  | 61 | 
 | weight | 3pt made | 185 | 
 | name | assist | ben uzoh | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 205 | 
 | height |  | 6160ft1600160in 1.83 m | 
 | weight |  | 175160lb 79 kg | 
 | name | rebound | marcin gortat | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | injury | brandon rush | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 210160lb 95 kg | 
 | team | march 18, 1987 | charlotte bobcats | 
 | name | houston rockets | courtney lee | 
 | team | relevancy filter | houston rockets | 
 | team | november 27, 1979 | dallas mavericks | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 225160lb 102 kg | 
 | name | rebound | luol deng | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 220 | 
 | height |  | 611 | 
 | name | los angeles clippers | brian cook | 
 | team | relevancy filter | los angeles clippers | 
 | name | assist | nate robinson | 
 | height |  | 59 | 
 | weight | may 18 ap | 180 | 
 | name | washington wizards | al thornton | 
 | team | relevancy filter | washington wizards | 
 | height |  | 6160ft1606160in 1.98 m | 
 | weight |  | 210160lb 95 kg | 
 | name | career highs | andrew bogut | 
 | height | 3.1 | 7160ft1600160in 2.13 m | 
 | weight | 3.1 | 260160lb 118 kg | 
 | name | assist | j.r. smith | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 220 | 
 | height |  | 511 | 
 | weight | 28 | 165 | 
 | name | 2003 draft | kirk hinrich | 
 | height | 3.1 | 6160ft1604160in 1.93 m | 
 | weight | 3.1 | 190160lb 86 kg | 
 | name | assist | pape sy | 
 | height |  | 67 | 
 | weight | 3pt made | 225 | 
 | name | milwaukee bucks | brian skinner | 
 | team | relevancy filter | milwaukee bucks | 
 | name | rebound | gani lawal | 
 | height |  | 69 | 
 | weight | adidas phoenix suns 13 steve nash white home swingman basketball jersey | 234 | 
 | height |  | 69 | 
 | name | charlottenew orleans hornets | baron davis | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 215160lb 98 kg | 
 | height |  | 70 | 
 | height |  | 66 | 
 | name | assist | francisco garcia | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 195 | 
 | name | dallas mavericks | tyson chandler | 
 | team | relevancy filter | dallas mavericks | 
 | name | philadelphia 76ers | jason kapono | 
 | team | relevancy filter | philadelphia 76ers | 
 | height |  | 610 | 
 | name | miami heat | eddie house | 
 | team | relevancy filter | miami heat | 
 | height |  | 64 | 
 | name | rebound | marcus cousin | 
 | height |  | 611 | 
 | weight | adidas houston rockets 1 tracy mcgrady red swingman jersey | 250 | 
 | team | december 19, 1982 | cleveland cavaliers | 
 | name | los angeles clippers | jarron collins | 
 | team | relevancy filter | los angeles clippers | 
 | name | freshman year 2006–07 | greivis vasquez | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 200160lb 91 kg | 
 | name | detroit pistons | chris wilcox | 
 | team | relevancy filter | detroit pistons | 
 | height |  | 60 | 
 | weight | 25 | 188 | 
 | name | charlotte bobcats | gerald henderson | 
 | team | relevancy filter | charlotte bobcats | 
 | name | memphis grizzlies | greivis vasquez | 
 | team | relevancy filter | memphis grizzlies | 
 | name | detroit pistons | dajuan summers | 
 | team | relevancy filter | detroit pistons | 
 | team | february 14, 1978 | philadelphia 76ers | 
 | team | february 1, 1983 | houston rockets | 
 | name | chicago bulls | ronnie brewer | 
 | team | relevancy filter | chicago bulls | 
 | team | april 12, 1976 | houston rockets | 
 | name | assist | michael redd | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 215 | 
 | height |  | 69 | 
 | height |  | 64 | 
 | name | career transactions | tyson chandler | 
 | height | 2.1 | 7160ft1601160in 2.16 m | 
 | weight | 2.1 | 235160lb 107 kg | 
 | name | assist | garrett temple | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 195 | 
 | team | september 9, 1978 | houston rockets | 
 | name | golden state warriors | vladimir radmanovic | 
 | team | relevancy filter | golden state warriors | 
 | name | freshman season | cole aldrich | 
 | height | 1.1 | 6160ft16011160in 2.11 m | 
 | weight | 1.1 | 245160lb 111 kg | 
 | name | 2006–07 season | brandon roy | 
 | height | 3.1 | 6160ft1606160in 1.98 m | 
 | weight | 3.1 | 211160lb 96 kg | 
 | team | rank | jazz | 
 | height |  | 610 | 
 | name | chicago bulls | taj gibson | 
 | team | relevancy filter | chicago bulls | 
 | team | august 29, 1980 | new orleans hornets | 
 | name | miami heat | mario chalmers | 
 | team | relevancy filter | miami heat | 
 | name | assist | terrence williams | 
 | height |  | 66 | 
 | weight | 3pt made | 220 | 
 | height |  | 69 | 
 | team | february 16, 1987 | memphis grizzlies | 
 | name | assist | j.j. redick | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 190 | 
 | team | january 27, 1986 | new jersey nets | 
 | team | february 27, 1983 | new jersey nets | 
 | team | july 26, 1983 | boston celtics | 
 | team | september 5, 1990 | indiana pacers | 
 | name | rebound | samardo samuels | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 260 | 
 | team | september 19, 1989 | sacramento kings | 
 | team | january 12, 1987 | washington wizards | 
 | name | los angeles lakers | ron artest | 
 | team | relevancy filter | los angeles lakers | 
 | name | assist | wes johnson | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | new jersey nets | quinton ross | 
 | team | relevancy filter | new jersey nets | 
 | name | oklahoma city thunder | russell westbrook | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | rebound | patrick ewing jr. | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 240 | 
 | team | december 4, 1980 | los angeles clippers | 
 | name | assist | will bynum | 
 | height |  | 60 | 
 | weight | may 18 yahoo contributor network | 185 | 
 | name | charlotte bobcats | nazr mohammed | 
 | team | relevancy filter | charlotte bobcats | 
 | name | rebound | shelden williams | 
 | height |  | 69 | 
 | weight | 9.3 | 250 | 
 | team | june 9, 1985 | minnesota timberwolves | 
 | team | february 27, 1986 | cleveland cavaliers | 
 | name | portland trail blazers | jerryd bayless | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 200160lb 91 kg | 
 | name | charlotte bobcats | dominic mcguire | 
 | team | relevancy filter | charlotte bobcats | 
 | name | charlotte bobcats | d.j. augustin | 
 | team | relevancy filter | charlotte bobcats | 
 | name | new orleans hornets | david west | 
 | team | relevancy filter | new orleans hornets | 
 | name | new jersey nets | stephen graham | 
 | team | relevancy filter | new jersey nets | 
 | team | october 9, 1987 | philadelphia 76ers | 
 | name | rebound | ekpe udoh | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 240 | 
 | team | rank | heat | 
 | height |  | 610 | 
 | team | july 27, 1986 | memphis grizzlies | 
 | height |  | 69 | 
 | name | assist | trevor ariza | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 210 | 
 | team | july 8, 1982 | phoenix suns | 
 | name | portland trail blazers | greg oden | 
 | height | 3.1 | 7160ft1600160in 2.13 m | 
 | weight | 3.1 | 285160lb 129 kg | 
 | name | assist | reggie williams | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 210 | 
 | height |  | 70 | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 275160lb 125 kg | 
 | name | rebound | kyrylo fesenko | 
 | height |  | 71 | 
 | weight | may 21 yahoo sports | 280 | 
 | name | new jersey nets | kris humphries | 
 | team | relevancy filter | new jersey nets | 
 | team | december 9, 1989 | los angeles clippers | 
 | name | assist | joey graham | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 225 | 
 | height |  | 610 | 
 | name | regular season | daequan cook | 
 | height | 4.1 | 6160ft1605160in 1.96 m | 
 | weight | 4.1 | 210160lb 95 kg | 
 | name | denver nuggets | arron afflalo | 
 | team | relevancy filter | denver nuggets | 
 | name | dallas mavericks | brian cardinal | 
 | team | relevancy filter | dallas mavericks | 
 | team | august 8, 1979 | orlando magic | 
 | height |  | 68 | 
 | name | assist | mickael pietrus | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | assist | gerald henderson | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | new jersey nets | damion james | 
 | team | relevancy filter | new jersey nets | 
 | name | regular season | earl watson | 
 | height | 1.1 | 6160ft1601160in 1.85 m | 
 | weight | 1.1 | 195160lb 88 kg | 
 | height |  | 6160ft16011160in 2.11 m | 
 | weight |  | 200160lb 91 kg | 
 | team | september 10, 1974 | detroit pistons | 
 | height |  | 69 | 
 | weight | 21 | 235 | 
 | name | orlando magic | quentin richardson | 
 | team | relevancy filter | orlando magic | 
 | name | 2006–07 | hasheem thabeet | 
 | height | 1.1 | 7160ft1603160in 2.21 m | 
 | weight | 1.1 | 267160lb 121 kg | 
 | name | assist | ron artest | 
 | height |  | 67 | 
 | weight | may 20 yahoo contributor network | 260 | 
 | team | rank | net | 
 | height |  | 67 | 
 | name | assist | othyus jeffers | 
 | height |  | 65 | 
 | weight | 3pt made | 210 | 
 | team | april 18, 1986 | minnesota timberwolves | 
 | name | rebound | anthony randolph | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 225 | 
 | team | september 24, 1983 | los angeles clippers | 
 | height |  | 68 | 
 | height |  | 71 | 
 | team | rank | net | 
 | height |  | 66 | 
 | name | assist | leandro barbosa | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 202 | 
 | name | regular season | udonis haslem | 
 | height | 4.1 | 6160ft1608160in 2.03 m | 
 | weight | 4.1 | 235160lb 107 kg | 
 | height |  | 66 | 
 | team | july 10, 1985 | phoenix suns | 
 | height |  | 63 | 
 | name | 2006–07 | wesley johnson | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 206160lb 93 kg | 
 | name | europe | marc gasol | 
 | team | 4.2.1 | memphis grizzlies | 
 | height | 2.1 | 7160ft1601160in 2.16 m | 
 | weight | 2.1 | 265160lb 120 kg | 
 | team | june 11, 1982 | cleveland cavaliers | 
 | name | phoenix suns | steve nash | 
 | team | relevancy filter | phoenix suns | 
 | name | assist | willie warren | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 205 | 
 | height |  | 67 | 
 | height |  | 611 | 
 | weight | 26 | 240 | 
 | name | minnesota timberwolves | lazar hayward | 
 | team | relevancy filter | minnesota timberwolves | 
 | height |  | 71 | 
 | name | assist | keith bogans | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 215 | 
 | height |  | 65 | 
 | team | september 14, 1986 | golden state warriors | 
 | name | rebound | joakim noah | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 232 | 
 | team | april 21, 1986 | detroit pistons | 
 | team | august 23, 1988 | golden state warriors | 
 | name | rebound | derrick favors | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 246 | 
 | name | assist | acie law | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 202 | 
 | name | argentine and italian years | emanuel ginóbili | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 205160lb 93 kg | 
 | height |  | 66 | 
 | name | assist | willie green | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 201 | 
 | name | denver nuggets | kenyon martin | 
 | team | relevancy filter | denver nuggets | 
 | team | april 13, 1980 | orlando magic | 
 | team | june 21, 1983 | utah jazz | 
 | name | high school and college | alonzo gee | 
 | height | 1.1 | 6160ft1606160in 1.98 m | 
 | weight | 1.1 | 220160lb 100 kg | 
 | name | phoenix suns | jared dudley | 
 | team | relevancy filter | phoenix suns | 
 | name | rebound | jeff adrien | 
 | height |  | 67 | 
 | weight | 9.6 | 243 | 
 | name | assist | o.j. mayo | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 210 | 
 | height |  | 65 | 
 | name | assist | darren collison | 
 | height |  | 60 | 
 | weight | may 21 yahoo sports | 160 | 
 | name | assist | dahntay jones | 
 | height |  | 66 | 
 | weight | may 12 yahoo contributor network | 210 | 
 | team | february 18, 1983 | detroit pistons | 
 | team | november 29, 1985 | los angeles lakers | 
 | name | indiana pacers | lance stephenson | 
 | team | relevancy filter | indiana pacers | 
 | team | rank | heat | 
 | height |  | 73 | 
 | name | cleveland cavaliers | anderson varejao | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | regular season | travis outlaw | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 207160lb 94 kg | 
 | name | regular season | maurice evans | 
 | height | 4.1 | 6160ft1605160in 1.96 m | 
 | weight | 4.1 | 220160lb 100 kg | 
 | name | regular season | sean marks | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 250160lb 113 kg | 
 | name | assist | sundiata gaines | 
 | height |  | 61 | 
 | weight | 3pt made | 195 | 
 | name | rebound | zaza pachulia | 
 | height |  | 611 | 
 | weight | may 13 savannah morning news | 275 | 
 | height |  | 61 | 
 | name | europe | tiago splitter | 
 | height | 1.1 | 6160ft16011160in 2.11 m | 
 | weight | 1.1 | 232160lb 105 kg | 
 | name | dallas mavericks | brendan haywood | 
 | team | relevancy filter | dallas mavericks | 
 | name | philadelphia 76ers | spencer hawes | 
 | team | relevancy filter | philadelphia 76ers | 
 | name | golden state warriors | dan gadzuric | 
 | team | relevancy filter | golden state warriors | 
 | name | seattle supersonics | reggie evans | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 245160lb 111 kg | 
 | name | phoenix suns | earl clark | 
 | team | relevancy filter | phoenix suns | 
 | name | regular season | arron afflalo | 
 | height | 5.1 | 6160ft1605160in 1.96 m | 
 | weight | 5.1 | 215160lb 98 kg | 
 | name | toronto raptors | amir johnson | 
 | team | relevancy filter | toronto raptors | 
 | name | detroit pistons | mehmet okur | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 263160lb 119 kg | 
 | team | february 11, 1976 | philadelphia 76ers | 
 | name | assist | stephen curry | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 185 | 
 | height |  | 68 | 
 | name | rebound | nazr mohammed | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 250 | 
 | team | may 21, 1978 | miami heat | 
 | height |  | 62 | 
 | weight | 26 | 190 | 
 | team | august 31, 1982 | orlando magic | 
 | team | november 28, 1982 | toronto raptors | 
 | height |  | 65 | 
 | name | 4.1.1 | luc richard mbah a moute | 
 | height | 4.1 | 6160ft1608160in 2.03 m | 
 | weight | 4.1 | 230160lb 104 kg | 
 | team | march 5, 1986 | minnesota timberwolves | 
 | name | career transactions | eddie house | 
 | height | 2.1 | 6160ft1601160in 1.85 m | 
 | weight | 2.1 | 175160lb 79 kg | 
 | name | portland trail blazers | sean marks | 
 | team | relevancy filter | portland trail blazers | 
 | team | february 7, 1974 | phoenix suns | 
 | name | high school | derrick rose | 
 | height | 1.1 | 6160ft1603160in 1.91 m | 
 | weight | 1.1 | 190160lb 86 kg | 
 | name | minnesota timberwolves | anthony tolliver | 
 | team | relevancy filter | minnesota timberwolves | 
 | name | regular season | anthony carter | 
 | height | 4.1 | 6160ft1601160in 1.85 m | 
 | weight | 4.1 | 190160lb 86 kg | 
 | team | april 29, 1983 | golden state warriors | 
 | height |  | 610 | 
 | height |  | 62 | 
 | team | rank | sun | 
 | height |  | 69 | 
 | height |  | 63 | 
 | team | rank | jazz | 
 | height |  | 71 | 
 | height |  | 6160ft1601160in 1.85 m | 
 | weight |  | 195160lb 88 kg | 
 | name | new jersey nets | anthony morrow | 
 | team | relevancy filter | new jersey nets | 
 | height |  | 6160ft1606160in 1.98 m | 
 | weight |  | 225160lb 102 kg | 
 | name | assist | courtney lee | 
 | height |  | 65 | 
 | weight | 3pt made | 200 | 
 | name | cleveland cavaliers | christian eyenga | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | college | lamar odom | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 230160lb 104 kg | 
 | team | august 22, 1986 | washington wizards | 
 | name | new jersey nets | ben uzoh | 
 | team | relevancy filter | new jersey nets | 
 | name | regular season | dorell wright | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 210160lb 95 kg | 
 | team | july 25, 1983 | oklahoma city thunder | 
 | height |  | 68 | 
 | height |  | 68 | 
 | name | los angeles clippers | eric bledsoe | 
 | team | relevancy filter | los angeles clippers | 
 | height |  | 55 | 
 | name | rebound | jeff green | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | freshman season | tyler hansbrough | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 250160lb 113 kg | 
 | height |  | 62 | 
 | team | september 25, 1976 | denver nuggets | 
 | height |  | 6160ft1604160in 1.93 m | 
 | weight |  | 207160lb 94 kg | 
 | name | assist | trey johnson | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 218 | 
 | name | miami heat | dwyane wade | 
 | team | relevancy filter | miami heat | 
 | height |  | 611 | 
 | height |  | 70 | 
 | name | washington wizards | javale mcgee | 
 | team | relevancy filter | washington wizards | 
 | team | march 10, 1982 | charlotte bobcats | 
 | name | career highs | jason maxiell | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 260160lb 118 kg | 
 | name | new york knicks | bill walker | 
 | team | relevancy filter | new york knicks | 
 | height |  | 67 | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 196160lb 89 kg | 
 | name | career transactions | richard hamilton | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 193160lb 88 kg | 
 | name | chicago bulls | kyle korver | 
 | team | relevancy filter | chicago bulls | 
 | name | regular season | melvin ely | 
 | height | 3.1 | 6160ft16010160in 2.08 m | 
 | weight | 3.1 | 261160lb 118 kg | 
 | team | february 7, 1973 | miami heat | 
 | team | march 13, 1980 | dallas mavericks | 
 | name | portland trail blazers | dante cunningham | 
 | team | relevancy filter | portland trail blazers | 
 | name | toronto raptors | leandro barbosa | 
 | team | relevancy filter | toronto raptors | 
 | team | december 31, 1980 | sacramento kings | 
 | height |  | 67 | 
 | name | san antonio spurs | tony parker | 
 | team | relevancy filter | san antonio spurs | 
 | name | atlanta hawks | etan thomas | 
 | team | relevancy filter | atlanta hawks | 
 | name | drafted by cleveland | carlos boozer | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 266160lb 121 kg | 
 | height |  | 69 | 
 | name | atlanta hawks | marvin williams | 
 | team | relevancy filter | atlanta hawks | 
 | team | december 30, 1980 | new orleans hornets | 
 | name | miami heat | joel anthony | 
 | team | relevancy filter | miami heat | 
 | name | portland trail blazers | matt carroll | 
 | height | 3.1 | 6160ft1606160in 1.98 m | 
 | weight | 3.1 | 212160lb 96 kg | 
 | team | rank | sun | 
 | height |  | 67 | 
 | name | rebound | corey maggette | 
 | height |  | 66 | 
 | weight | adidas milwaukee bucks 3 brandon jennings white replica basketball jersey | 225 | 
 | name | rebound | josh powell | 
 | height |  | 69 | 
 | weight | 9.3 | 240 | 
 | name | golden state warriors | monta ellis | 
 | team | relevancy filter | golden state warriors | 
 | team | september 29, 1988 | oklahoma city thunder | 
 | team | rank | sun | 
 | height |  | 69 | 
 | weight | 24 | 220 | 
 | name | assist | jonny flynn | 
 | height |  | 60 | 
 | weight | may 21 yahoo sports | 195 | 
 | team | november 26, 1990 | boston celtics | 
 | height |  | 65 | 
 | weight | 19 | 210 | 
 | team | april 3, 1981 | dallas mavericks | 
 | team | october 14, 1986 | portland trail blazers | 
 | team | june 27, 1978 | orlando magic | 
 | name | toronto raptors 1997–2000 | tracy mcgrady | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 223160lb 101 kg | 
 | name | regular season | shawne williams | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 225160lb 102 kg | 
 | height |  | 69 | 
 | name | washington wizards | kevin seraphin | 
 | team | relevancy filter | washington wizards | 
 | team | february 22, 1986 | boston celtics | 
 | name | assist | ronnie price | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 187 | 
 | height |  | 63 | 
 | height |  | 60 | 
 | weight | 25 | 195 | 
 | height |  | 65 | 
 | name | assist | maurice evans | 
 | height |  | 65 | 
 | weight | 3pt made | 220 | 
 | team | february 28, 1987 | indiana pacers | 
 | height |  | 6160ft1608160in 2.03 m | 
 | weight |  | 268160lb 122 kg | 
 | team | rank | heat | 
 | height |  | 68 | 
 | team | january 6, 1982 | washington wizards | 
 | team | july 27, 1987 | houston rockets | 
 | name | golden state warriors 1995–1998 | joe smith | 
 | team | 1.2.1 | new jersey nets | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 225160lb 102 kg | 
 | team | rank | sun | 
 | height |  | 70 | 
 | name | high school | chris paul | 
 | height | 1.1 | 6160ft1600160in 1.83 m | 
 | weight | 1.1 | 175160lb 79 kg | 
 | team | february 20, 1987 | chicago bulls | 
 | team | rank | net | 
 | height |  | 70 | 
 | name | rebound | hasheem thabeet | 
 | height |  | 73 | 
 | weight | may 17 memphis commercial appeal | 267 | 
 | name | washington wizards | andray blatche | 
 | team | relevancy filter | washington wizards | 
 | height |  | 66 | 
 | name | rebound | kurt thomas | 
 | height |  | 69 | 
 | weight | may 13 ap | 230 | 
 | name | rebound | dj white | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 251 | 
 | name | rebound | hassan whiteside | 
 | height |  | 70 | 
 | weight | adidas sacramento kings 23 kevin martin black net player tshirt | 235 | 
 | name | rebound | serge ibaka | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | rebound | richard jefferson | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 230 | 
 | name | rebound | jeff foster | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 250 | 
 | team | june 21, 1988 | philadelphia 76ers | 
 | team | october 13, 1977 | boston celtics | 
 | name | college career | chris duhon | 
 | height | 1.1 | 6160ft1601160in 1.85 m | 
 | weight | 1.1 | 185160lb 84 kg | 
 | team | august 21, 1987 | philadelphia 76ers | 
 | name | denver nuggets | chris andersen | 
 | team | relevancy filter | denver nuggets | 
 | height |  | 611 | 
 | name | assist | jameer nelson | 
 | height |  | 60 | 
 | weight | may 21 yahoo sports | 190 | 
 | team | june 12, 1990 | philadelphia 76ers | 
 | height |  | 65 | 
 | name | postcollege | josé juan barea | 
 | height | 2.1 | 6160ft1600160in 1.83 m | 
 | weight | 2.1 | 175160lb 79 kg | 
 | team | may 15, 1987 | milwaukee bucks | 
 | name | los angeles lakers | derrick caracter | 
 | team | relevancy filter | los angeles lakers | 
 | name | rebound | dwight howard | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 265 | 
 | team | april 16, 1982 | charlotte bobcats | 
 | team | november 25, 1981 | houston rockets | 
 | team | november 6, 1979 | los angeles lakers | 
 | name | assist | tony parker | 
 | height |  | 62 | 
 | weight | may 21 yahoo sports | 185 | 
 | name | memphis grizzlies | xavier henry | 
 | team | relevancy filter | memphis grizzlies | 
 | name | assist | omri casspi | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 225 | 
 | team | january 19, 1988 | washington wizards | 
 | team | december 14, 1988 | portland trail blazers | 
 | height |  | 66 | 
 | name | miami heat | lebron james | 
 | team | relevancy filter | miami heat | 
 | team | rank | sun | 
 | height |  | 610 | 
 | team | november 5, 1986 | dallas mavericks | 
 | name | orlando magic 1992–1996 | shaquille oneal | 
 | height | 3.1 | 7160ft1601160in 2.16 m | 
 | weight | 3.1 | 325160lb 147 kg | 
 | name | cleveland cavaliers | joey graham | 
 | team | relevancy filter | cleveland cavaliers | 
 | name | orlando magic | daniel orton | 
 | team | relevancy filter | orlando magic | 
 | name | charlotte bobcats | tyrus thomas | 
 | team | relevancy filter | charlotte bobcats | 
 | name | regular season | javale mcgee | 
 | height | 5.1 | 7160ft1600160in 2.13 m | 
 | weight | 5.1 | 252160lb 114 kg | 
 | name | new orleans hornets | aaron gray | 
 | team | relevancy filter | new orleans hornets | 
 | height |  | 611 | 
 | team | february 9, 1982 | orlando magic | 
 | name | regular season | dominic mcguire | 
 | height | 3.1 | 6160ft1608160in 2.03 m | 
 | weight | 3.1 | 220160lb 100 kg | 
 | name | new orleans hornets | willie green | 
 | team | relevancy filter | new orleans hornets | 
 | name | philadelphia 76ers | andre iguodala | 
 | team | relevancy filter | philadelphia 76ers | 
 | height |  | 66 | 
 | name | new orleans hornets | marco belinelli | 
 | team | relevancy filter | new orleans hornets | 
 | name | chicago bulls | ron artest | 
 | height | 1.1 | 6160ft1607160in 2.01 m | 
 | weight | 1.1 | 260160lb 118 kg | 
 | height |  | 68 | 
 | team | june 10, 1988 | atlanta hawks | 
 | height |  | 68 | 
 | name | portland trail blazers | brandon roy | 
 | team | relevancy filter | portland trail blazers | 
 | team | november 7, 1985 | sacramento kings | 
 | name | recruiting process | jeremy lin | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 200160lb 91 kg | 
 | name | assist | raja bell | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 205 | 
 | height |  | 68 | 
 | height |  | 610 | 
 | weight | 23 | 230 | 
 | height |  | 70 | 
 | name | regular season | nick collison | 
 | height | 5.1 | 6160ft16010160in 2.08 m | 
 | weight | 5.1 | 255160lb 116 kg | 
 | height |  | 61 | 
 | team | june 26, 1984 | utah jazz | 
 | name | rebound | marreese speights | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 245 | 
 | name | orlando magic | keith bogans | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 215160lb 98 kg | 
 | height |  | 66 | 
 | height |  | 65 | 
 | weight | 21 | 180 | 
 | team | august 26, 1977 | oklahoma city thunder | 
 | name | houston rockets | ishmael smith | 
 | team | relevancy filter | houston rockets | 
 | height |  | 63 | 
 | name | assist | derrick rose | 
 | height |  | 63 | 
 | weight | may 21 yahoo sports | 190 | 
 | name | regular season | craig smith | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 250160lb 113 kg | 
 | team | november 23, 1984 | washington wizards | 
 | team | june 1, 1985 | memphis grizzlies | 
 | team | february 28, 1980 | detroit pistons | 
 | team | november 30, 1986 | new jersey nets | 
 | name | regular season | brook lopez | 
 | height | 5.1 | 7160ft1600160in 2.13 m | 
 | weight | 5.1 | 265160lb 120 kg | 
 | name | toronto raptors | joey dorsey | 
 | team | relevancy filter | toronto raptors | 
 | name | detroit pistons | jason maxiell | 
 | team | relevancy filter | detroit pistons | 
 | height |  | 610 | 
 | name | israel | omri casspi | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 225160lb 102 kg | 
 | name | houston rockets | brad miller | 
 | team | relevancy filter | houston rockets | 
 | team | april 22, 1989 | san antonio spurs | 
 | name | assist | gilbert arenas | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 215 | 
 | height |  | 67 | 
 | team | august 9, 1982 | miami heat | 
 | name | rebound | kendrick perkins | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 275 | 
 | name | early years | david lee | 
 | height | 1.1 | 6160ft1609160in 2.06 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | name | regular season | will bynum | 
 | height | 4.1 | 6160ft1600160in 1.83 m | 
 | weight | 4.1 | 185160lb 84 kg | 
 | name | rebound | david west | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | regular season | royal ivey | 
 | height | 3.1 | 6160ft1604160in 1.93 m | 
 | weight | 3.1 | 215160lb 98 kg | 
 | team | october 3, 1984 | san antonio spurs | 
 | team | rank | heat | 
 | height |  | 69 | 
 | name | rebound | joey dorsey | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 268 | 
 | name | oklahoma city thunder | royal ivey | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | rebound | shawn marion | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 228 | 
 | name | nba career statistics | demar derozan | 
 | height | 4.1 | 6160ft1607160in 2.01 m | 
 | weight | 4.1 | 220160lb 100 kg | 
 | name | rebound | yi jianlian | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 250 | 
 | name | new york knicks | anthony randolph | 
 | team | relevancy filter | new york knicks | 
 | name | regular season | josh smith | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | team | september 11, 1985 | charlotte bobcats | 
 | name | regular season | corey brewer | 
 | height | 3.1 | 6160ft1609160in 2.06 m | 
 | weight | 3.1 | 185160lb 84 kg | 
 | name | early life | ronny turiaf | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 250160lb 113 kg | 
 | team | july 7, 1985 | indiana pacers | 
 | name | assist | joe johnson | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 240 | 
 | name | regular season | steve novak | 
 | height | 5.1 | 6160ft16010160in 2.08 m | 
 | weight | 5.1 | 220160lb 100 kg | 
 | name | orlando magic | dwight howard | 
 | team | relevancy filter | orlando magic | 
 | name | college | kelenna azubuike | 
 | height | 1.1 | 6160ft1605160in 1.96 m | 
 | weight | 1.1 | 220160lb 100 kg | 
 | name | san antonio spurs | tony parker | 
 | team | 2.1.1 | san antonio spurs | 
 | height | 2.1 | 6160ft1602160in 1.88 m | 
 | weight | 2.1 | 180160lb 82 kg | 
 | height |  | 67 | 
 | name | new orleans hornets | pops mensah bonsu | 
 | team | relevancy filter | new orleans hornets | 
 | team | rank | heat | 
 | height |  | 64 | 
 | name | assist | josh howard | 
 | height |  | 67 | 
 | weight | may 21 yahoo sports | 210 | 
 | name | washington wizards | kirk hinrich | 
 | team | relevancy filter | washington wizards | 
 | team | november 3, 1987 | denver nuggets | 
 | height |  | 611 | 
 | height |  | 68 | 
 | weight | 25 | 205 | 
 | height |  | 69 | 
 | team | june 21, 1980 | san antonio spurs | 
 | name | freshman season | luke harangody | 
 | height | 2.1 | 6160ft1607160in 2.01 m | 
 | weight | 2.1 | 251160lb 114 kg | 
 | name | regular season | dajuan summers | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 240160lb 109 kg | 
 | name | rebound | chuck hayes | 
 | height |  | 66 | 
 | weight | may 21 yahoo sports | 238 | 
 | height |  | 70 | 
 | team | july 5, 1982 | sacramento kings | 
 | name | rebound | byron mullens | 
 | height |  | 70 | 
 | weight | adidas oklahoma city thunder 35 kevin durant royal blue swingman basketball jersey | 275 | 
 | name | assist | antonio daniels | 
 | height |  | 64 | 
 | weight | may 21 yahoo sports | 205 | 
 | team | january 9, 1989 | minnesota timberwolves | 
 | name | golden state warriors | charlie bell | 
 | team | relevancy filter | golden state warriors | 
 | name | milwaukee bucks | jon brockman | 
 | team | relevancy filter | milwaukee bucks | 
 | name | new orleans hornets | marcus banks | 
 | team | relevancy filter | new orleans hornets | 
 | team | january 25, 1983 | atlanta hawks | 
 | name | charlotte bobcats | stephen jackson | 
 | team | relevancy filter | charlotte bobcats | 
 | name | denver nuggets | anthony carter | 
 | team | relevancy filter | denver nuggets | 
 | height |  | 610 | 
 | name | utah jazz | raja bell | 
 | team | relevancy filter | utah jazz | 
 | name | los angeles clippers | blake griffin | 
 | team | relevancy filter | los angeles clippers | 
 | height |  | 611 | 
 | height |  | 64 | 
 | height |  | 611 | 
 | name | chicago bulls | omer asik | 
 | team | relevancy filter | chicago bulls | 
 | height |  | 6160ft16010160in 2.08 m | 
 | weight |  | 240160lb 109 kg | 
 | name | rebound | kosta koufos | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 275 | 
 | name | early career | paul pierce | 
 | height | 3.1 | 6160ft1607160in 2.01 m | 
 | weight | 3.1 | 235160lb 107 kg | 
 | height |  | 69 | 
 | height |  | 64 | 
 | name | college statistics | james harden | 
 | height | 2.1 | 6160ft1605160in 1.96 m | 
 | weight | 2.1 | 218160lb 99 kg | 
 | name | oklahoma city thunder | nick collison | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | atlanta hawks | pape sy | 
 | team | relevancy filter | atlanta hawks | 
 | name | regular season | michael redd | 
 | height | 6.1 | 6160ft1606160in 1.98 m | 
 | weight | 6.1 | 215160lb 98 kg | 
 | height |  | 60 | 
 | height |  | 61 | 
 | team | october 7, 1986 | indiana pacers | 
 | team | rank | net | 
 | height |  | 610 | 
 | height |  | 63 | 
 | height |  | 63 | 
 | height |  | 60 | 
 | team | rank | jazz | 
 | height |  | 65 | 
 | weight | 25 | 210 | 
 | team | august 9, 1974 | los angeles lakers | 
 | name | rebound | chris bosh | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 235 | 
 | name | assist | jamal crawford | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 200 | 
 | height |  | 67 | 
 | name | 2006 nba draft | rajon rondo | 
 | height | 3.1 | 6160ft1601160in 1.85 m | 
 | weight | 3.1 | 171160lb 78 kg | 
 | height |  | 511 | 
 | name | oklahoma city thunder | eric maynor | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | milwaukee bucks | brandon jennings | 
 | team | relevancy filter | milwaukee bucks | 
 | name | shooting incident | tony allen | 
 | height | 2.1 | 6160ft1604160in 1.93 m | 
 | weight | 2.1 | 213160lb 97 kg | 
 | name | regular season | terrence williams | 
 | height | 2.1 | 6160ft1606160in 1.98 m | 
 | weight | 2.1 | 220160lb 100 kg | 
 | height |  | 63 | 
 | name | assist | mario chalmers | 
 | height |  | 61 | 
 | weight | may 21 yahoo sports | 190 | 
 | team | june 20, 1989 | portland trail blazers | 
 | height |  | 68 | 
 | name | chicago bulls | john lucas | 
 | team | relevancy filter | chicago bulls | 
 | name | indiana pacers 2005present | danny granger | 
 | height | 2.1 | 6160ft1608160in 2.03 m | 
 | weight | 2.1 | 228160lb 103 kg | 
 | name | memphis grizzlies | zach randolph | 
 | team | relevancy filter | memphis grizzlies | 
 | name | regular season | kyle lowry | 
 | height | 2.1 | 6160ft1600160in 1.83 m | 
 | weight | 2.1 | 205160lb 93 kg | 
 | name | los angeles clippers | deandre jordan | 
 | team | relevancy filter | los angeles clippers | 
 | team | rank | sun | 
 | height |  | 610 | 
 | height |  | 66 | 
 | team | september 6, 1990 | washington wizards | 
 | name | portland trail blazers | jermaine oneal | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 255160lb 116 kg | 
 | team | rank | heat | 
 | height |  | 61 | 
 | name | rebound | jamaal magloire | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 255 | 
 | height |  | 70 | 
 | team | january 24, 1988 | detroit pistons | 
 | height |  | 68 | 
 | name | new orleans hornets | dj mbenga | 
 | team | relevancy filter | new orleans hornets | 
 | name | boston celtics | kevin garnett | 
 | team | relevancy filter | boston celtics | 
 | team | rank | net | 
 | height |  | 69 | 
 | name | criminal allegations | o. j. mayo | 
 | height | 1.1 | 6160ft1604160in 1.93 m | 
 | weight | 1.1 | 210160lb 95 kg | 
 | team | rank | jazz | 
 | height |  | 611 | 
 | name | assist | jrue holiday | 
 | height |  | 64 | 
 | weight | may 16 yahoo contributor network | 180 | 
 | name | denver nuggets | nene hilario | 
 | team | relevancy filter | denver nuggets | 
 | name | rebound | jermaine oneal | 
 | height |  | 611 | 
 | weight | may 21 yahoo sports | 268 | 
 | team | november 26, 1986 | minnesota timberwolves | 
 | name | philadelphia 76ers | jrue holiday | 
 | team | relevancy filter | philadelphia 76ers | 
 | height |  | 610 | 
 | name | assist | jerryd bayless | 
 | height |  | 63 | 
 | weight | may 16 yahoo sports | 200 | 
 | height |  | 68 | 
 | team | september 18, 1984 | new jersey nets | 
 | name | regular season | dante cunningham | 
 | height | 5.1 | 6160ft1608160in 2.03 m | 
 | weight | 5.1 | 230160lb 104 kg | 
 | height |  | 63 | 
 | team | july 21, 1988 | los angeles clippers | 
 | team | october 7, 1987 | new jersey nets | 
 | name | rebound | udonis haslem | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 235 | 
 | team | january 3, 1986 | minnesota timberwolves | 
 | team | april 4, 1983 | detroit pistons | 
 | name | new jersey | kenyon martin | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | name | memphis grizzlies | hamed haddadi | 
 | team | relevancy filter | memphis grizzlies | 
 | name | rookie season | deron williams | 
 | height | 3.1 | 6160ft1603160in 1.91 m | 
 | weight | 3.1 | 207160lb 94 kg | 
 | name | europe | goran dragić | 
 | height | 1.1 | 6160ft1604160in 1.93 m | 
 | weight | 1.1 | 190160lb 86 kg | 
 | team | march 19, 1988 | new jersey nets | 
 | height |  | 610 | 
 | team | may 29, 1984 | denver nuggets | 
 | name | sacramento kings | beno udrih | 
 | team | relevancy filter | sacramento kings | 
 | name | washington wizards | kwame brown | 
 | team | 2.1.1 | charlotte bobcats | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 270160lb 122 kg | 
 | name | slam dunk contest | chris andersen | 
 | team | 3.1.1 | denver nuggets | 
 | height | 1.1 | 6160ft16010160in 2.08 m | 
 | weight | 1.1 | 228160lb 103 kg | 
 | height |  | 611 | 
 | name | rebound | chris andersen | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 230 | 
 | height |  | 66 | 
 | team | rank | jazz | 
 | height |  | 69 | 
 | team | january 4, 1983 | detroit pistons | 
 | name | phoenix suns | jason richardson | 
 | team | relevancy filter | phoenix suns | 
 | name | college career | darren collison | 
 | height | 1.1 | 6160ft1600160in 1.83 m | 
 | weight | 1.1 | 160160lb 73 kg | 
 | team | january 22, 1984 | cleveland cavaliers | 
 | team | october 31, 1988 | oklahoma city thunder | 
 | height |  | 71 | 
 | height |  | 611 | 
 | height |  | 67 | 
 | height |  | 63 | 
 | name | assist | marquis daniels | 
 | height |  | 66 | 
 | weight | may 14 worcester telegram gazette | 200 | 
 | name | regular season | antonio mcdyess | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 245160lb 111 kg | 
 | name | rebound | brian cardinal | 
 | height |  | 68 | 
 | weight | 9.6 | 241 | 
 | name | assist | ray allen | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 205 | 
 | team | may 12, 1980 | chicago bulls | 
 | height |  | 6160ft1607160in 2.01 m | 
 | weight |  | 243160lb 110 kg | 
 | team | march 19, 1979 | phoenix suns | 
 | height |  | 68 | 
 | name | dallas mavericks | jason terry | 
 | team | relevancy filter | dallas mavericks | 
 | name | rebound | kris humphries | 
 | height |  | 69 | 
 | weight | may 21 yahoo sports | 235 | 
 | team | june 26, 1984 | dallas mavericks | 
 | height |  | 63 | 
 | name | dallas mavericks | alexis ajinca | 
 | team | relevancy filter | dallas mavericks | 
 | name | los angeles clippers | al farouq aminu | 
 | team | relevancy filter | los angeles clippers | 
 | team | rank | sun | 
 | height |  | 66 | 
 | name | regular season | matt bonner | 
 | height | 7.1 | 6160ft16010160in 2.08 m | 
 | weight | 7.1 | 249160lb 113 kg | 
 | team | march 20, 1985 | chicago bulls | 
 | name | assist | jason kapono | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 215 | 
 | name | new jersey nets | stephen jackson | 
 | height | 1.1 | 6160ft1608160in 2.03 m | 
 | weight | 1.1 | 215160lb 98 kg | 
 | name | san antonio spurs | tiago splitter | 
 | team | relevancy filter | san antonio spurs | 
 | team | january 17, 1988 | phoenix suns | 
 | name | nba career statistics | tony battie | 
 | height | 2.1 | 6160ft16011160in 2.11 m | 
 | weight | 2.1 | 240160lb 109 kg | 
 | height |  | 63 | 
 | team | february 10, 1985 | utah jazz | 
 | name | golden state warriors | monta ellis | 
 | height | 2.1 | 6160ft1603160in 1.91 m | 
 | weight | 2.1 | 180160lb 82 kg | 
 | name | rebound | shaquille oneal | 
 | height |  | 71 | 
 | weight | may 21 yahoo sports | 325 | 
 | name | rebound | craig brackins | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 230 | 
 | name | oklahoma city thunder | daequan cook | 
 | team | relevancy filter | oklahoma city thunder | 
 | name | regular season | jamario moon | 
 | height | 4.1 | 6160ft1608160in 2.03 m | 
 | weight | 4.1 | 200160lb 91 kg | 
 | team | june 12, 1976 | cleveland cavaliers | 
 | name | detroit pistons | charlie villanueva | 
 | team | relevancy filter | detroit pistons | 
 | team | december 4, 1986 | minnesota timberwolves | 
 | height |  | 611 | 
 | name | chicago bulls | james johnson | 
 | team | relevancy filter | chicago bulls | 
 | name | rebound | javale mcgee | 
 | height |  | 70 | 
 | weight | may 21 yahoo sports | 250 | 
 | name | assist | mike conley | 
 | height |  | 61 | 
 | weight | may 21 yahoo sports | 185 | 
 | name | philadelphia 76ers | thaddeus young | 
 | team | relevancy filter | philadelphia 76ers | 
 | height |  | 71 | 
 | team | march 21, 1988 | toronto raptors | 
 | team | june 26, 1984 | new york knicks | 
 | height |  | 64 | 
 | height |  | 60 | 
 | height |  | 70 | 
 | name | assist | tracy mcgrady | 
 | height |  | 68 | 
 | weight | may 21 yahoo sports | 223 | 
 | team | december 27, 1980 | indiana pacers | 
 | name | rebound | brandan wright | 
 | height |  | 610 | 
 | weight | may 21 yahoo sports | 220 | 
 | name | utah jazz 1999present | andrei kirilenko | 
 | height | 2.1 | 6160ft1609160in 2.06 m | 
 | weight | 2.1 | 225160lb 102 kg | 
 | height |  | 60 | 
 | height |  | 70 | 
 | height |  | 65 | 
 | team | april 1, 1988 | phoenix suns | 
 | name | philadelphia 76ers | andres nocioni | 
 | team | relevancy filter | philadelphia 76ers | 
 | height |  | 6160ft1609160in 2.06 m | 
 | weight |  | 265160lb 120 kg | 
 | height |  | 67 | 
 | name | high school | eddy curry | 
 | height | 1.1 | 7160ft1600160in 2.13 m | 
 | weight | 1.1 | 295160lb 134 kg | 
 | name | career transactions | jason williams | 
 | height | 2.1 | 6160ft1601160in 1.85 m | 
 | weight | 2.1 | 180160lb 82 kg | 
 | name | nba development league | chuck hayes | 
 | height | 4.1 | 6160ft1606160in 1.98 m | 
 | weight | 4.1 | 238160lb 108 kg | 
 | name | 2006 ncaa tournament | tyrus thomas | 
 | height | 2.1 | 6160ft16010160in 2.08 m | 
 | weight | 2.1 | 225160lb 102 kg | 
 | name | assist | lance stephenson | 
 | height |  | 65 | 
 | weight | may 21 yahoo sports | 210 | 
