# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.structure_template_model_v3.StrucTempExtractionModelV3'>
* Category: Category.NBA_PLAYER
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.15
* Seed: eval_class
* Name: final_struc_nba_player_website
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7027 | 0.7135 |
| F1 | 0.703 | 0.7139 |
| Partial Match | 0.7027 | 0.7135 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7205 | 0.7282 |
| F1 | 0.7206 | 0.7283 |
| Partial Match | 0.7208 | 0.7286 |
## Attribute Prediction: Name
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6951 | 0.7367 |
| F1 | 0.6966 | 0.7383 |
| Partial Match | 0.6951 | 0.7367 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7156 | 0.744 |
| F1 | 0.7159 | 0.7444 |
| Partial Match | 0.7156 | 0.744 |
## Attribute Prediction: Team
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7027 | 0.7045 |
| F1 | 0.7027 | 0.7045 |
| Partial Match | 0.7027 | 0.7045 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6792 | 0.6816 |
| F1 | 0.6792 | 0.6817 |
| Partial Match | 0.6792 | 0.6816 |
## Attribute Prediction: Height
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6591 | 0.6591 |
| F1 | 0.6591 | 0.6591 |
| Partial Match | 0.6591 | 0.6591 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6906 | 0.6906 |
| F1 | 0.6906 | 0.6906 |
| Partial Match | 0.6906 | 0.6906 |
## Attribute Prediction: Weight
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7538 | 0.7538 |
| F1 | 0.7538 | 0.7538 |
| Partial Match | 0.7538 | 0.7538 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.7967 | 0.7967 |
| F1 | 0.7967 | 0.7967 |
| Partial Match | 0.7977 | 0.7984 |
