# Evaluation Extraction
## Parameters:
* Model: <class 'extraction.extraction_models.structure_template_model_v3.StrucTempExtractionModelV3'>
* Category: Category.AUTO
* Data-split: website
* Size dataset: -1
* Train-Test-Split: 0.15
* Seed: eval_class
* Name: final_struc_auto_website
## Overall Prediction: 
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.5821 | 0.6452 |
| F1 | 0.6694 | 0.7552 |
| Partial Match | 0.6949 | 0.7841 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.5813 | 0.6451 |
| F1 | 0.6698 | 0.7535 |
| Partial Match | 0.6957 | 0.7824 |
## Attribute Prediction: Model
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6293 | 0.6865 |
| F1 | 0.6394 | 0.703 |
| Partial Match | 0.6293 | 0.6865 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6296 | 0.6974 |
| F1 | 0.6383 | 0.7118 |
| Partial Match | 0.6296 | 0.6974 |
## Attribute Prediction: Price
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8893 | 0.9567 |
| F1 | 0.8913 | 0.9588 |
| Partial Match | 0.8893 | 0.9567 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.8853 | 0.9564 |
| F1 | 0.888 | 0.9591 |
| Partial Match | 0.8853 | 0.9564 |
## Attribute Prediction: Engine
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.674 | 0.8019 |
| F1 | 0.6743 | 0.803 |
| Partial Match | 0.674 | 0.8019 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.6657 | 0.7822 |
| F1 | 0.6661 | 0.7831 |
| Partial Match | 0.6657 | 0.7822 |
## Attribute Prediction: Fuel_economy
### In-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.1358 | 0.1358 |
| F1 | 0.4726 | 0.556 |
| Partial Match | 0.587 | 0.6912 |
### Out-of-sample Prediction:
| Metric | Top 1 | Top 3 |
|---|---|---|
| Exact Match | 0.1447 | 0.1447 |
| F1 | 0.4867 | 0.56 |
| Partial Match | 0.6022 | 0.6937 |
