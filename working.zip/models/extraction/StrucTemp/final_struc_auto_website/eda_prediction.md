# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: CATEGORY.AUTO

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| model | 20.04 | 3.66 | 3.0 | 0.0 | 
| price | 12.11 | 2.36 | 3.0 | 0.0 | 
| engine | 16.11 | 3.29 | 3.0 | 0.0 | 
| fuel_economy | 9.58 | 2.18 | 3.0 | 0.45 | 


