# Exploratory Data Analysis
* **Average Length** = Average number of characters / length of solution calculated for each attribute and category.

* **Average Tokens** = Average number of tokens (words) calculated for each attribute and category.

* **Average Solutions** = Average number of existing solutions calculated for each attribute and category.

* **Average Missing** = Average proportion of missing solutions calculated for each attribute and category.



## Category: MOVIE

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| title | 16.89 | 3.09 | 1.2 | 0.0 | 
| director | 12.49 | 1.98 | 1.07 | 0.01 | 
| genre | 11.42 | 1.6 | 1.56 | 0.01 | 
| mpaa_rating | 12.64 | 2.71 | 0.98 | 0.02 | 


## Category: JOB

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| title | 33.07 | 4.41 | 1.19 | 0.0 | 
| company | 16.75 | 2.2 | 1.0 | 0.0 | 
| location | 20.06 | 2.92 | 1.0 | 0.0 | 
| date_posted | 11.35 | 1.81 | 0.8 | 0.2 | 


## Category: UNIVERSITY

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 27.85 | 3.64 | 1.04 | 0.0 | 
| phone | 11.49 | 1.89 | 1.23 | 0.12 | 
| website | 16.35 | 0.97 | 0.96 | 0.04 | 
| type | 15.75 | 2.1 | 1.0 | 0.0 | 


## Category: RESTAURANT

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 16.55 | 2.67 | 1.0 | 0.0 | 
| address | 19.05 | 3.57 | 2.8 | 0.01 | 
| phone | 10.52 | 1.49 | 1.0 | 0.0 | 
| cuisine | 11.78 | 1.47 | 1.16 | 0.01 | 


## Category: CAMERA

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| model | 73.99 | 12.76 | 1.3 | 0.0 | 
| price | 7.67 | 1.98 | 0.99 | 0.01 | 
| manufacturer | 8.14 | 1.3 | 1.64 | 0.0 | 


## Category: AUTO

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| model | 28.37 | 5.01 | 1.33 | 0.0 | 
| price | 9.81 | 2.31 | 1.11 | 0.0 | 
| engine | 22.46 | 5.34 | 0.92 | 0.11 | 
| fuel_economy | 18.84 | 4.81 | 1.25 | 0.08 | 


## Category: BOOK

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| title | 32.64 | 5.5 | 1.0 | 0.0 | 
| author | 14.14 | 2.27 | 1.17 | 0.01 | 
| isbn_13 | 13.0 | 1.0 | 1.0 | 0.0 | 
| publisher | 20.99 | 3.12 | 0.99 | 0.01 | 
| publication_date | 12.93 | 2.32 | 1.0 | 0.0 | 


## Category: NBA PLAYER

| Attribute | Average Length | Average Tokens | Average Solutions | Average Missing |
|---|---|---|---|---|
| name | 13.45 | 2.31 | 1.01 | 0.0 | 
| team | 13.32 | 1.92 | 0.9 | 0.1 | 
| height | 5.49 | 1.59 | 1.0 | 0.0 | 
| weight | 7.12 | 1.78 | 1.0 | 0.0 | 


